#pragma once
#include <cstdint>
#include <cstdio>
#include <string>
#include <ostream>
#include <sstream>
#include <algorithm>
#include <iostream>
typedef uint8_t u8; typedef uint16_t u16; typedef uint32_t u32; typedef uint64_t u64;
typedef int8_t s8; typedef int16_t s16; typedef int32_t s32; typedef int64_t s64;
typedef uint32_t offs_t;
namespace util {
template <typename T> inline T conv(T const &v) { return v; }
inline const char *conv(std::string const &s) { return s.c_str(); }
template <typename... A> std::string string_format(const char *f, A const &... a) { char b[512]; snprintf(b, sizeof b, f, conv(a)...); return b; }
template <typename... A> void stream_format(std::ostream &o, const char *f, A const &... a) { o << string_format(f, a...); }
}
using util::string_format;
namespace util {
class disasm_interface {
public:
  class data_buffer { public: const uint8_t *base; uint32_t org, len;
    u8 r8(offs_t a) const { a -= org; return a < len ? base[a] : 0; } };
  enum : u32 { SUPPORTED = 0x80000000, STEP_OVER = 0x20000000, STEP_OUT = 0x40000000, STEP_COND = 0x10000000 };
  virtual ~disasm_interface() {}
  virtual u32 opcode_alignment() const = 0;
  virtual offs_t disassemble(std::ostream &stream, offs_t pc, const data_buffer &opcodes, const data_buffer &params) = 0;
};
}
