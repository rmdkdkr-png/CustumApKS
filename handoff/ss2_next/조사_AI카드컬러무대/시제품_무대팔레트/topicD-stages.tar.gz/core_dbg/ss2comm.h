/* ss2comm — 사쇼!2 캐릭터 해설 엔진 (프런트엔드 공용)
   RAM만 읽어 이벤트를 잡고 대사 문자열(UTF-8)을 돌려준다. 표시는 프런트엔드가 한다.
   · libretro 코어 : ss2comm_frame() → RETRO_ENVIRONMENT_SET_MESSAGE 또는 ss2comm_draw()
   · NGP.emu (APK) : ss2comm_frame() → app.postMessage()
   브라우저판은 같은 로직의 JS 구현(runner.html)을 쓴다 — 이 파일은 그 이식본이다. */
#ifndef SS2COMM_H
#define SS2COMM_H
#include <stdint.h>
#ifdef __cplusplus
extern "C" {
#endif

#define SS2COMM_VERSION "1.0.2"   /* SS2 층 버전 — 릴리즈마다 올린다 */
void        ss2comm_set_ram(void *p);        /* SS2SP_RAM_POINTER 빌드에서만 필요 */
void        ss2comm_set_enabled(int on);     /* 코어 옵션 */
void        ss2comm_set_rom(const void *rom, unsigned len);
void        ss2comm_toast(const char *text, int frames); /* 기술명 한 줄 표시 (svcsp) */
void        ss2comm_overlay_spmode(int svc);   /* 1 = SvC — SP 배치가 svcsp 표를 쓴다 */
void        ss2comm_overlay_bind_knob(const char *name, unsigned char *v, int max); /* 숫자 노브 */
void        ss2comm_overlay_bind_extra(const char *name, unsigned char *v); /* 초상(얼굴)을 사용자 롬에서 그린다 */
void        ss2comm_rom_fix(void *rom, unsigned len);  /* 한글패치 글자 깨짐을 롬 메모리에서 보정 */
void        ss2comm_overlay_bind(unsigned char *chat, unsigned char *spk, unsigned char *ref,
                                 unsigned char *sides, unsigned char *sbg, unsigned char *vib,
                                 unsigned char *cap, unsigned char *sp); /* 빠른 설정 항목 연결 */
int         ss2comm_overlay_active(void);
void        ss2comm_overlay_toggle(void);
int         ss2comm_overlay_input(int k); /* 0상 1하 2좌 3우 4확인 5닫기 — 소비하면 1 */
void        ss2comm_overlay_draw(uint16_t *fb, int pitch_px, int w, int h);
void        ss2comm_set_speaker(int idx);    /* 0 = 하오마루. 순서는 ss2comm_speaker_name() 으로 */
int         ss2comm_speaker_count(void);     /* 해설자 수 (v0.7: 15) */
const char *ss2comm_speaker_name(int idx);   /* 화자 이름 (UTF-8) */
const char *ss2comm_speaker_hello(int idx);  /* 화자 인사 한마디 */
int         ss2comm_get_speaker(void);
int         ss2comm_next_speaker(int step);  /* 다음(또는 이전) 해설자로. 새 번호를 돌려준다 */
void        ss2comm_reset(void);             /* 롬 로드/리셋 시 */
void        ss2comm_notify(const char *text);/* 해설 자리에 안내 한 줄 */
/* 카드가 없어 SP 발동을 거른 경우의 안내. 글리프 추출이 이 파일도 훑으므로 여기에 둔다. */
#define SS2COMM_MSG_NOCARD "카드가 없다 \xe2\x80\x94 그 기술은 못 낸다"
const char *ss2comm_frame(void);             /* 매 프레임 1회. 새 대사면 문자열, 아니면 NULL */
const char *ss2comm_current(int *age_frames);/* 현재 표시 중인 대사(자체 렌더용) */
void        ss2comm_draw_enable(int mode);   /* 0 끔 1 확장띠 2 상단겹침 3 하단겹침 */
void        ss2comm_sp_band(int on);         /* 기술명 전용 띠 (해설 없는 롬용) */
int         ss2comm_rom_is_ss2(void);        /* 해설·초상을 돌려도 되는 롬인가 */
int         ss2comm_band_h(void);            /* 화면 **위** 해설 띠 높이 */
int         ss2comm_ref_h(void);             /* 항상 0 — 심판은 게임 화면 위 오버레이라 제 자리가 없다 */
int         ss2comm_ref_overlay(void);       /* (구) 게임-위 오버레이 조회 — 심판이 해설창으로 올라와 항상 0 */
void        ss2comm_set_ref(int on);         /* 심판(쿠로코) 온오프 — 온이면 심판이 해설창 우선, 캐릭터챗은 후순위 */
void        ss2comm_set_chat(int on);        /* 캐릭터챗 온오프 — 심판과 따로 끈다 (조합: 둘 다/캐릭터만/쿠로코만/무음) */
int         ss2comm_band_top(void);          /* 1이면 띠가 게임 화면 위에 붙는다 */
int         ss2comm_impact(void);            /* 지금 줄이 강조인가 — 진동·연출용 */
int         ss2comm_thump(void);             /* 심판 구령(승부!·한 판!)이 선 프레임에 1 — 진동 한 번용, 읽으면 지워짐 */
int         ss2comm_drawing(void);           /* 1이면 코어가 직접 그린다(알림 불필요) */
void        ss2comm_draw(uint16_t *fb, int pitch_px, int w, int h); /* 화면에 직접 그리기 */
/* 합성 프레임(프레임 생성)에서 띠를 한 번 더 그릴 때: 토스트 수명을 줄이지 않는다 */
void ss2comm_draw_hold(int on);
void        ss2comm_side(uint16_t *fb, int pitch_px, int w, int h, int right); /* 양옆 아트웍 기둥 한 짝 */

#ifdef __cplusplus
}
#endif
#endif
