/* ss2fg — 프레임 생성(중간 프레임 합성). 설명은 ss2fg.h.
 *
 * 렌더러는 mednafen gfx.c 의 draw_scanline_colour 를 그대로 옮기되
 *   · 스크롤값·스프라이트 오프셋은 스캔라인별로 a→b 보간한 값을 쓰고
 *   · 스프라이트는 체인을 푼 절대좌표를 슬롯별로 보간한다(같은 타일·팔레트·플립·
 *     우선순위일 때만 — 아니면 b 자리).
 * 타일·타일맵·팔레트는 b 의 것. 창(window)·배경색·반전·플레인 순서도 b 의 것. */
#include <string.h>
#include <stdlib.h>
#include "ss2fg.h"

/* ───────────── 캡처 ─────────────
   지난 프레임 몇 장을 쌓아 둔다(최근이 0번). 4배(게임 박자 맞춤) 예측은 N+1·N+2 를 미리 돌려 두 장을
   쌓았다가 두 번 무른다. */
#define FG_RING 10                 /* 런어헤드 2 + 미리 4(느린 몸 박자) + 실제·앞 프레임이 다 들어가게 */
static ss2fg_frame fg_slot[FG_RING + 2];   /* 99v: 뒤의 둘 = 멀리 미리 보기 전용(고리에 안 들어감) */
static int fg_hist[FG_RING] = { -1, -1, -1, -1, -1, -1, -1, -1, -1, -1 };   /* fg_hist[0] = 마지막(현재), [1] = 그 앞 … (-1 = 없음) */
static int fg_build = 0;
static uint8_t fg_build_dirty;
static int fg_pb_mode = 0, fg_pb_prev = -1, fg_pb_sbuild;   /* 99v: 멀리 미리 보기 중 — 캡처를 전용 칸에(고리 안 건드림) */
static uint8_t fg_pb_sdirty;
static void probe_check(const ss2fg_frame *f);
static void probe_clear(void);

static int next_free(void)
{
   int i, k, used;
   for (i = 0; i < FG_RING; i++)
   {
      used = 0;
      for (k = 0; k < FG_RING - 1; k++) if (fg_hist[k] == i) used = 1;
      if (!used) return i;
   }
   return fg_hist[FG_RING - 1] >= 0 ? fg_hist[FG_RING - 1] : 0;
}

void ss2fg_reset(void)
{
   int k;
   memset(fg_slot, 0, sizeof fg_slot);
   for (k = 0; k < FG_RING; k++) fg_hist[k] = -1;
   fg_build = 0;
   fg_build_dirty = 0;
   fg_pb_mode = 0; fg_pb_prev = -1;
   probe_clear();   /* 99v */
}

void ss2fg_capture_line(int y, const ss2fg_regs *r)
{
   if (y < 0 || y >= SS2FG_H) return;
   fg_slot[fg_build].line[y] = *r;
}

void ss2fg_capture_write(int dirty_bit)
{
   fg_build_dirty |= (uint8_t)dirty_bit;
}

/* 체인 비트를 풀어 절대좌표를 만든다 — 원본 렌더러처럼 보이지 않는 스프라이트도 앵커를 민다 */
static void resolve_chain(ss2fg_frame *f)
{
   int i, lx = 0, ly = 0;
   for (i = 0; i < 64; i++)
   {
      const uint8_t *s = f->spr + i * 4;
      uint16_t data = (uint16_t)(s[0] | (s[1] << 8));
      int x = s[2], y = s[3];
      if (data & 0x0400) x = lx + s[2];
      if (data & 0x0200) y = ly + s[3];
      lx = x; ly = y;
      f->ax[i] = (int16_t)x;
      f->ay[i] = (int16_t)y;
   }
}

/* 사무쇼2 RAM 의 물체 표 (리버싱 실측, 대전 3판)
   물체 k = 0x0E00 + 0x40·k : +0x36 종류(16비트, 0xFFFF = 빈 칸), +0x38 X, +0x3A Y(땅 = 128)
   k 0·1 = P1·P2(스프라이트 이동량과 99%+ 일치), 2·3 = 그림자, 4~7 = 기술 이펙트·장풍(겉모습 짝과 100% 일치).
   카메라 X 0x176D, 대전 중 = 0x00A7 이 241 */
#define FG_RAM_MODE   0x00A7
#define FG_RAM_FIGHT  241
#define FG_RAM_SELECT 240         /* 대전 밖 — 캐릭터·유파 고르기 화면(물체 0 = 가운데 미리보기 몸 80,76), 판 시작 전 소개 */
#define FG_RAM_CAMX   0x176D
#define FG_RAM_SCR    0x01C0      /* 99s: 화면 번호 — 0 제목·2 캐릭터 고르기·4 검질 고르기·6 카드·8~ 판 시작 전 */
#define FG_RAM_OBJ    0x0E00
static const uint8_t *fg_ram = 0;
void ss2fg_set_ram(const uint8_t *ram) { fg_ram = ram; }
static int id_on;                 /* 서기 사이 그림(아래 «서기 자세») 켬 */

static void capture_body(ss2fg_frame *f, const ss2fg_frame *pv)   /* pv = 직전 캡처(99v: 멀리 미리 보기 중엔 그 앞 미리 보기 칸) */
{
   int k, sel = 0;
   f->now_ok = (uint8_t)(fg_ram && fg_ram[FG_RAM_MODE] == FG_RAM_FIGHT);
   f->fight = f->now_ok;   /* 99r */
   /* 대전 밖(모드 240) — 고르기 화면 미리보기(물체 0 = 가운데 80,76, 유저 「여기서는 안 되는 거?」, 패치 96) +
      판 시작 전 소개(«いざ尋常に»·«一本目» 동안 두 캐릭터가 대전 자리에 서 있다 — 모드가 240 이라 사이 그림이 대전부터만 나왔다,
      유저 「대전 시작 전에도 좀 되게」, 패치 99). 서기 그리기가 켜졌을 때만, 몸(물체 0·1)만 — 그림자·이펙트 물체는 안 본다.
      끄면 예전과 같다(대전 밖은 몸 없음) */
   if (!f->now_ok && id_on && fg_ram && fg_ram[FG_RAM_MODE] == FG_RAM_SELECT)
   {
      const uint8_t *o = fg_ram + FG_RAM_OBJ;
      sel = !(o[0x36] == 0xFF && o[0x37] == 0xFF);
      f->now_ok = (uint8_t)sel;
   }
   f->ob_now_act = 0;
   for (k = 0; k < SS2FG_OBJS; k++)
   {
      const uint8_t *o = f->now_ok && (!sel || k <= 1) ? fg_ram + FG_RAM_OBJ + 0x40 * k : 0;
      int act = o && !(o[0x36] == 0xFF && o[0x37] == 0xFF);
      f->ob_now_x[k] = act ? (uint8_t)(o[0x38] - fg_ram[FG_RAM_CAMX]) : 0;
      f->ob_now_y[k] = act ? o[0x3A] : 0;
      f->ob_now_t[k] = act ? o[0x36] : 0;
      if (act) f->ob_now_act |= (uint8_t)(1u << k);
   }
   f->body_ok = (uint8_t)(f->now_ok && pv && pv->valid && pv->now_ok);
   for (k = 0; k < SS2FG_OBJS; k++)
   {
      f->ob_x[k] = f->body_ok ? pv->ob_now_x[k] : 0;
      f->ob_y[k] = f->body_ok ? pv->ob_now_y[k] : 0;
      f->ob_t[k] = f->body_ok ? pv->ob_now_t[k] : 0;
   }
   f->ob_act = f->body_ok ? pv->ob_now_act : 0;
   /* 99s: 고르기 화면 표시·몸 캐릭터 번호 — 다른 값처럼 «이 프레임 화면 = 직전 캡처 순간의 RAM» */
   f->pick_now = (uint8_t)(fg_ram && fg_ram[FG_RAM_MODE] == FG_RAM_SELECT && (fg_ram[FG_RAM_SCR] == 2 || fg_ram[FG_RAM_SCR] == 4) ? fg_ram[FG_RAM_SCR] : 0);
   for (k = 0; k < 2; k++) f->ch_now[k] = fg_ram ? fg_ram[FG_RAM_OBJ + 0x40 * k + 0x3C] : 0;
   f->pick = pv && pv->valid ? pv->pick_now : f->pick_now;
   for (k = 0; k < 2; k++) f->ch[k] = pv && pv->valid ? pv->ch_now[k] : f->ch_now[k];
}

void ss2fg_capture_end(const uint8_t *scroll, const uint8_t *chr, const uint8_t *spr,
                       const uint8_t *sprcol, const uint8_t *pal, int mono, int layers)
{
   ss2fg_frame *f = &fg_slot[fg_build];
   int k;
   capture_body(f, fg_pb_mode ? (fg_pb_prev >= 0 ? &fg_slot[fg_pb_prev] : 0) : (fg_hist[0] >= 0 ? &fg_slot[fg_hist[0]] : 0));
   memcpy(f->scroll, scroll, sizeof f->scroll);
   memcpy(f->chr,    chr,    sizeof f->chr);
   memcpy(f->spr,    spr,    sizeof f->spr);
   memcpy(f->sprcol, sprcol, sizeof f->sprcol);
   memcpy(f->pal,    pal,    sizeof f->pal);
   f->mono   = (uint8_t)(mono != 0);
   f->layers = layers;
   f->dirty  = fg_build_dirty;
   f->valid  = 1;
   resolve_chain(f);

   if (fg_pb_mode)
   {  /* 99v: 멀리 미리 보기 — 전용 칸 둘을 번갈아, 고리는 그대로 */
      fg_pb_prev = fg_build;
      fg_build = fg_build == FG_RING ? FG_RING + 1 : FG_RING;
      fg_build_dirty = 0;
      memcpy(fg_slot[fg_build].line, f->line, sizeof f->line);
      probe_check(f);
      return;
   }
   for (k = FG_RING - 1; k > 0; k--) fg_hist[k] = fg_hist[k - 1];
   fg_hist[0] = fg_build;
   fg_build = next_free();
   fg_build_dirty = 0;
   /* 다음 프레임의 줄 레지스터는 처음부터 다시 채운다 — 못 채운 줄이 남지 않게 지난 값으로 초기화 */
   memcpy(fg_slot[fg_build].line, f->line, sizeof f->line);
}

void ss2fg_capture_pop(void)
{
   int k;
   if (fg_hist[0] < 0) return;
   fg_build = fg_hist[0];
   for (k = 0; k < FG_RING - 1; k++) fg_hist[k] = fg_hist[k + 1];
   fg_hist[FG_RING - 1] = -1;
   fg_build_dirty = 0;
}

const ss2fg_frame *ss2fg_hist(int k)
{
   if (k < 0 || k >= FG_RING || fg_hist[k] < 0 || !fg_slot[fg_hist[k]].valid) return 0;
   return &fg_slot[fg_hist[k]];
}
const ss2fg_frame *ss2fg_prev(void) { return ss2fg_hist(1); }
const ss2fg_frame *ss2fg_cur(void)  { return ss2fg_hist(0); }

/* ───────────── 렌더러 ───────────── */
#define ZD_BACK_SPRITE   2
#define ZD_BG_SCROLL     3
#define ZD_FG_SCROLL     5

static const unsigned char mirrored[256] = {
    0x00, 0x40, 0x80, 0xc0, 0x10, 0x50, 0x90, 0xd0, 0x20, 0x60, 0xa0, 0xe0, 0x30, 0x70, 0xb0, 0xf0,
    0x04, 0x44, 0x84, 0xc4, 0x14, 0x54, 0x94, 0xd4, 0x24, 0x64, 0xa4, 0xe4, 0x34, 0x74, 0xb4, 0xf4,
    0x08, 0x48, 0x88, 0xc8, 0x18, 0x58, 0x98, 0xd8, 0x28, 0x68, 0xa8, 0xe8, 0x38, 0x78, 0xb8, 0xf8,
    0x0c, 0x4c, 0x8c, 0xcc, 0x1c, 0x5c, 0x9c, 0xdc, 0x2c, 0x6c, 0xac, 0xec, 0x3c, 0x7c, 0xbc, 0xfc,
    0x01, 0x41, 0x81, 0xc1, 0x11, 0x51, 0x91, 0xd1, 0x21, 0x61, 0xa1, 0xe1, 0x31, 0x71, 0xb1, 0xf1,
    0x05, 0x45, 0x85, 0xc5, 0x15, 0x55, 0x95, 0xd5, 0x25, 0x65, 0xa5, 0xe5, 0x35, 0x75, 0xb5, 0xf5,
    0x09, 0x49, 0x89, 0xc9, 0x19, 0x59, 0x99, 0xd9, 0x29, 0x69, 0xa9, 0xe9, 0x39, 0x79, 0xb9, 0xf9,
    0x0d, 0x4d, 0x8d, 0xcd, 0x1d, 0x5d, 0x9d, 0xdd, 0x2d, 0x6d, 0xad, 0xed, 0x3d, 0x7d, 0xbd, 0xfd,
    0x02, 0x42, 0x82, 0xc2, 0x12, 0x52, 0x92, 0xd2, 0x22, 0x62, 0xa2, 0xe2, 0x32, 0x72, 0xb2, 0xf2,
    0x06, 0x46, 0x86, 0xc6, 0x16, 0x56, 0x96, 0xd6, 0x26, 0x66, 0xa6, 0xe6, 0x36, 0x76, 0xb6, 0xf6,
    0x0a, 0x4a, 0x8a, 0xca, 0x1a, 0x5a, 0x9a, 0xda, 0x2a, 0x6a, 0xaa, 0xea, 0x3a, 0x7a, 0xba, 0xfa,
    0x0e, 0x4e, 0x8e, 0xce, 0x1e, 0x5e, 0x9e, 0xde, 0x2e, 0x6e, 0xae, 0xee, 0x3e, 0x7e, 0xbe, 0xfe,
    0x03, 0x43, 0x83, 0xc3, 0x13, 0x53, 0x93, 0xd3, 0x23, 0x63, 0xa3, 0xe3, 0x33, 0x73, 0xb3, 0xf3,
    0x07, 0x47, 0x87, 0xc7, 0x17, 0x57, 0x97, 0xd7, 0x27, 0x67, 0xa7, 0xe7, 0x37, 0x77, 0xb7, 0xf7,
    0x0b, 0x4b, 0x8b, 0xcb, 0x1b, 0x5b, 0x9b, 0xdb, 0x2b, 0x6b, 0xab, 0xeb, 0x3b, 0x7b, 0xbb, 0xfb,
    0x0f, 0x4f, 0x8f, 0xcf, 0x1f, 0x5f, 0x9f, 0xdf, 0x2f, 0x6f, 0xaf, 0xef, 0x3f, 0x7f, 0xbf, 0xff
};

static inline uint16_t ld16(const uint8_t *p) { return (uint16_t)(p[0] | (p[1] << 8)); }
static inline int imin(int a, int b) { return a < b ? a : b; }
static inline int imax(int a, int b) { return a > b ? a : b; }

/* a + d·t/256, 반올림(내림 나눗셈 기반 → .5 는 올림) */
static inline int lerp_i(int a, int d, int t)
{
   int v = d * t + 128;
   return a + (v >= 0 ? v / 256 : -((-v + 255) / 256));
}

/* 8비트 랩 최단경로 보간 — 임계 넘으면(장면 전환) 제자리(a = base) */
static inline uint8_t lerp_wrap8(uint8_t a, uint8_t b, int t)
{
   int d = (int8_t)(uint8_t)(b - a);
   if (d > SS2FG_SCROLL_MAX_STEP || d < -SS2FG_SCROLL_MAX_STEP) return a;
   return (uint8_t)lerp_i(a, d, t);
}

/* 원본의 세로 좌표 접기: 249..255 → -7..-1, 나머지는 하위 8비트(256 이상은 안 접힌다) */
static inline int wrapc(int v)
{
   if (v > 248 && v < 256) return v - 256;
   return v & 0xFF;
}
/* 가로는 한 번 더 접힌다 — 원본이 drawColourPattern 에 uint8 로 넘기고 그 안에서 >0xF8 이면 -256 */
static inline int wrapx(int v)
{
   v &= 0xFF;
   return v > 0xF8 ? v - 256 : v;
}

/* gfx.c drawColourPattern 과 같은 동작 — x 는 이미 접힌 좌표(-7..248) */
/* 서기 사이 그림(패치 100) — 몸 조각만 빼고 줄을 다시 그릴 때: 뺄 조각, 줄 끝 깊이(zbuf) 사본, 화소마다 차지한 스프라이트 슬롯 */
static const uint8_t *rl_skip = 0;
static uint8_t *rl_zout = 0;
static int16_t *rl_slot = 0;
static int rl_cur_slot = -1;
/* 99j: 스프라이트만의 맨 앞(플레인에 가린 것도) — 깊이(0 = 없음)·색(12비트, 반전 반영)·슬롯 */
static uint8_t  *rl_sprz = 0;
static uint16_t *rl_sprc = 0;
static int16_t  *rl_sprs = 0;

static void draw_pattern(const ss2fg_frame *f, const ss2fg_regs *r, uint16_t *scan, uint8_t *zbuf,
                         int x, unsigned tile, unsigned tiley, int mirror,
                         const uint8_t *palette, unsigned pal, uint8_t depth)
{
   int index, left, right, highmark, xx;
   if (x >= SS2FG_W) return;

   index = ld16(f->chr + (tile * 16) + (tiley * 2));
   if (mirror)
      index = mirrored[(index & 0xff00) >> 8] | (mirrored[index & 0xff] << 8);

   palette += pal << 3;                       /* 4색 × 2바이트 */
   left     = imax(imax(x, r->winx), 0);
   right    = x + 7;
   highmark = imin(r->winw + r->winx, SS2FG_W) - 1;
   if (right > highmark)
   {
      index >>= (right - highmark) * 2;
      right = highmark;
   }
   for (xx = right; xx >= left; --xx, index >>= 2)
   {
      uint16_t c;
      if ((index & 3) == 0) continue;
      if (rl_sprz && !(depth & 1) && depth > rl_sprz[xx])
      {  /* 99j: 스프라이트(깊이 2·4·6)만 따로 */
         uint16_t cs = ld16(palette + ((index & 3) << 1));
         if (r->neg) cs = (uint16_t)~cs;
         rl_sprz[xx] = depth; rl_sprc[xx] = (uint16_t)(cs & 0x0FFF);
         if (rl_sprs) rl_sprs[xx] = (int16_t)rl_cur_slot;
      }
      if (depth <= zbuf[xx]) continue;
      zbuf[xx] = depth;
      if (rl_slot) rl_slot[xx] = (int16_t)rl_cur_slot;
      c = ld16(palette + ((index & 3) << 1));
      if (r->neg) c = (uint16_t)~c;
      scan[xx] = c;
   }
}

/* 반투명 그리기 — K2GE 12비트 색(0BGR)을 채널마다 섞는다. 앞에 더 높은 우선순위가 있으면(zbuf) 건너뛴다. zbuf 는 안 바꾼다 */
static uint16_t mix12(uint16_t a, uint16_t b, int t)
{
   int r = ((a & 15) * (256 - t) + (b & 15) * t + 128) >> 8;
   int g = (((a >> 4) & 15) * (256 - t) + ((b >> 4) & 15) * t + 128) >> 8;
   int bl = (((a >> 8) & 15) * (256 - t) + ((b >> 8) & 15) * t + 128) >> 8;
   return (uint16_t)(r | (g << 4) | (bl << 8));
}
static void draw_pattern_blend(const ss2fg_frame *f, const ss2fg_regs *r, uint16_t *scan, const uint8_t *zbuf,
                               int x, unsigned tile, unsigned tiley, int mirror,
                               const uint8_t *palette, unsigned pal, uint8_t depth, int alpha)
{
   int index, left, right, highmark, xx;
   if (x >= SS2FG_W || alpha <= 0) return;
   index = ld16(f->chr + (tile * 16) + (tiley * 2));
   if (mirror)
      index = mirrored[(index & 0xff00) >> 8] | (mirrored[index & 0xff] << 8);
   palette += pal << 3;
   left     = imax(imax(x, r->winx), 0);
   right    = x + 7;
   highmark = imin(r->winw + r->winx, SS2FG_W) - 1;
   if (right > highmark) { index >>= (right - highmark) * 2; right = highmark; }
   for (xx = right; xx >= left; --xx, index >>= 2)
   {
      uint16_t c;
      if (depth < zbuf[xx] || (index & 3) == 0) continue;
      c = ld16(palette + ((index & 3) << 1));
      if (r->neg) c = (uint16_t)~c;
      scan[xx] = alpha >= 256 ? c : mix12(scan[xx], c, alpha);
   }
}

static void draw_scroll(const ss2fg_frame *f, const ss2fg_regs *r, uint16_t *scan, uint8_t *zbuf,
                        int y, int plane /*1·2*/, uint8_t sx, uint8_t sy, uint8_t depth)
{
   unsigned i;
   uint8_t line = (uint8_t)(y + sy);
   uint8_t row  = line & 7;
   const uint8_t *map = f->scroll + (plane == 2 ? 0x0800 : 0);
   const uint8_t *pal = f->pal + (plane == 2 ? 0x0100 : 0x0080);
   for (i = 0; i < 32; i++)
   {
      uint16_t d = ld16(map + ((i + ((line >> 3) << 5)) << 1));
      int x = ((i << 3) - sx) & 0xFF;
      if (x > 0xF8) x -= 256;
      draw_pattern(f, r, scan, zbuf, x, d & 0x01FF, (d & 0x4000) ? (7 - row) : row,
                   d & 0x8000, pal, (d & 0x1E00) >> 9, depth);
   }
}

/* ── 스프라이트 이동량 표 (프레임 쌍마다 한 번) ──
   base 의 슬롯 i 가 to 에서 같은 물체(타일·플립·우선순위·팔레트 동일, 이동 ≤ 임계)면 그 이동량.
   체인으로 묶인 그룹(메타스프라이트)은 일치한 조각들의 이동량이 서로 1px 안에 모이고 절반 이상
   일치하면 그 값을 그룹 벡터로 삼아, 타일이 바뀐(애니메이션) 조각도 같이 움직인다. */
typedef struct { int16_t dx, dy; uint8_t has; } fg_move;


/* 무리 벡터 검증용 — base 무리의 조각 중, 그 자리 + (vx,vy) 에 to 의 «같은 우선순위·팔레트» 조각이
   (슬롯 번호와 상관없이) 놓여 있는 개수. 슬롯 번호로 짝지은 벡터가 진짜 이동인지, 조각 하나가 끼어들어
   번호가 한 칸씩 밀린 것(배치는 그대로)인지 가른다. */
static int grp_overlap(const ss2fg_frame *base, const ss2fg_frame *to, int gstart, int g, int vx, int vy)
{
   const ss2fg_regs *rb = &base->line[0], *rt = &to->line[0];
   int k, j, c = 0;
   for (k = gstart; k < g; k++)
   {
      uint16_t wb = ld16(base->spr + k * 4);
      int bx, by;
      if (!(wb & 0x1800)) continue;
      bx = wrapx(base->ax[k] + rb->spx) + vx; by = wrapc(base->ay[k] + rb->spy) + vy;
      for (j = 0; j < 64; j++)
      {
         uint16_t wt = ld16(to->spr + j * 4);
         if (!(wt & 0x1800) || (wt & 0x1800) != (wb & 0x1800) || to->sprcol[j] != base->sprcol[k]) continue;
         if (wrapx(to->ax[j] + rt->spx) == bx && wrapc(to->ay[j] + rt->spy) == by) { c++; break; }
      }
   }
   return c;
}


/* 조각의 «겉모습» — 반전까지 적용한 8줄(2bpp). 사무쇼2 는 슬롯 번호가 자리표일 뿐이라(포즈마다 내용을
   새로 씀) 번호로는 같은 조각을 못 찾는다. 겉모습이 같은 조각끼리 짝지으면 진짜 대응이 나온다. */
static uint64_t piece_look(const ss2fg_frame *f, int k)
{
   uint16_t w = ld16(f->spr + k * 4);
   unsigned tile = w & 0x01FF, r;
   uint64_t h = 1469598103934665603ULL;
   int any = 0;
   if (!(w & 0x1800)) return 0;
   for (r = 0; r < 8; r++)
   {
      unsigned row = (w & 0x4000) ? 7 - r : r;
      uint16_t v = ld16(f->chr + tile * 16 + row * 2);
      if (w & 0x8000) v = (uint16_t)(mirrored[(v & 0xff00) >> 8] | (mirrored[v & 0xff] << 8));
      if (v) any = 1;
      h = (h ^ (v & 0xff)) * 1099511628211ULL;
      h = (h ^ (v >> 8)) * 1099511628211ULL;
   }
   return any ? (h | 1) : 0;                                   /* 빈 조각은 0 — 짝짓기에 안 쓴다 */
}

/* 겉모습 투표 — 무리(gstart..g-1)의 각 조각이 to 에서 «겉모습·우선순위·팔레트가 같은 조각»을 찾아
   그 거리로 표를 던진다(슬롯 번호 무관). 한 조각이 여러 곳과 맞으면 표를 나눈다. 뚜렷한 1등이 있으면
   그게 몸의 이동(0 이면 제자리) → 1, 아니면 0 (판단 보류 → 슬롯 번호 규칙으로). */
#define FG_VOTE_UNIT 12
static int look_vote(const ss2fg_frame *base, const ss2fg_frame *to, const uint64_t *lb, const uint64_t *lt,
                     int gstart, int g, int *vx, int *vy)
{
   const ss2fg_regs *rb = &base->line[0], *rt = &to->line[0];
   int cdx[256], cdy[256], cw[256], nc = 0, npc = 0, k, j, c;
   int best = -1, second = 0;
   for (k = gstart; k < g; k++)
   {
      int dup = 0, mj[4], mdx[4], mdy[4], m = 0, bx, by;
      uint16_t wb = ld16(base->spr + k * 4);
      if (!lb[k]) continue;
      for (j = gstart; j < g; j++) if (lb[j] == lb[k]) dup++;
      if (dup > 2) continue;                                   /* 흔한 무늬(칠한 면)는 아무 데나 맞는다 */
      npc++;
      bx = wrapx(base->ax[k] + rb->spx); by = wrapc(base->ay[k] + rb->spy);
      for (j = 0; j < 64 && m <= 4; j++)
      {
         uint16_t wt = ld16(to->spr + j * 4);
         int dx, dy;
         if (lt[j] != lb[k] || (wt & 0x1800) != (wb & 0x1800) || to->sprcol[j] != base->sprcol[k]) continue;
         dx = wrapx(to->ax[j] + rt->spx) - bx; dy = wrapc(to->ay[j] + rt->spy) - by;
         if (dx > SS2FG_SPR_MAX_STEP || dx < -SS2FG_SPR_MAX_STEP || dy > SS2FG_SPR_MAX_STEP || dy < -SS2FG_SPR_MAX_STEP) continue;
         if (m < 4) { mj[m] = j; mdx[m] = dx; mdy[m] = dy; }
         m++;
      }
      if (m == 0 || m > 4) continue;                           /* 바뀐 조각 / 너무 흔한 조각 */
      for (j = 0; j < m; j++)
      {
         for (c = 0; c < nc; c++) if (cdx[c] == mdx[j] && cdy[c] == mdy[j]) break;
         if (c == nc) { if (nc == 256) continue; cdx[nc] = mdx[j]; cdy[nc] = mdy[j]; cw[nc] = 0; nc++; }
         cw[c] += FG_VOTE_UNIT / m;
      }
      (void)mj;
   }
   for (c = 0; c < nc; c++)
      if (best < 0 || cw[c] > cw[best]) best = c;
   if (best < 0) return 0;
   for (c = 0; c < nc; c++)
      if (c != best && cw[c] > second) second = cw[c];
   if (cw[best] < 2 * FG_VOTE_UNIT) return 0;                  /* 두 조각 몫은 맞아야 */
   if (cw[best] * 10 < npc * FG_VOTE_UNIT * 3) return 0;       /* 겉모습 있는 조각의 30% 이상 */
   if (cw[best] < 2 * second) return 0;                        /* 뚜렷한 1등 */
   *vx = cdx[best]; *vy = cdy[best];
   return 1;
}

/* 제자리 겹침이 벡터 겹침보다 많으면 «배치만 바뀜». 같을 때는 벡터가 타일 간격 쪽(4px 이상)일 때만 —
   번호 밀림은 늘 ±8 근처로 나오고, 1~2px 짜리 동점은 실제로 조금 움직인 몸이라 보간을 살린다. */
static int layout_only(const ss2fg_frame *base, const ss2fg_frame *to, int gstart, int g, int vx, int vy)
{
   int o0, ov;
   if (!vx && !vy) return 0;
   o0 = grp_overlap(base, to, gstart, g, 0, 0);
   ov = grp_overlap(base, to, gstart, g, vx, vy);
   if (o0 > ov) return 1;
   return o0 == ov && (vx >= 4 || vx <= -4 || vy >= 4 || vy <= -4);
}

/* 몸 위치로 무리 벡터 정하기 — 사무쇼2 는 포즈가 바뀔 때 조각 내용·배치를 통째로 새로 쓴다. 맞고 빙글빙글
   날아갈 때는 2 프레임마다 회전 포즈가 새로 그려져 겉모습이 맞는 조각이 없고, 슬롯 번호로 짝지은 이동량은
   제각각(+22, -10 …)이라, 지금까지는 그 몸만 보간 없이 30Hz 로 툭툭 끊기거나 조각이 흩어졌다.
   게임이 RAM 에 둔 몸 위치(=실제 궤적)를 쓰면 지금 포즈를 그 궤적으로 옮길 수 있다(포즈는 다음 실제 프레임에
   바뀐다 — 회전 그림을 만들어 내진 않는다). 몸 위치가 그대로면 0 = 제자리(포즈만 바뀜 → 지금처럼 둔다).
   몸 팔레트(P1 = 0, P2 = 5)이고 무리가 그 몸 위치 근처일 때만 1. */
/* 몸 팔레트(P1 0 · P2 5)가 아닌데 «몸 그 자체»인 무리 — 감전(해골)·불탐처럼 맞은 몸을 다른 팔레트로 그리는 동안.
   그 캐릭터의 몸 팔레트 조각이 몸 자리 근처에 «하나도» 없고, 이 무리가 6조각 이상이며 몸 자리에 붙어 있을 때만.
   (나찰·카즈키 판 실측: 감전돼 날아가는 몸이 팔레트 14 로 23조각 — 예전엔 «이펙트»로 보고 제자리에 뒀다) */
static int body_alt_owner(const ss2fg_frame *base, int gstart, int g)
{
   const ss2fg_regs *rb = &base->line[0];
   int pal = base->sprcol[gstart] & 0x0F, p, k, j, n = 0, best = -1, bscore = 17;
   if (!base->body_ok || pal == 0 || pal == 5 || pal == 12) return -1;
   for (k = gstart; k < g; k++) if (ld16(base->spr + k * 4) & 0x1800) n++;
   if (n < 6) return -1;
   for (p = 0; p < 2; p++)
   {
      int bp = p ? 5 : 0, has = 0, l = 999, r = -999, t = 999, b = -999, dx, dy;
      if (!(base->ob_act & (1u << p))) continue;
      for (j = 0; j < 64 && !has; j++)
      {
         int sx, sy;
         if (!(ld16(base->spr + j * 4) & 0x1800) || (base->sprcol[j] & 0x0F) != bp) continue;
         sx = (int8_t)(uint8_t)(base->ax[j] + rb->spx - base->ob_x[p]);
         sy = (int8_t)(uint8_t)(base->ay[j] + rb->spy - base->ob_y[p]);
         if (sx >= -48 && sx <= 40 && sy >= -96 && sy <= 8) has = 1;
      }
      if (has) continue;
      for (k = gstart; k < g; k++)
      {
         int sx, sy;
         if (!(ld16(base->spr + k * 4) & 0x1800)) continue;
         sx = (int8_t)(uint8_t)(base->ax[k] + rb->spx - base->ob_x[p]);
         sy = (int8_t)(uint8_t)(base->ay[k] + rb->spy - base->ob_y[p]);
         if (sx < l) l = sx;
         if (sx + 8 > r) r = sx + 8;
         if (sy < t) t = sy;
         if (sy + 8 > b) b = sy + 8;
      }
      /* 몸 자리(발 가운데)가 무리 테두리 안(세로는 아래로 8px 여유)이면 0, 밖이면 그 거리 — 두 캐릭터 중 가까운 쪽(16px 안) */
      dx = l > 0 ? l : r < 0 ? -r : 0;
      dy = t > 0 ? t : b + 8 < 0 ? -(b + 8) : 0;
      if (dx + dy < bscore) { bscore = dx + dy; best = p; }
   }
   return best;
}

static int fg_last_owner;                                     /* body_vec 이 마지막으로 정한 몸 번호 */
static int8_t fg_body_of[64];                                 /* 조각 → 몸 번호(0·1), 아니면 -1 — sprite_moves 가 채운다 */
/* 몸 따로 박자 — 느린 박자(감전돼 날아갈 때 4프레임에 한 번)나 다른 조각과 바뀌는 때가 어긋난 몸은, 그 몸의 지난 바뀜·다음 바뀜
   사이로 따로 보간한 자리(1/256 px)를 libretro.c 가 넣어 준다. 켜진 몸의 조각은 무리 판정 이동량 대신 이 값으로 옮긴다. */
static int fg_ov_on[2], fg_ov_x[2], fg_ov_y[2];
/* 99i: 몸마다 이 출력 칸의 정확한 옮김(1/256 px) — render2 가 정하고 id_build 가 4배 격자(¼ px)로 그린다.
   1배 그림은 몸 조각을 정수 픽셀만큼만 옮길 수 있어, 느리게 움직이는 몸(KO 슬로모션으로 날아감·점프 꼭대기·걷기)은
   120Hz 네 칸 중 두세 칸이 같은 자리였다(봇 판 측정: 움직이는 동안 땅 33%·공중 19% 칸이 반올림에 묻힘) */
static int fg_spe_x[64], fg_spe_y[64];   /* 99r: 조각마다 이 칸의 정확한 옮김(1/256 px) — 몸과 같이 움직이는 «붙은» 조각 찾기 */
static int fg_ex_on[2], fg_ex_x[2], fg_ex_y[2];
void ss2fg_body_override(int p, int on, int x256, int y256)
{
   if (p < 0 || p > 1) return;
   fg_ov_on[p] = on; fg_ov_x[p] = x256; fg_ov_y[p] = y256;
}
static int body_vec(const ss2fg_frame *base, const ss2fg_frame *to, int gstart, int g, int *vx, int *vy)
{
   const ss2fg_regs *rb = &base->line[0];
   int pal = base->sprcol[gstart] & 0x0F, p, k, dx, dy;
   int l = 999, r = -999, t = 999, b = -999;
   fg_last_owner = -1;
   if (!base->body_ok || !to->body_ok) return 0;
   p = pal == 0 ? 0 : pal == 5 ? 1 : body_alt_owner(base, gstart, g);
   if (p < 0) return 0;
   if (!(base->ob_act & to->ob_act & (1u << p))) return 0;
   dx = (int8_t)(uint8_t)(to->ob_x[p] - base->ob_x[p]);
   dy = (int8_t)(uint8_t)(to->ob_y[p] - base->ob_y[p]);
   if (dx > SS2FG_SPR_MAX_STEP || dx < -SS2FG_SPR_MAX_STEP || dy > SS2FG_SPR_MAX_STEP || dy < -SS2FG_SPR_MAX_STEP) return 0;
   for (k = gstart; k < g; k++)                                /* 몸 위치 기준 상대 좌표(8비트 랩) 테두리 */
   {
      int sx, sy;
      if (!(ld16(base->spr + k * 4) & 0x1800)) continue;
      sx = (int8_t)(uint8_t)(base->ax[k] + rb->spx - base->ob_x[p]);
      sy = (int8_t)(uint8_t)(base->ay[k] + rb->spy - base->ob_y[p]);
      if (sx < l) l = sx;
      if (sx + 8 > r) r = sx + 8;
      if (sy < t) t = sy;
      if (sy + 8 > b) b = sy + 8;
   }
   if (l > r) return 0;
   /* 몸 위치(발 가운데)가 무리 테두리 옆 40px 안, 세로는 무리 위 16px ~ 아래 56px 안(머리만 떨어진 무리 포함) */
   if (l > 40 || r < -40 || t > 16 || b < -56) return 0;
   *vx = dx; *vy = dy;
   fg_last_owner = p;
   return 1;
}

/* 이펙트·그림자 무리 — 몸 팔레트가 아닌 무리가 겉모습으로 안 정해지면(기술 이펙트는 매 프레임 모양이 바뀐다),
   RAM 물체 표의 그림자(2·3)·이펙트(4~7) 칸 중 그 무리 테두리에 가장 가까운(16px 안) 물체의 이동량을 쓴다.
   앞뒤 프레임 모두 같은 종류로 쓰여 있는 칸만(칸이 다른 이펙트로 재사용되면 거리가 엉터리).
   하니스: 겉모습으로 정해진 이펙트 133건과 전부 일치. 캐릭터 칸(0·1)은 안 쓴다 — 캐릭터 근처 이펙트가
   캐릭터를 따라가지 않는 일이 많아(121 맞음 / 84 틀림) 쓰면 오히려 미끄러진다. */
#define FG_OBJ_NEAR 16
static int obj_vec(const ss2fg_frame *base, const ss2fg_frame *to, int gstart, int g, int *vx, int *vy)
{
   const ss2fg_regs *rb = &base->line[0];
   int pal = base->sprcol[gstart] & 0x0F, o, k, best = -1, bd = 999, dx, dy;
   if (!base->body_ok || !to->body_ok) return 0;
   if (pal == 0 || pal == 5) return 0;                        /* 몸은 body_vec */
   for (o = 2; o < SS2FG_OBJS; o++)
   {
      int l = 999, r = -999, t = 999, b = -999, ex, ey, d;
      if (!(base->ob_act & to->ob_act & (1u << o)) || base->ob_t[o] != to->ob_t[o]) continue;
      for (k = gstart; k < g; k++)
      {
         int sx, sy;
         if (!(ld16(base->spr + k * 4) & 0x1800)) continue;
         sx = (int8_t)(uint8_t)(base->ax[k] + rb->spx - base->ob_x[o]);
         sy = (int8_t)(uint8_t)(base->ay[k] + rb->spy - base->ob_y[o]);
         if (sx < l) l = sx;
         if (sx + 8 > r) r = sx + 8;
         if (sy < t) t = sy;
         if (sy + 8 > b) b = sy + 8;
      }
      if (l > r) return 0;
      ex = l > 0 ? l : r < 0 ? -r : 0;                        /* 물체 자리에서 무리 테두리까지 */
      ey = t > 0 ? t : b < 0 ? -b : 0;
      d = ex > ey ? ex : ey;
      if (d < bd) { bd = d; best = o; }
   }
   if (best < 0 || bd > FG_OBJ_NEAR) return 0;
   dx = (int8_t)(uint8_t)(to->ob_x[best] - base->ob_x[best]);
   dy = (int8_t)(uint8_t)(to->ob_y[best] - base->ob_y[best]);
   if (dx > SS2FG_SPR_MAX_STEP || dx < -SS2FG_SPR_MAX_STEP || dy > SS2FG_SPR_MAX_STEP || dy < -SS2FG_SPR_MAX_STEP) return 0;
   /* 맞춰 보기 — 물체 자리가 그림의 기준점이 아닌 이펙트가 많다(카즈키 판: 폭발 그림 옆 불똥 물체가 +18 로 움직였는데
      다음 그림은 제자리 → 앞으로 갔다 되돌아오는 흔들림). to 의 같은 팔레트 조각 테두리 가운데가 물체와 같이(±2px)
      움직였을 때만 믿는다. 그림자는 거의 늘 맞고, 모양이 바뀌는 이펙트는 대부분 여기서 걸러진다(→ 지금처럼 제자리). */
   {
      const ss2fg_regs *rt = &to->line[0];
      uint16_t key = ld16(base->spr + gstart * 4) & 0x1800;
      int l = 999, r = -999, t = 999, b = -999, l2 = 999, r2 = -999, t2 = 999, b2 = -999, j, cx, cy;
      for (k = gstart; k < g; k++)
      {
         int sx, sy;
         if (!(ld16(base->spr + k * 4) & 0x1800)) continue;
         sx = wrapx(base->ax[k] + rb->spx); sy = wrapc(base->ay[k] + rb->spy);
         if (sx < l) l = sx;
         if (sx + 8 > r) r = sx + 8;
         if (sy < t) t = sy;
         if (sy + 8 > b) b = sy + 8;
      }
      for (j = 0; j < 64; j++)
      {
         uint16_t w = ld16(to->spr + j * 4);
         int sx, sy;
         if ((w & 0x1800) != key || to->sprcol[j] != base->sprcol[gstart]) continue;
         sx = wrapx(to->ax[j] + rt->spx); sy = wrapc(to->ay[j] + rt->spy);
         if (sx + 8 < l - 40 || sx > r + 40 || sy + 8 < t - 40 || sy > b + 40) continue;
         if (sx < l2) l2 = sx;
         if (sx + 8 > r2) r2 = sx + 8;
         if (sy < t2) t2 = sy;
         if (sy + 8 > b2) b2 = sy + 8;
      }
      if (l2 > r2) return 0;                                  /* 다음 프레임에 그 그림이 없다 — 맞춰 볼 수 없음 */
      cx = (l2 + r2) - (l + r); cy = (t2 + b2) - (t + b);     /* 가운데 이동 ×2 */
      if (abs(cx - 2 * dx) > 4 || abs(cy - 2 * dy) > 4) return 0;
   }
   *vx = dx; *vy = dy;
   return 1;
}

/* 외톨이 조각 하나 — to 에 겉모습·우선순위·팔레트가 같은 조각이 임계 안에 «딱 하나» 있으면 그 거리 */
static int single_look(const ss2fg_frame *base, const ss2fg_frame *to, const uint64_t *lb, const uint64_t *lt,
                       int k, int *vx, int *vy)
{
   const ss2fg_regs *rb = &base->line[0], *rt = &to->line[0];
   uint16_t wb = ld16(base->spr + k * 4);
   int j, c = 0, bx, by;
   if (!lb[k]) return 0;
   bx = wrapx(base->ax[k] + rb->spx); by = wrapc(base->ay[k] + rb->spy);
   for (j = 0; j < 64; j++)
   {
      uint16_t wt = ld16(to->spr + j * 4);
      int dx, dy;
      if (lt[j] != lb[k] || (wt & 0x1800) != (wb & 0x1800) || to->sprcol[j] != base->sprcol[k]) continue;
      dx = wrapx(to->ax[j] + rt->spx) - bx; dy = wrapc(to->ay[j] + rt->spy) - by;
      if (dx > SS2FG_SPR_MAX_STEP || dx < -SS2FG_SPR_MAX_STEP || dy > SS2FG_SPR_MAX_STEP || dy < -SS2FG_SPR_MAX_STEP) continue;
      if (++c > 1) return 0;
      *vx = dx; *vy = dy;
   }
   return c == 1;
}

static void set_group(const ss2fg_frame *base, fg_move mv[64], int gstart, int g, int vx, int vy)
{
   int k;
   for (k = gstart; k < g; k++)
   {
      if (ld16(base->spr + k * 4) & 0x1800)
      { mv[k].dx = (int16_t)vx; mv[k].dy = (int16_t)vy; mv[k].has = (uint8_t)(vx || vy); }
      else mv[k].has = 0;
   }
}

/* ── 이펙트·장풍 (모양이 매 프레임 바뀌는 무리) ──
   겉모습·몸·물체 위치 어느 것으로도 못 정한 무리를, 같은 팔레트·우선순위 조각 테두리로 앞뒤를 본다.
   «직전 바뀐 프레임 → base → to» 두 걸음의 테두리 가운데 이동이 1px 안으로 같고 크기도 그대로면(등속으로
   날아가는 장풍·불덩이) 그 이동량으로 옮긴다. 한 걸음만 보고 옮기면 번쩍임·폭발처럼 모양이 바뀌며 자리가
   튀는 것까지 미끄러져 흔들린다 — 두 걸음이 같을 때만. */
static int same_sprites(const ss2fg_frame *a, const ss2fg_frame *b)
{
   return !memcmp(a->spr, b->spr, sizeof a->spr) && !memcmp(a->sprcol, b->sprcol, sizeof a->sprcol) &&
          !memcmp(a->ax, b->ax, sizeof a->ax) && !memcmp(a->ay, b->ay, sizeof a->ay) &&
          a->line[0].spx == b->line[0].spx && a->line[0].spy == b->line[0].spy;
}
/* base 보다 앞선 캡처 중 스프라이트가 base 와 다른 가장 최근 것 (없으면 0) */
static const ss2fg_frame *older_change(const ss2fg_frame *base)
{
   int i, j;
   for (i = 0; i < FG_RING; i++)
      if (fg_hist[i] >= 0 && &fg_slot[fg_hist[i]] == base) break;
   if (i >= FG_RING) return 0;
   for (j = i + 1; j < FG_RING; j++)
   {
      const ss2fg_frame *f;
      if (fg_hist[j] < 0) return 0;
      f = &fg_slot[fg_hist[j]];
      if (!f->valid || f->mono || (f->dirty & SS2FG_DIRTY_SPR)) return 0;
      if (!same_sprites(f, base)) return f;
   }
   return 0;
}
/* f 에서 우선순위 key·팔레트 pal 조각 무리의 테두리 — 창(w0..w1, h0..h1)에 걸치는 조각을 씨앗으로, 16px 안에
   붙는 같은 팔레트 조각을 넓혀 모은다(한 이펙트가 슬롯 여러 구간에 흩어져 있어도 하나로). 반환 = 조각 수 */
static int fx_box(const ss2fg_frame *f, uint16_t key, uint8_t pal, int w0, int w1, int h0, int h1,
                  int *x0, int *x1, int *y0, int *y1)
{
   const ss2fg_regs *r = &f->line[0];
   int j, c = 0, grew = 1;
   int px[64], py[64], in[64], np = 0;
   *x0 = 999; *x1 = -999; *y0 = 999; *y1 = -999;
   for (j = 0; j < 64; j++)
   {
      uint16_t w = ld16(f->spr + j * 4);
      if ((w & 0x1800) != key || f->sprcol[j] != pal) continue;
      px[np] = wrapx(f->ax[j] + r->spx); py[np] = wrapc(f->ay[j] + r->spy);
      in[np] = !(px[np] + 8 < w0 || px[np] > w1 || py[np] + 8 < h0 || py[np] > h1);
      np++;
   }
   while (grew)
   {
      grew = 0;
      for (j = 0; j < np; j++)
      {
         int i;
         if (in[j]) continue;
         for (i = 0; i < np; i++)
            if (in[i] && abs(px[i] - px[j]) <= 16 && abs(py[i] - py[j]) <= 16) { in[j] = 1; grew = 1; break; }
      }
   }
   for (j = 0; j < np; j++)
   {
      if (!in[j]) continue;
      c++;
      if (px[j] < *x0) *x0 = px[j];
      if (px[j] + 8 > *x1) *x1 = px[j] + 8;
      if (py[j] < *y0) *y0 = py[j];
      if (py[j] + 8 > *y1) *y1 = py[j] + 8;
   }
   return c;
}
static int fx_stats[8];
static int fx_last = 0, fx_in_render = 0;
/* 이펙트 처리: 0 끔(예전 그대로) · 1 옮기기 · 2 옮기기 + 못 정한 것은 다음 그림과 반투명 섞기 (코어 옵션 ngp_framegen_fx) */
static int fx_mode = 1;
void ss2fg_set_fx(int mode) { fx_mode = mode < 0 ? 0 : mode > 2 ? 2 : mode; }
static uint8_t fx_fade_b[64];        /* render 중: base 조각이 «섞어 사라질» 이펙트인가 */
static uint8_t fx_fade_in[64];       /* render 중: to 조각 중 «섞어 나타날» 이펙트 */
static int fx_fade_on = 0, fx_fade_t = 0;
static const ss2fg_frame *fx_fade_to = 0;   /* 시험용: 판정 이유 찍기 / 마지막 fx_vec 결과 코드 */
#include <stdio.h>   /* 시험용 계기: [0] 살핀 무리 [1] 앞 캡처 없음 [2] 등속 아님 [3] 옮김 */
/* base 무리(gstart..g)를 씨앗으로 같은 팔레트 이펙트 전체 테두리 */
static void fx_base_box(const ss2fg_frame *base, int gstart, int g, int *x0, int *x1, int *y0, int *y1)
{
   const ss2fg_regs *rb = &base->line[0];
   int k;
   *x0 = 999; *x1 = -999; *y0 = 999; *y1 = -999;
   for (k = gstart; k < g; k++)
   {
      uint16_t w = ld16(base->spr + k * 4);
      int sx, sy;
      if (!(w & 0x1800)) continue;
      sx = wrapx(base->ax[k] + rb->spx); sy = wrapc(base->ay[k] + rb->spy);
      if (sx < *x0) *x0 = sx;
      if (sx + 8 > *x1) *x1 = sx + 8;
      if (sy < *y0) *y0 = sy;
      if (sy + 8 > *y1) *y1 = sy + 8;
   }
   if (*x0 <= *x1)
      fx_box(base, ld16(base->spr + gstart * 4) & 0x1800, base->sprcol[gstart], *x0, *x1 - 1, *y0, *y1 - 1, x0, x1, y0, y1);
}
static int half_round(int v2) { return v2 >= 0 ? (v2 + 1) / 2 : -((-v2 + 1) / 2); }

/* ① 장풍(따로 날아가는 것) — «직전 바뀐 프레임 → base → to» 두 걸음의 테두리 가운데 이동이 2px 안으로 같고,
   진행 방향으로 테두리 양쪽 끝이 다 같은 쪽으로 움직였을 때(돌면서 날아가는 삼각 장풍처럼 모양·크기가 바뀌어도 됨).
   한쪽 끝이 고정된 «늘어나는» 이펙트(칼 궤적)는 가운데가 반만 움직여 등속처럼 보이므로 양쪽 끝 검사로 거른다. */
static int fx_vec(const ss2fg_frame *base, const ss2fg_frame *to, const ss2fg_frame *prev, int gstart, int g,
                  int *vx, int *vy)
{
   uint16_t key = ld16(base->spr + gstart * 4) & 0x1800;
   uint8_t pal = base->sprcol[gstart];
   int bx0, bx1, by0, by1, tx0, tx1, ty0, ty1, px0, px1, py0, py1;
   int c2bx, c2by, v2x, v2y, v1x, v1y;
   fx_stats[0]++;
   if (!prev) { fx_stats[1]++; fx_last = 1; return 0; }
   fx_base_box(base, gstart, g, &bx0, &bx1, &by0, &by1);
   if (bx0 > bx1) return 0;
   if (!fx_box(to, key, pal, bx0 - 24, bx1 + 24, by0 - 24, by1 + 24, &tx0, &tx1, &ty0, &ty1) ||
       !fx_box(prev, key, pal, bx0 - 24, bx1 + 24, by0 - 24, by1 + 24, &px0, &px1, &py0, &py1))
   { fx_stats[4]++; fx_last = 4; return 0; }
   c2bx = bx0 + bx1; c2by = by0 + by1;
   v2x = (tx0 + tx1) - c2bx; v2y = (ty0 + ty1) - c2by;
   v1x = c2bx - (px0 + px1); v1y = c2by - (py0 + py1);
   if (abs(v2x - v1x) > 4 || abs(v2y - v1y) > 4) { fx_stats[6]++; fx_last = 6; return 0; }
   if (abs(v2x) + abs(v2y) < 4) { fx_stats[7]++; fx_last = 7; return 0; }        /* 2px 미만 — 옮길 것 없음 */
   /* 진행 축(더 많이 움직인 축)에서 양쪽 끝이 두 걸음 모두 같은 방향으로 */
   if (abs(v2x) >= abs(v2y))
   {
      int sgn = v2x > 0 ? 1 : -1;
      if ((tx0 - bx0) * sgn <= 0 || (tx1 - bx1) * sgn <= 0 || (bx0 - px0) * sgn <= 0 || (bx1 - px1) * sgn <= 0)
      { fx_stats[5]++; fx_last = 5; return 0; }
   }
   else
   {
      int sgn = v2y > 0 ? 1 : -1;
      if ((ty0 - by0) * sgn <= 0 || (ty1 - by1) * sgn <= 0 || (by0 - py0) * sgn <= 0 || (by1 - py1) * sgn <= 0)
      { fx_stats[5]++; fx_last = 5; return 0; }
   }
   *vx = half_round(v2x); *vy = half_round(v2y);
   if (*vx > SS2FG_SPR_MAX_STEP || *vx < -SS2FG_SPR_MAX_STEP || *vy > SS2FG_SPR_MAX_STEP || *vy < -SS2FG_SPR_MAX_STEP)
   { fx_stats[6]++; fx_last = 6; return 0; }
   fx_stats[3]++; fx_last = 3;
   return 1;
}

static int fx_on_body(const ss2fg_frame *f, int o)
{
   int p;
   for (p = 0; p < 2; p++)
      if ((f->ob_act >> p) & 1 && abs((int)f->ob_x[o] - (int)f->ob_x[p]) <= 1)
         return 1;
   return 0;
}

/* ③ RAM 물체로 나는 장풍 — 돌면서 날아가는 삼각 장풍처럼 그림 테두리는 회전 때문에 들쭉날쭉해도, 게임의 물체 자리(RAM)는
   한 걸음에 -8px 씩 똑같이 간다(나찰 판 실측: 101→93→85→77…). 이펙트 근처(48px)의 물체 «모두»를 보고,
   앞 걸음과 이번 걸음의 이동이 1px 안으로 같으면서 다음 그림 테두리 가운데가 그 이동과 가장 잘 맞는(8px 안) 물체를 고른다.
   가까운 물체 하나만 보면 옆을 지나는 캐릭터 그림자(+2~3px)를 잡아 장풍을 거꾸로 끌고 가는 일이 생겼다(나찰 판 2255). */
static int fx_objpath(const ss2fg_frame *base, const ss2fg_frame *to, const ss2fg_frame *prev, int gstart, int g,
                      int *vx, int *vy)
{
   const ss2fg_regs *rb = &base->line[0];
   uint16_t key = ld16(base->spr + gstart * 4) & 0x1800;
   uint8_t pal = base->sprcol[gstart];
   int o, k, best = 999, bvx = 0, bvy = 0, bx0, bx1, by0, by1;
   if (!prev || !base->body_ok || !to->body_ok || !prev->body_ok) return 0;
   fx_base_box(base, gstart, g, &bx0, &bx1, &by0, &by1);
   if (bx0 > bx1) return 0;
   for (o = 2; o < SS2FG_OBJS; o++)
   {
      int l = 999, r = -999, t = 999, b = -999, ex, ey, d, d1x, d1y, d2x, d2y, tx0, tx1, ty0, ty1, err;
      if (!(base->ob_act & to->ob_act & prev->ob_act & (1u << o))) continue;
      if (base->ob_t[o] != to->ob_t[o] || base->ob_t[o] != prev->ob_t[o]) continue;
      /* 몸과 같은 x 에 붙어 다니는 물체(그림자·몸에 딸린 이펙트)는 몸 이동 그대로라 장풍 길잡이가 못 됨 — 몸에 붙은 이펙트는 ② 가 맡음 */
      if (fx_on_body(base, o) || fx_on_body(to, o)) continue;
      for (k = gstart; k < g; k++)
      {
         int sx, sy;
         if (!(ld16(base->spr + k * 4) & 0x1800)) continue;
         sx = (int8_t)(uint8_t)(base->ax[k] + rb->spx - base->ob_x[o]);
         sy = (int8_t)(uint8_t)(base->ay[k] + rb->spy - base->ob_y[o]);
         if (sx < l) l = sx;
         if (sx + 8 > r) r = sx + 8;
         if (sy < t) t = sy;
         if (sy + 8 > b) b = sy + 8;
      }
      if (l > r) continue;
      ex = l > 0 ? l : r < 0 ? -r : 0;
      ey = t > 0 ? t : b < 0 ? -b : 0;
      d = ex > ey ? ex : ey;
      if (d > 8) continue;                                     /* 장풍은 제 물체 자리를 감싸고(8px 안) 그려진다 */
      d2x = (int8_t)(uint8_t)(to->ob_x[o] - base->ob_x[o]);  d2y = (int8_t)(uint8_t)(to->ob_y[o] - base->ob_y[o]);
      d1x = (int8_t)(uint8_t)(base->ob_x[o] - prev->ob_x[o]); d1y = (int8_t)(uint8_t)(base->ob_y[o] - prev->ob_y[o]);
      if (abs(d2x - d1x) > 1 || abs(d2y - d1y) > 1) continue;
      if (abs(d2x) + abs(d2y) < 1) continue;
      if (d2x > SS2FG_SPR_MAX_STEP || d2x < -SS2FG_SPR_MAX_STEP || d2y > SS2FG_SPR_MAX_STEP || d2y < -SS2FG_SPR_MAX_STEP) continue;
      if (!fx_box(to, key, pal, bx0 - 24 + d2x, bx1 + 24 + d2x, by0 - 24 + d2y, by1 + 24 + d2y, &tx0, &tx1, &ty0, &ty1)) continue;
      ex = abs((tx0 + tx1) - (bx0 + bx1) - 2 * d2x); ey = abs((ty0 + ty1) - (by0 + by1) - 2 * d2y);
      err = ex > ey ? ex : ey;
      if (err <= 16 && err < best) { best = err; bvx = d2x; bvy = d2y; }
   }
   if (best == 999) return 0;
   *vx = bvx; *vy = bvy;
   return 1;
}

/* ② 몸에 붙은 이펙트(칼 궤적·기 모으기 등) — 몸이 움직이는데 이펙트만 제자리면 중간 그림에서 몸에서 떨어져 보인다.
   이펙트가 몸 근처이고, «앞 걸음과 이번 걸음 둘 다» 같은 팔레트 이펙트 테두리 가운데가 몸 이동과 6px 안으로 같이 움직였으면
   몸 이동량(RAM — 정확)으로 옮긴다. 한 걸음만 보면 몸 옆을 지나 날아가는 장풍이 우연히 맞아 몸에 붙어 끌려갔다(나찰 판 2255).
   맞은 자리에 고정된 불똥은 몸만 밀려나고 불똥은 제자리라 걸리지 않는다. */
static int fx_attach(const ss2fg_frame *base, const ss2fg_frame *to, const ss2fg_frame *prev, int gstart, int g,
                     int *vx, int *vy)
{
   uint16_t key = ld16(base->spr + gstart * 4) & 0x1800;
   uint8_t pal = base->sprcol[gstart];
   int bx0, bx1, by0, by1, tx0, tx1, ty0, ty1, px0, px1, py0, py1, p, best = 99, bvx = 0, bvy = 0;
   if (!prev || !base->body_ok || !to->body_ok || !prev->body_ok) return 0;
   fx_base_box(base, gstart, g, &bx0, &bx1, &by0, &by1);
   if (bx0 > bx1) return 0;
   for (p = 0; p < 2; p++)
   {
      int dx, dy, d1x, d1y, ex, ey, rx0, rx1, ry0, ry1, err, err1;
      if (!(prev->ob_act & base->ob_act & to->ob_act & (1u << p))) continue;
      dx = (int8_t)(uint8_t)(to->ob_x[p] - base->ob_x[p]);
      dy = (int8_t)(uint8_t)(to->ob_y[p] - base->ob_y[p]);
      d1x = (int8_t)(uint8_t)(base->ob_x[p] - prev->ob_x[p]);
      d1y = (int8_t)(uint8_t)(base->ob_y[p] - prev->ob_y[p]);
      if (abs(dx) + abs(dy) < 2) continue;                       /* 몸이 안 움직이면 붙일 이유 없음 */
      if (dx > SS2FG_SPR_MAX_STEP || dx < -SS2FG_SPR_MAX_STEP || dy > SS2FG_SPR_MAX_STEP || dy < -SS2FG_SPR_MAX_STEP) continue;
      /* 몸(발 가운데) 기준 상대 테두리 — 옆 56px, 위 80px ~ 아래 24px 안에 걸쳐야 «몸 근처» */
      rx0 = bx0 - (int)base->ob_x[p]; rx1 = bx1 - (int)base->ob_x[p];
      ry0 = by0 - (int)base->ob_y[p]; ry1 = by1 - (int)base->ob_y[p];
      if (rx0 > 56 || rx1 < -56 || ry0 > 24 || ry1 < -80) continue;
      if (!fx_box(to, key, pal, bx0 - 24 + dx, bx1 + 24 + dx, by0 - 24 + dy, by1 + 24 + dy, &tx0, &tx1, &ty0, &ty1)) continue;
      if (!fx_box(prev, key, pal, bx0 - 24 - d1x, bx1 + 24 - d1x, by0 - 24 - d1y, by1 + 24 - d1y, &px0, &px1, &py0, &py1)) continue;
      ex = (tx0 + tx1) - (bx0 + bx1) - 2 * dx; ey = (ty0 + ty1) - (by0 + by1) - 2 * dy;
      err = abs(ex) > abs(ey) ? abs(ex) : abs(ey);
      ex = (bx0 + bx1) - (px0 + px1) - 2 * d1x; ey = (by0 + by1) - (py0 + py1) - 2 * d1y;
      err1 = abs(ex) > abs(ey) ? abs(ex) : abs(ey);
      if (err1 > err) err = err1;
      if (err <= 12 && err < best) { best = err; bvx = dx; bvy = dy; }
   }
   if (best == 99) return 0;
   *vx = bvx; *vy = bvy;
   return 1;
}
void ss2fg_fx_stats(int *out4) { int i; for (i = 0; i < 8; i++) out4[i] = fx_stats[i]; }

static void sprite_moves(const ss2fg_frame *base, const ss2fg_frame *to, fg_move mv[64])
{
   const ss2fg_regs *rb = &base->line[0], *rt = &to->line[0];
   int i, g, gstart;
   uint64_t lb[64], lt[64];
   uint8_t und[64];                 /* und[gstart] = 그 무리 끝(g) — 아무것도 못 정한 비체인 무리 (0 = 아님) */
   char why[64];                    /* 무리 판정 — 'u' = 못 정함(이펙트 섞기 후보) */
   memset(why, 0, sizeof why);
   memset(fg_body_of, 0xFF, sizeof fg_body_of);
   memset(mv, 0, 64 * sizeof *mv);
   memset(und, 0, sizeof und);
   for (i = 0; i < 64; i++) { lb[i] = piece_look(base, i); lt[i] = piece_look(to, i); }

   for (i = 0; i < 64; i++)
   {
      uint16_t db = ld16(base->spr + i * 4), dt = ld16(to->spr + i * 4);
      int bx, by, tx, ty, dx, dy;
      if (!(db & 0x1800) || !(dt & 0x1800)) continue;          /* 둘 다 보여야 */
      if (db != dt || base->sprcol[i] != to->sprcol[i]) continue;
      bx = wrapx(base->ax[i] + rb->spx); by = wrapc(base->ay[i] + rb->spy);
      tx = wrapx(to->ax[i]   + rt->spx); ty = wrapc(to->ay[i]   + rt->spy);
      dx = tx - bx; dy = ty - by;
      if (dx > SS2FG_SPR_MAX_STEP || dx < -SS2FG_SPR_MAX_STEP ||
          dy > SS2FG_SPR_MAX_STEP || dy < -SS2FG_SPR_MAX_STEP) continue;
      mv[i].dx = (int16_t)dx; mv[i].dy = (int16_t)dy; mv[i].has = 1;
   }

   /* 비체인 무리 합의 — 사무쇼2 처럼 체인 없이 «슬롯마다 고정 타일 번호(0x57+슬롯)»를 쓰고 포즈가 바뀔 때
      타일 «내용»과 배치를 새로 쓰는 게임은, 같은 번호·속성이 «다른 조각»을 가리킨다. 번호만 같다고 이어 붙이면
      조각마다 제각각인 가짜 이동량(-7, -15, (9,-8) …)이 생겨 숨쉬기 같은 제자리 포즈에서 몸이 흩어졌다.
      이웃 슬롯(속성 상위 비트·팔레트가 같은 연속 구간 = 한 캐릭터)의 이동량이 1px 안에 모이지 않으면
      «배치가 바뀌었다»로 보고 그 무리 전원을 보간하지 않는다(base 자리). 모이면 안 맞은 조각도 그 벡터로. */
   for (gstart = 0; gstart < 64; gstart = g)
   {
      /* 무리 = 우선순위·팔레트가 같고, 지금까지 모인 무리의 테두리에서 16px 안에 붙는 연속 슬롯 = 한 캐릭터.
         (반전 비트는 조각마다 달라 무시. 줄 바뀜으로 앞 슬롯과는 멀어도 몸통 테두리 안이면 같은 무리 —
          줄 단위로 끊으면 줄마다 «그 줄만 일관된» 가짜 이동량이 살아나 다시 깨진다) */
      uint16_t key = ld16(base->spr + gstart * 4) & 0x1800;
      uint8_t  pal = base->sprcol[gstart];
      int n = 0, m = 0, k, any_chain = 0, body, bvx = 0, bvy = 0, objv, ovx = 0, ovy = 0;
      int minx = 999, maxx = -999, miny = 999, maxy = -999;
      int bx0 = base->ax[gstart], bx1 = base->ax[gstart] + 8, by0 = base->ay[gstart], by1 = base->ay[gstart] + 8;
      for (g = gstart + 1; g < 64; g++)
      {
         uint16_t w = ld16(base->spr + g * 4);
         int sx = base->ax[g], sy = base->ay[g];
         if ((w & 0x1800) != key || base->sprcol[g] != pal) break;
         if (sx + 8 < bx0 - 16 || sx > bx1 + 16 || sy + 8 < by0 - 16 || sy > by1 + 16) break;
         if (sx < bx0) bx0 = sx;
         if (sx + 8 > bx1) bx1 = sx + 8;
         if (sy < by0) by0 = sy;
         if (sy + 8 > by1) by1 = sy + 8;
      }
      for (k = gstart; k < g; k++)
      {
         uint16_t w = ld16(base->spr + k * 4);
         if (w & 0x0600) any_chain = 1;
         if (!(w & 0x1800)) continue;
         n++;
         if (!mv[k].has) continue;
         m++;
         if (mv[k].dx < minx) minx = mv[k].dx;
         if (mv[k].dx > maxx) maxx = mv[k].dx;
         if (mv[k].dy < miny) miny = mv[k].dy;
         if (mv[k].dy > maxy) maxy = mv[k].dy;
      }
      if (any_chain) { why[gstart] = 'c'; continue; }          /* 체인 무리는 아래 체인 규칙에 맡긴다 */
      body = body_vec(base, to, gstart, g, &bvx, &bvy);
      if (body) for (k = gstart; k < g; k++) fg_body_of[k] = (int8_t)fg_last_owner;   /* 몸 박자 따로 보간에 쓴다 */
      objv = body ? 0 : obj_vec(base, to, gstart, g, &ovx, &ovy);
      if (n < 2)
      {
         /* 외톨이 조각(돌며 날아갈 때 몸에서 떨어져 나온 조각, 이펙트 한 조각 등) — 몸·물체 위치를 알면 슬롯 번호 짝
            (엉뚱한 +22px 따위) 대신, 겉모습 짝이 딱 하나면 그 거리, 아니면 몸·물체 위치로 */
         if (objv) { bvx = ovx; bvy = ovy; }
         if (!(body || objv) && n == 1) und[gstart] = (uint8_t)g;
         why[gstart] = (body || objv) ? '1' : 'u';
         if ((body || objv) && n == 1)
            for (k = gstart; k < g; k++)
               if (ld16(base->spr + k * 4) & 0x1800)
               {
                  int vx = bvx, vy = bvy;
                  single_look(base, to, lb, lt, k, &vx, &vy);
                  mv[k].dx = (int16_t)vx; mv[k].dy = (int16_t)vy; mv[k].has = (uint8_t)(vx || vy);
               }
         continue;
      }
      {
         /* 1순위: 겉모습 투표 — 슬롯 번호가 밀리거나(조각 끼어듦) 포즈가 바뀌어도, 그대로 남은 조각들이
            몸의 진짜 이동을 알려 준다. 정해지면 무리 전체를 그 벡터로(0 이면 제자리) */
         int vx, vy;
         int slot_ok = m > 0 && m * 2 >= n && maxx - minx <= 1 && maxy - miny <= 1;
         if (look_vote(base, to, lb, lt, gstart, g, &vx, &vy) &&
             !(slot_ok && (vx < minx || vx > maxx || vy < miny || vy > maxy)) &&  /* 둘이 어긋나면(드묾) 슬롯 합의 쪽 */
             !(body && (bvx || bvy) && (abs(vx - bvx) > 4 || abs(vy - bvy) > 4)))  /* 몸이 움직였는데 딴 데를 가리키면 우연한 짝 */
         {
            why[gstart] = 'L';
            set_group(base, mv, gstart, g, vx, vy);
            continue;
         }
      }
      if (body)                                               /* 2순위: 몸 위치 — 슬롯 번호 어림보다 정확하다 */
      {
         why[gstart] = 'B';
         set_group(base, mv, gstart, g, bvx, bvy);
         continue;
      }
      /* 이펙트·그림자는 슬롯 번호 규칙이 정한 건 그대로 두고, 아무것도 못 정한 «빈칸»만 물체 위치로 채운다 */
      if (m == 0)
      {
         if (objv) set_group(base, mv, gstart, g, ovx, ovy);
         else und[gstart] = (uint8_t)g;
         why[gstart] = objv ? 'O' : 'u';
         continue;
      }
      if (m * 2 < n || maxx - minx > 1 || maxy - miny > 1)
      {
         /* 합의 없음. 다만 보이는 조각의 70% 이상이 «같은 벡터»면 그게 몸의 이동이고 나머지는 배치가 바뀐
            조각이다(걷기 -2px 에 일부 조각만 재배치) → 무리 전체를 그 벡터로 단단히. 아니면 무리 전체 제자리. */
         int best = 0, bdx = 0, bdy = 0, j;
         for (k = gstart; k < g; k++)
         {
            int c = 0;
            if (!mv[k].has) continue;
            for (j = gstart; j < g; j++)
               if (mv[j].has && mv[j].dx == mv[k].dx && mv[j].dy == mv[k].dy) c++;
            if (c > best) { best = c; bdx = mv[k].dx; bdy = mv[k].dy; }
         }
         /* 70% 가 같은 벡터여도, 조각 «자리들»이 제자리에서 더 많이 겹치면 진짜 이동이 아니다 —
            사무쇼2 카즈키(나찰) 유파선택 대기: 머리 조각 하나가 슬롯 0 에 끼어들면 나머지 번호가 한 칸씩 밀려
            13 조각 중 9 개가 «-8px» 로 짝지어진다(타일 간격). 배치는 그대로라 제자리 겹침 14 vs -8 겹침 10. */
         if (best * 10 >= n * 7 && layout_only(base, to, gstart, g, bdx, bdy))
            best = 0;
         if (best * 10 < n * 7 && objv)
         {
            set_group(base, mv, gstart, g, ovx, ovy);
            continue;
         }
         for (k = gstart; k < g; k++)
         {
            if (best * 10 >= n * 7 && (ld16(base->spr + k * 4) & 0x1800))
            { mv[k].dx = (int16_t)bdx; mv[k].dy = (int16_t)bdy; mv[k].has = 1; }
            else mv[k].has = 0;
         }
         if (best * 10 < n * 7) und[gstart] = (uint8_t)g;
         why[gstart] = best * 10 < n * 7 ? 'u' : '7';
         continue;
      }
      {
         /* 합의된 벡터도 같은 검증 — 번호 밀림이 무리 전체에 고르게 걸리면 «합의»처럼 보인다 */
         int cx = (minx + maxx) >= 0 ? (minx + maxx + 1) / 2 : -((-(minx + maxx) + 1) / 2);
         int cy = (miny + maxy) >= 0 ? (miny + maxy + 1) / 2 : -((-(miny + maxy) + 1) / 2);
         if (layout_only(base, to, gstart, g, cx, cy))
         {
            if (objv) set_group(base, mv, gstart, g, ovx, ovy);
            else { for (k = gstart; k < g; k++) mv[k].has = 0; und[gstart] = (uint8_t)g; }
            why[gstart] = objv ? 'O' : 'u';
            continue;
         }
      }
      why[gstart] = 'S';
      for (k = gstart; k < g; k++)
         if (!mv[k].has && (ld16(base->spr + k * 4) & 0x1800))
         {
            mv[k].dx = (int16_t)((minx + maxx) >= 0 ? (minx + maxx + 1) / 2 : -((-(minx + maxx) + 1) / 2));
            mv[k].dy = (int16_t)((miny + maxy) >= 0 ? (miny + maxy + 1) / 2 : -((-(miny + maxy) + 1) / 2));
            mv[k].has = 1;
         }
   }
   /* 못 정한 무리 중 몸 팔레트(0·5)가 아닌 것 = 이펙트·장풍 — ③ RAM 물체 등속 → ② 몸에 붙음 → ① 테두리 등속 순서로 */
   if (fx_mode)
   {
      const ss2fg_frame *prev = 0;
      int prev_done = 0;
      for (gstart = 0; gstart < 64; gstart++)
      {
         int vx, vy;
         uint8_t pal;
         if (!und[gstart]) continue;
         pal = base->sprcol[gstart];
         if (pal == 0 || pal == 5) continue;
         if (!prev_done) { prev = older_change(base); prev_done = 1; }
         int ok;
         if (fx_objpath(base, to, prev, gstart, und[gstart], &vx, &vy))
         { set_group(base, mv, gstart, und[gstart], vx, vy); why[gstart] = 'R'; continue; }
         if (fx_attach(base, to, prev, gstart, und[gstart], &vx, &vy))
         { set_group(base, mv, gstart, und[gstart], vx, vy); why[gstart] = 'A'; fx_stats[2]++; continue; }
         ok = fx_vec(base, to, prev, gstart, und[gstart], &vx, &vy);
         if (ok) { set_group(base, mv, gstart, und[gstart], vx, vy); why[gstart] = 'F'; }
      }
   }
   if (fx_in_render)
   {
      memset(fx_fade_b, 0, sizeof fx_fade_b);
      for (gstart = 0; gstart < 64; gstart++)
         if (und[gstart] && why[gstart] == 'u' && base->sprcol[gstart] != 0 && base->sprcol[gstart] != 5 &&
             base->sprcol[gstart] != 12)
            memset(fx_fade_b + gstart, 1, und[gstart] - gstart);
   }
   /* 체인 그룹: 슬롯 k 에 체인 비트(0x0600)가 있으면 k-1 과 같은 그룹 */
   for (gstart = 0; gstart < 64; gstart = g)
   {
      int n = 0, m = 0, k;
      int minx = 999, maxx = -999, miny = 999, maxy = -999;
      for (g = gstart + 1; g < 64; g++)
         if (!(ld16(base->spr + g * 4) & 0x0600)) break;
      if (g - gstart < 2) continue;
      for (k = gstart; k < g; k++)
      {
         if (!(ld16(base->spr + k * 4) & 0x1800)) continue;
         n++;
         if (!mv[k].has) continue;
         m++;
         if (mv[k].dx < minx) minx = mv[k].dx;
         if (mv[k].dx > maxx) maxx = mv[k].dx;
         if (mv[k].dy < miny) miny = mv[k].dy;
         if (mv[k].dy > maxy) maxy = mv[k].dy;
      }
      if (m == 0 || m * 2 < n) continue;                        /* 절반 미만 일치 → 믿지 않는다 */
      if (maxx - minx > 1 || maxy - miny > 1) continue;         /* 조각이 제각각 → 그룹 벡터 없음 */
      for (k = gstart; k < g; k++)
         if (!mv[k].has && (ld16(base->spr + k * 4) & 0x1800))
         {
            mv[k].dx = (int16_t)((minx + maxx) >= 0 ? (minx + maxx + 1) / 2 : -((-(minx + maxx) + 1) / 2));
            mv[k].dy = (int16_t)((miny + maxy) >= 0 ? (miny + maxy + 1) / 2 : -((-(miny + maxy) + 1) / 2));
            mv[k].has = 1;
         }
   }
}

/* ───────────── 포즈 섞기 (코어 패치 80) ─────────────
   맞고 빙글빙글 날아가는 동안 사무쇼2 는 몸 포즈 두 장(쭉 뻗음·웅크림)을 실제 2 프레임(1/30초)마다 번갈아 그린다 — 60Hz 원판에도
   그대로라 «깜빡이며 날아가는» 느낌이 난다(유저 2026-10-10 「다 깜빡이는 거마냥 날아가는데 원래 그런가 보네 — 연구 좀 해 봐」).
   포즈는 그림이 통째로 바뀌어 조각을 옮겨 이어 줄 수 없으니, «번갈아 바뀌는 몸»만 중간 그림에서 지금 포즈(1−t)와 다음 포즈(t)를
   반투명으로 겹친다(잔상). 그 몸을 지금 포즈로 그린 줄과 다음 포즈로 그린 줄을 따로 만들어 화소마다 섞으므로, 앞에 있는
   다른 조각·배경과의 앞뒤는 원래 그리기 순서 그대로다. 다음 포즈는 몸 이동(RAM)만큼 되돌린 자리에서 출발해 t 와 함께 제자리로.
   켜지는 때: 몸 포즈가 base→to 에서 바뀌고, 포즈가 3 프레임 이하씩 돌아가는 중이고(to 포즈가 최근에 나왔던 것 = 순환),
   몸이 공중에서 움직이는 중(pose_alternates). 몸 따로 박자(패치 70)가 걸린 몸은 안 섞는다. 코어 옵션 ngp_framegen_pose(blend·off).
   하니스(대전 11판, 예측·보간 4배·2배): 섞인 그림은 모두 맞고 날아가는 몸 — 걷기·대시·공격 포즈는 그대로. 끄면 출력 해시 예전과 동일. */
static int pose_mode = 1;
static int pose_stats[4];          /* [0] 몸 포즈가 바뀐 그림 [1] 번갈음 아님 [2] 섞음 [3] 안 움직임 */
void ss2fg_set_pose(int on) { pose_mode = on ? 1 : 0; }
void ss2fg_pose_stats(int *out4) { int i; for (i = 0; i < 4; i++) out4[i] = pose_stats[i]; }
static int pp_on = 0;
static uint8_t pp_skip[64], pp_add[64];
static int16_t pp_dx[64], pp_dy[64];
static const ss2fg_frame *pp_to = 0;
static int pp_ymin, pp_ymax;

/* f 의 몸 p 조각 — 몸 팔레트(P1 0 · P2 5) 무리(sprite_moves 와 같은 무리 나누기) 중 테두리가 몸 자리 근처(body_vec 과 같은 창) */
static int body_mask(const ss2fg_frame *f, int p, uint8_t *mask)
{
   const ss2fg_regs *r = &f->line[0];
   int gstart, g, n = 0, bp = p ? 5 : 0;
   memset(mask, 0, 64);
   if (!f->valid || f->mono || !f->body_ok || !(f->ob_act & (1u << p))) return 0;
   for (gstart = 0; gstart < 64; gstart = g)
   {
      uint16_t key = ld16(f->spr + gstart * 4) & 0x1800;
      uint8_t pal = f->sprcol[gstart];
      int bx0 = f->ax[gstart], bx1 = f->ax[gstart] + 8, by0 = f->ay[gstart], by1 = f->ay[gstart] + 8, k;
      int l = 999, rr = -999, t = 999, b = -999;
      for (g = gstart + 1; g < 64; g++)
      {
         uint16_t w = ld16(f->spr + g * 4);
         int sx = f->ax[g], sy = f->ay[g];
         if ((w & 0x1800) != key || f->sprcol[g] != pal) break;
         if (sx + 8 < bx0 - 16 || sx > bx1 + 16 || sy + 8 < by0 - 16 || sy > by1 + 16) break;
         if (sx < bx0) bx0 = sx;
         if (sx + 8 > bx1) bx1 = sx + 8;
         if (sy < by0) by0 = sy;
         if (sy + 8 > by1) by1 = sy + 8;
      }
      if (!key || (pal & 0x0F) != bp) continue;
      for (k = gstart; k < g; k++)
      {
         int sx, sy;
         if (!(ld16(f->spr + k * 4) & 0x1800)) continue;
         sx = (int8_t)(uint8_t)(f->ax[k] + r->spx - f->ob_x[p]);
         sy = (int8_t)(uint8_t)(f->ay[k] + r->spy - f->ob_y[p]);
         if (sx < l) l = sx;
         if (sx + 8 > rr) rr = sx + 8;
         if (sy < t) t = sy;
         if (sy + 8 > b) b = sy + 8;
      }
      if (l > rr || l > 40 || rr < -40 || t > 16 || b < -56) continue;
      for (k = gstart; k < g; k++)
         if (ld16(f->spr + k * 4) & 0x1800) { mask[k] = 1; n++; }
   }
   return n;
}

/* 몸 포즈의 지문 — 조각마다 (겉모습, 몸 테두리 왼쪽 위 기준 자리)를 줄·칸 순으로 늘어놓은 해시. 자리(몸 이동)와 슬롯 번호에 무관 */
static uint64_t body_sig(const ss2fg_frame *f, const uint8_t *mask)
{
   const ss2fg_regs *r = &f->line[0];
   int k, n = 0, i, j, x0 = 9999, y0 = 9999;
   int px[64], py[64];
   uint64_t lk[64], h = 1469598103934665603ULL;
   for (k = 0; k < 64; k++)
   {
      if (!mask[k]) continue;
      px[n] = wrapx(f->ax[k] + r->spx); py[n] = wrapc(f->ay[k] + r->spy); lk[n] = piece_look(f, k);
      if (px[n] < x0) x0 = px[n];
      if (py[n] < y0) y0 = py[n];
      n++;
   }
   if (!n) return 0;
   for (i = 1; i < n; i++)                                       /* 줄(y)·칸(x)·겉모습 순으로 */
      for (j = i; j > 0; j--)
      {
         int sw = py[j] < py[j - 1] || (py[j] == py[j - 1] && (px[j] < px[j - 1] || (px[j] == px[j - 1] && lk[j] < lk[j - 1])));
         int tx, ty; uint64_t tl;
         if (!sw) break;
         tx = px[j]; px[j] = px[j - 1]; px[j - 1] = tx;
         ty = py[j]; py[j] = py[j - 1]; py[j - 1] = ty;
         tl = lk[j]; lk[j] = lk[j - 1]; lk[j - 1] = tl;
      }
   for (i = 0; i < n; i++)
   {
      h = (h ^ (uint64_t)(uint8_t)(px[i] - x0)) * 1099511628211ULL;
      h = (h ^ (uint64_t)(uint8_t)(py[i] - y0)) * 1099511628211ULL;
      h = (h ^ lk[i]) * 1099511628211ULL;
   }
   return h | 1;
}

static int ring_index(const ss2fg_frame *f)
{
   int i;
   for (i = 0; i < FG_RING; i++) if (fg_hist[i] >= 0 && &fg_slot[fg_hist[i]] == f) return i;
   return -1;
}

/* 몸 p 를 섞을지 — 맞고 날아가는 몸은 포즈를 1~3 프레임마다 돌려 가며 그린다(하니스 실측 나코루루: 웅크림 14조각 ·
   뻗음 20조각 두 가지가 «뻗음1·웅크림·뻗음2·웅크림…» 으로 2 프레임씩). 그래서 «A·B·A» 하나만 보지 않고:
   base 포즈가 3 프레임 이하로 이어졌고, 그 앞으로도 3 프레임 이하짜리 포즈가 둘 이상 이어졌고(짧게 돌아가는 중),
   다음 포즈(st)가 최근에 이미 나왔고(돌아오는 포즈 = 순환), 몸이 공중(발 높이 < 땅 128 − 4)에서 움직이는 중일 때.
   걷기·대시(한 포즈 4 프레임 넘게, 또는 땅 위)와 제자리 연타(안 움직임)는 안 걸린다.
   몸 조각을 못 찾는 프레임(맞는 순간 번쩍임 — 다른 팔레트)을 만나면 거기서 멈춘다. */
#define FG_GROUND_Y 128
static int pose_alternates(const ss2fg_frame *base, const ss2fg_frame *to, int p, uint64_t sb, uint64_t st)
{
   int i = ring_index(base), j, cur_len = 1, changes = 0, seen_st = 0, moved = 0;
   uint64_t cur = sb;
   uint8_t m[64];
   if (i < 0) return 0;
   if (base->ob_y[p] > FG_GROUND_Y - 4 && to->ob_y[p] > FG_GROUND_Y - 4) return 0;      /* 땅 위 */
   if (to->ob_x[p] != base->ob_x[p] || to->ob_y[p] != base->ob_y[p]) moved = 1;
   for (j = i + 1; j < FG_RING; j++)
   {
      const ss2fg_frame *f = fg_hist[j] >= 0 ? &fg_slot[fg_hist[j]] : 0;
      uint64_t sg;
      if (!f || !body_mask(f, p, m)) break;
      sg = body_sig(f, m);
      if (f->ob_x[p] != base->ob_x[p] || f->ob_y[p] != base->ob_y[p]) moved = 1;
      if (sg == cur)
      {
         if (++cur_len > 3) { if (!changes) return 0; break; }  /* base 포즈가 오래 머묾 → 아님 / 앞쪽 긴 포즈 → 거기까지 */
         continue;
      }
      changes++;                                                 /* cur 포즈가 3 프레임 이하로 끝남 */
      cur = sg; cur_len = 1;
      if (sg == st) seen_st = 1;
   }
   if (changes < 2 || !seen_st) return 0;
   if (!moved) { pose_stats[3]++; return 0; }
   return 1;
}

static void render_line(const ss2fg_frame *base, const ss2fg_frame *to, const int16_t *offx, const int16_t *offy,
                        int t, int y, uint16_t *scan)
{
   const ss2fg_regs *rb = &base->line[y];
   uint8_t zbuf[256];
   uint16_t c;
   int x = 0, spr;
   int in_win = (y >= rb->winy) && (y < rb->winy + rb->winh);

   memset(zbuf, 0, sizeof zbuf);
   rl_cur_slot = -1;
   if (rl_slot) { int i; for (i = 0; i < 256; i++) rl_slot[i] = -1; }
   if (rl_sprz) memset(rl_sprz, 0, SS2FG_W);

   /* 창 밖 색 */
   c = ld16(base->pal + 0x01F0 + (rb->oowc << 1));
   if (rb->neg) c = (uint16_t)~c;
   if (in_win)
   {
      for (x = 0; x < imin(rb->winx, SS2FG_W); x++) scan[x] = c;
      x = imin(rb->winx + rb->winw, SS2FG_W);
   }
   for (; x < SS2FG_W; x++) scan[x] = c;

   if (!in_win) { if (rl_zout) memcpy(rl_zout, zbuf, sizeof zbuf); return; }

   /* 배경색 */
   c = ld16(base->pal + 0x01E0 + ((rb->bgc & 7) << 1));
   if (rb->neg) c = (uint16_t)~c;
   for (x = rb->winx; x < imin(rb->winx + rb->winw, SS2FG_W); x++) scan[x] = c;

   /* 스크롤 플레인 — 값만 base→to 보간, 내용·순서는 base */
   {
      uint8_t s1x = rb->s1x, s1y = rb->s1y, s2x = rb->s2x, s2y = rb->s2y;
      if (to)
      {
         const ss2fg_regs *rt = &to->line[y];
         s1x = lerp_wrap8(rb->s1x, rt->s1x, t); s1y = lerp_wrap8(rb->s1y, rt->s1y, t);
         s2x = lerp_wrap8(rb->s2x, rt->s2x, t); s2y = lerp_wrap8(rb->s2y, rt->s2y, t);
      }
      if (rb->swap)
      {
         if (base->layers & 1) draw_scroll(base, rb, scan, zbuf, y, 1, s1x, s1y, ZD_BG_SCROLL);
         if (base->layers & 2) draw_scroll(base, rb, scan, zbuf, y, 2, s2x, s2y, ZD_FG_SCROLL);
      }
      else
      {
         if (base->layers & 1) draw_scroll(base, rb, scan, zbuf, y, 2, s2x, s2y, ZD_BG_SCROLL);
         if (base->layers & 2) draw_scroll(base, rb, scan, zbuf, y, 1, s1x, s1y, ZD_FG_SCROLL);
      }
   }

   /* 스프라이트 — base 의 것을 이동량만큼 옮겨 그린다.
      포즈 섞기 둘째 판(pp_on)에서는 섞을 몸의 base 조각을 빼고, 그 자리 순서(슬롯 번호)에 다음 포즈(pp_to) 조각을 넣는다 */
   if (base->layers & 4)
   for (spr = 0; spr < 64; spr++)
   {
      uint16_t d = ld16(base->spr + spr * 4);
      unsigned priority = (d & 0x1800) >> 11;
      int sx, sy;
      if (priority != 0 && !(pp_on == 2 && pp_skip[spr]) && !(fx_fade_on && fx_fade_b[spr])   /* 섞어 그릴 이펙트 — 아래 반투명 단계에서 */
          && !(rl_skip && rl_skip[spr]))                                                       /* 서기 사이 그림: 몸 뺀 줄 */
      {
         rl_cur_slot = spr;
         sx = wrapx(base->ax[spr] + rb->spx);
         sy = wrapc(base->ay[spr] + rb->spy);
         if (offx) { sx += offx[spr]; sy += offy[spr]; }
         if (y >= sy && y <= sy + 7)
         {
            unsigned row = (unsigned)(y - sy) & 7;
            draw_pattern(base, rb, scan, zbuf, sx, d & 0x01FF, (d & 0x4000) ? 7 - row : row,
                         d & 0x8000, base->pal, base->sprcol[spr] & 0xF, (uint8_t)(priority << 1));
         }
      }
      if (pp_on == 2 && pp_add[spr])
      {
         const ss2fg_regs *rt = &pp_to->line[y];
         uint16_t dt = ld16(pp_to->spr + spr * 4);
         unsigned pt = (dt & 0x1800) >> 11;
         sx = wrapx(pp_to->ax[spr] + rt->spx) + pp_dx[spr];
         sy = wrapc(pp_to->ay[spr] + rt->spy) + pp_dy[spr];
         if (pt && y >= sy && y <= sy + 7)
         {
            unsigned row = (unsigned)(y - sy) & 7;
            draw_pattern(pp_to, rb, scan, zbuf, sx, dt & 0x01FF, (dt & 0x4000) ? 7 - row : row,
                         dt & 0x8000, pp_to->pal, pp_to->sprcol[spr] & 0xF, (uint8_t)(pt << 1));
         }
      }
   }
   if (fx_fade_on && (base->layers & 4))
   {
      /* 반투명 단계: 사라질 base 이펙트(1-t) 위에 다음 그림의 이펙트(t) */
      for (spr = 0; spr < 64; spr++)
      {
         uint16_t d = ld16(base->spr + spr * 4);
         unsigned priority = (d & 0x1800) >> 11;
         int sx, sy;
         if (!priority || !fx_fade_b[spr]) continue;
         sx = wrapx(base->ax[spr] + rb->spx); sy = wrapc(base->ay[spr] + rb->spy);
         if (y >= sy && y <= sy + 7)
         {
            unsigned row = (unsigned)(y - sy) & 7;
            draw_pattern_blend(base, rb, scan, zbuf, sx, d & 0x01FF, (d & 0x4000) ? 7 - row : row,
                               d & 0x8000, base->pal, base->sprcol[spr] & 0xF, (uint8_t)(priority << 1), 256 - fx_fade_t);
         }
      }
      if (fx_fade_to)
      {
         const ss2fg_regs *rt = &fx_fade_to->line[y];
         for (spr = 0; spr < 64; spr++)
         {
            uint16_t d = ld16(fx_fade_to->spr + spr * 4);
            unsigned priority = (d & 0x1800) >> 11;
            int sx, sy;
            if (!priority || !fx_fade_in[spr]) continue;
            sx = wrapx(fx_fade_to->ax[spr] + rt->spx); sy = wrapc(fx_fade_to->ay[spr] + rt->spy);
            if (y >= sy && y <= sy + 7)
            {
               unsigned row = (unsigned)(y - sy) & 7;
               draw_pattern_blend(fx_fade_to, rb, scan, zbuf, sx, d & 0x01FF, (d & 0x4000) ? 7 - row : row,
                                  d & 0x8000, fx_fade_to->pal, fx_fade_to->sprcol[spr] & 0xF, (uint8_t)(priority << 1), fx_fade_t);
            }
         }
      }
   }
   if (rl_zout) memcpy(rl_zout, zbuf, sizeof zbuf);
}

/* ══ 서기 사이 그림 (코어 패치 100) ═══════════════════════════════════════════════════════════
   유저 2026-10-11 「뉴트럴 포즈를 기존 방식대로 일단 해 줘 봐, 그리는 거랑도」 → 비교 영상 → 「ㄱ」.
   서 있는 몸은 포즈 6~8장을 6~18 프레임씩 돌린다(하오마루 8장×8f, 갈포드 8장×14f …). 장마다 윗몸이 1~2픽셀
   옮겨진 그림이라 원래 해상도(160칸)에선 그 «사이»가 없다 — 4배 격자(640칸)에 앞 장·뒤 장의 화소를 움직인 만큼의
   t 씩 ¼픽셀로 옮겨 찍어 사이 그림을 만든다. 섞지 않는다(도트 그대로), 반이 넘으면 뒤 장이 위로.
   ① 관찰(실제 프레임마다): 몸 포즈 그림을 지문별로 기억하고, 제자리에서 A→B 로 바뀐 것과 A 의 길이를 배운다.
   ② 계획(출력마다): 지금 포즈 A 다음이 B 로 굳었고(같은 바뀜 2번 이상, 다른 것보다 두 배 이상) B 그림을 기억하면
      t = A 시작 뒤 지난 시간 / 길이. 미리 돌린 D+1·D+2 에서 B 로 바뀌면 그때 t=1 이 되게 맞추고, 다른 포즈로 바뀌거나
      몸이 움직이면(기술·걷기) 안 한다.
   ③ 그리기: 몸 조각만 뺀 줄을 다시 그려(깊이·슬롯 그대로) 4배로 늘리고 그 위에 사이 그림을 원래 앞뒤 규칙대로 얹은
      «조각»을 만든다. 내보낼 때 화면 전체를 4배로 늘리고 조각을 붙인다(ngp_framegen_idle=draw 일 때만 4배 출력). */

#define ID_W      80            /* 몸 그림 틀 최대 폭·높이(원래 화소) */
#define ID_H      96
#define ID_POSES  24            /* 몸마다 기억할 포즈 그림 */
#define ID_PAIRS  12            /* 몸마다 기억할 (A,B) 이동표 */
#define ID_LEARN  48            /* 몸마다 배운 바뀜 */
#define ID_R      3             /* 이동 찾기 범위 ±px */
#define ID_S      4             /* 4배 */
#define ID_NONE   0xFFFF        /* 빈 화소(그림 값은 팔레트<<2 | 색 번호 = 0x3F 까지) */
#define ID_BIGP   16            /* 99f: 안 맞는 덩어리가 이만큼(화소) 되면 «부분이 멀리 감» — 캐시 항목이 있으면 캐시로 */

typedef struct id_pose_s {
   uint64_t sig; unsigned used;
   int ox, oy, w, h;            /* 몸 자리(물체 X·Y = 발 가운데) 기준 그림 왼쪽 위, 크기 */
   uint8_t depth, first;        /* 몸 조각의 우선순위<<1, 가장 앞(가장 작은) 슬롯 */
   uint16_t c[ID_W * ID_H];     /* 팔레트<<2 | 색 번호(1~3), ID_NONE = 빈 화소. 색값이 아니라 번호로 — 같은 포즈라도 팔레트가 바뀐다
                                   (고르기 화면↔대전, 색 고르기, 화면이 어두워지는 때) — 기억한 색으로 그리면 사이 그림만 다른 색이 된다 */
} id_pose;

typedef struct {
   uint64_t sa, sb; unsigned used;
   int ox, oy, w, h;            /* 둘을 합친 틀(몸 자리 기준) */
   int aox, aoy, box, boy;      /* 만들 때의 A·B 자리(몸 자리 기준 왼쪽 위) — 지금 기억한 포즈와 다르면 다시 만든다(패치 99e) */
   uint8_t depth, first, small;  /* small = 작은 바뀜(옮긴 앞 그림이 뒤 그림 화소를 75% 넘게 맞춤 — 서기처럼) */
   uint8_t bigp;                 /* 99f: 이동표로 안 맞는 화소의 가장 큰 덩어리(8방향)가 ID_BIGP 넘음 — 칼처럼 가는 부분이 ±3px 밖으로 감 */
   uint16_t ca[ID_W * ID_H], cb[ID_W * ID_H];
   int8_t dax[ID_W * ID_H], day[ID_W * ID_H];   /* A 화소가 B 쪽으로 갈 때의 이동(A 격자) */
   int8_t dbx[ID_W * ID_H], dby[ID_W * ID_H];   /* B 화소가 A 의 어디서 왔나: B(p) = A(p - d) (B 격자) */
} id_pair;

typedef struct { uint64_t sa, sb; unsigned seen; uint16_t hold; uint8_t cnt; } id_learn_t;
struct mc_ent;
typedef struct { int on; id_pair *pr; int t256, ax, ay;
                 int kind;                    /* 0 = 서기(배운 바뀜, id_pair) · 1 = 모션 캐시 */
                 struct mc_ent *e; int ti; const struct id_pose_s *A, *B;
                 int gx, gy, gw, gh, depth, first; /* 4배 조각 틀: 몸 자리 기준 왼쪽 위·크기(1배), 깊이, 첫 슬롯 */
                 int sx4, sy4;                /* 캐시 사이 그림을 더 미는 양(4배 화소) — 포즈 자리 어긋남을 t 만큼 나눠 메운다(패치 99c) */
               } id_req_t;
typedef struct { int on, x0, y0, w, h; uint16_t px[(ID_W * ID_S) * (ID_H * ID_S)]; } id_patch_t;

static id_pose    id_pose_c[2][ID_POSES];
static id_pair    id_pair_c[2][ID_PAIRS];
static id_learn_t id_lt[2][ID_LEARN];
static unsigned   id_clock = 0;
static uint64_t   id_cur[2], id_prev[2];     /* 지금 포즈, 그 앞 포즈(제자리에서 바뀐 때만 — 왕복 동작의 다음 포즈 고르기) */
static unsigned   id_start[2];
static unsigned   id_sp_at[2];    /* 99h: 이 머묾(id_start+1)에 뒤 포즈를 모른 채(K=0) 고르게 편 사이 그림(배운 바뀜·캐시)을 그렸나 */
static uint64_t   id_sp_b[2];     /* 99h: 그때 향한 뒤 포즈 — 실제로 온 뒤 포즈가 다르면(예측이 빗나감) 편 적 없는 것으로 */
static unsigned   id_hold_prev[2];  /* 99k: 바로 앞 포즈가 머문 프레임 수 */
static uint8_t    id_prev_link[2];  /* 99k: 앞 포즈 → 지금 포즈가 되풀이 동작(캐시 순환 표·배운 순환)의 한 걸음이었나 */
static uint8_t    id_prev_moved[2]; /* 99k: 앞 포즈 동안 몸이 움직였나(걷기) — 서기 순환은 장마다 길이가 달라(18·8·8…) 앞 걸음 길이를 안 쓴다 */
static int8_t     id_ti_last[2];    /* 99k: 이 머묾에서 마지막으로 낸 캐시 사이 그림 칸(-1 = 아직 없음, 0·1·2 = ¼·½·¾) */
static uint64_t   id_ti_sb[2];      /* 99k: 그때 향한 뒤 포즈 */
static unsigned   id_hold_prev2[2];  /* 99o: 그 앞 포즈가 머문 프레임 수 */
static uint8_t    id_prev_moved2[2]; /* 99o: 그 앞 포즈 동안 몸이 움직였나 */
static uint8_t    id_far_want[2];    /* 99o: 이번 D 에 D+3·D+4 로 뒤 포즈를 찾을 몸 */
static const ss2fg_frame *id_far[2]; /* 99o: 미리 더 돌린 D+3·D+4 (없으면 0) */
static uint64_t   id_far_sb[2];      /* 99o: D+3·D+4 로 찾아 펴기 시작한 뒤 포즈 */
static unsigned   id_far_st[2];      /* 99o: 그때 앞 포즈의 시작 프레임 */
static uint8_t    id_chv[2];         /* 99s: 몸의 캐릭터 번호(마지막으로 본 값) */
static uint64_t   id_prev2[2];       /* 99t: 그 앞 포즈(id_prev 의 앞) */
#define ID_CHAINS 32
static uint64_t   id_chs[2][ID_CHAINS];   /* 99t: 제자리 짧은 머묾 줄기에 든 포즈 — 다시 시작하면 D+3·D+4 를 본다 */
static unsigned   id_chu[2][ID_CHAINS];
#define PB_STEP 4                 /* 99v: 실제 프레임마다 더 돌릴 숨은 프레임 */
#define PB_MAX  48                /* 99v: D 에서 이만큼 앞까지 */
static struct {                   /* 99v: 멀리 미리 보기(대전 밖) */
   int on, found, p, input;
   uint64_t from, sb;             /* 머무는 포즈 · 찾은 뒤 포즈 */
   unsigned start, pos, at;       /* 머무는 포즈 시작 · 미리 본 마지막 프레임 · 뒤 포즈가 처음 나온 프레임(실제 프레임 번호) */
   int ax, ay;
   uint8_t ch;
   uint64_t done_from[2];         /* 이 머묾은 이미 찾아봄 */
   unsigned done_start[2];
   ss2fg_frame last, fk;          /* 미리 본 마지막 캡처(다음에 이어 돌릴 때 «직전») · 뒤 포즈가 나온 캡처 */
} pb;
static unsigned   id_cht[2];         /* 99s: 그 번호가 바뀐 프레임 */
static int        id_ax[2], id_ay[2], id_still[2];
static id_req_t   id_rq[2][2];               /* [출력 칸: 0 = τD, 1 = τD+½][몸] */
#define FX_N 3                       /* 99w: 출력 칸마다 이펙트 사이 그림 무리 */
#define ID_NR (2 + FX_N)
static id_patch_t id_pt[2][ID_NR];
static int        id_slot = -1;              /* 지금 그리는 출력 칸(ss2fg_render2 가 본다) */
static uint16_t   id_tc[(ID_W * ID_S) * (ID_H * ID_S)];
static uint16_t   id_la[(ID_W * ID_S) * (ID_H * ID_S)], id_lb[(ID_W * ID_S) * (ID_H * ID_S)];
static int        id_stats[6];               /* 계기: [0] 배운 바뀜 [1] 계획 [2] 패치 [3] 미리 본 다른 포즈 [4] 이동표 [5] 그림 */

void ss2fg_set_idle(int on)
{
   if (!on && id_on)
   {
      memset(id_cur, 0, sizeof id_cur);
      memset(id_prev, 0, sizeof id_prev);
      memset(id_rq, 0, sizeof id_rq);
      memset(id_sp_at, 0, sizeof id_sp_at);
      memset(id_sp_b, 0, sizeof id_sp_b);
      memset(id_hold_prev, 0, sizeof id_hold_prev); memset(id_prev_link, 0, sizeof id_prev_link); memset(id_prev_moved, 0, sizeof id_prev_moved);
      memset(id_hold_prev2, 0, sizeof id_hold_prev2); memset(id_prev_moved2, 0, sizeof id_prev_moved2); memset(id_far_want, 0, sizeof id_far_want);
      id_far[0] = id_far[1] = 0; memset(id_far_sb, 0, sizeof id_far_sb); memset(id_far_st, 0, sizeof id_far_st);
      memset(id_prev2, 0, sizeof id_prev2); memset(id_chs, 0, sizeof id_chs); memset(id_chu, 0, sizeof id_chu);   /* 99t */
      id_ti_last[0] = id_ti_last[1] = -1;
      { int q_; for (q_ = 0; q_ < ID_NR; q_++) id_pt[0][q_].on = id_pt[1][q_].on = 0; }
   }
   id_on = on ? 1 : 0;
}
int ss2fg_idle_on(void) { return id_on; }
void ss2fg_idle_slot(int s) { id_slot = s; }
void ss2fg_idle_stats(int *out6) { int i; for (i = 0; i < 6; i++) out6[i] = id_stats[i]; }

static id_pose *id_find_pose(int p, uint64_t sg)
{
   int i;
   for (i = 0; i < ID_POSES; i++) if (id_pose_c[p][i].sig == sg) { id_pose_c[p][i].used = ++id_clock; return &id_pose_c[p][i]; }
   return 0;
}

/* 몸 p 의 조각(마스크 m)을 몸 자리 기준 그림으로 — 슬롯 번호가 작은 조각이 앞(render_line 의 zbuf 규칙과 같음) */
static void id_capture(const ss2fg_frame *f, int p, const uint8_t *m, uint64_t sg)
{
   const ss2fg_regs *r = &f->line[0];
   int k, x0 = 9999, y0 = 9999, x1 = -9999, y1 = -9999, depth = -1, first = -1, i, oldest = 0;
   id_pose *ps;
   for (k = 0; k < 64; k++)
   {
      uint16_t w;
      int sx, sy, pr;
      if (!m[k]) continue;
      w = ld16(f->spr + k * 4);
      pr = (w & 0x1800) >> 11;
      if (depth < 0) { depth = pr << 1; first = k; }
      else if ((pr << 1) != depth) return;                    /* 우선순위가 섞인 몸 — 안 다룬다 */
      sx = wrapx(f->ax[k] + r->spx) - f->ob_x[p];
      sy = wrapc(f->ay[k] + r->spy) - f->ob_y[p];
      if (sx < x0) x0 = sx;
      if (sy < y0) y0 = sy;
      if (sx + 8 > x1) x1 = sx + 8;
      if (sy + 8 > y1) y1 = sy + 8;
   }
   if (depth <= 0 || x1 - x0 > ID_W || y1 - y0 > ID_H) return;
   for (i = 1; i < ID_POSES; i++) if (id_pose_c[p][i].used < id_pose_c[p][oldest].used) oldest = i;
   ps = &id_pose_c[p][oldest];
   ps->sig = sg; ps->used = ++id_clock;
   ps->ox = x0; ps->oy = y0; ps->w = x1 - x0; ps->h = y1 - y0;
   ps->depth = (uint8_t)depth; ps->first = (uint8_t)first;
   for (i = 0; i < ps->w * ps->h; i++) ps->c[i] = ID_NONE;
   for (k = 0; k < 64; k++)
   {
      uint16_t w;
      int sx, sy, row, col;
      unsigned tile;
      if (!m[k]) continue;
      w = ld16(f->spr + k * 4);
      tile = w & 0x01FF;
      sx = wrapx(f->ax[k] + r->spx) - f->ob_x[p] - x0;
      sy = wrapc(f->ay[k] + r->spy) - f->ob_y[p] - y0;
      for (row = 0; row < 8; row++)
      {
         unsigned rr = (w & 0x4000) ? 7 - row : row;
         int v = ld16(f->chr + tile * 16 + rr * 2);
         if (w & 0x8000) v = mirrored[(v & 0xff00) >> 8] | (mirrored[v & 0xff] << 8);
         for (col = 0; col < 8; col++)
         {
            int idx = (v >> (2 * (7 - col))) & 3, o;
            if (!idx) continue;
            o = (sy + row) * ps->w + sx + col;
            if (ps->c[o] != ID_NONE) continue;                 /* 앞 슬롯이 이미 칠함 */
            ps->c[o] = (uint16_t)(((f->sprcol[k] & 0xF) << 2) | idx);   /* 색은 그릴 때 그 프레임 팔레트로 */
         }
      }
   }
   id_stats[5]++;
}

static void id_learn_add(int p, uint64_t sa, uint64_t sb, unsigned hold)
{
   int i, lo = 0;
   for (i = 0; i < ID_LEARN; i++)
      if (id_lt[p][i].sa == sa && id_lt[p][i].sb == sb)
      {
         if (id_lt[p][i].cnt < 250) id_lt[p][i].cnt++;
         id_lt[p][i].hold = (uint16_t)hold;
         id_lt[p][i].seen = ++id_clock;
         id_stats[0]++;
         return;
      }
   /* 가장 오래 안 본 칸을 바꾼다. (예전: 횟수가 가장 적은 칸 — 표가 «2번 이상 본 바뀜»으로 다 차면 새 바뀜은 1번째에서
      서로 밀어내 영영 2번이 못 됐다 = 상대가 바뀌는 아케이드 몇 판 뒤·캐릭터를 바꾼 뒤 서기 그리기가 멈춤) */
   for (i = 1; i < ID_LEARN; i++) if (id_lt[p][i].seen < id_lt[p][lo].seen) lo = i;
   id_lt[p][lo].sa = sa; id_lt[p][lo].sb = sb; id_lt[p][lo].hold = (uint16_t)hold; id_lt[p][lo].cnt = 1;
   id_lt[p][lo].seen = ++id_clock;
   id_stats[0]++;
}
/* 99s: 방금 배운 바뀜 하나를 무른다(고르기 화면에서 캐릭터 번호가 그림보다 늦게 바뀐 때) */
static void id_unlearn(int p, uint64_t sa, uint64_t sb)
{
   int i;
   for (i = 0; i < ID_LEARN; i++)
      if (id_lt[p][i].sa == sa && id_lt[p][i].sb == sb && id_lt[p][i].cnt)
      {
         if (!--id_lt[p][i].cnt) id_lt[p][i].sa = id_lt[p][i].sb = 0;
         return;
      }
}
/* A 다음 포즈 — 같은 바뀜을 2번 이상 봤고 두 번째로 많은 것보다 두 배 이상일 때만. 그래도 못 정하면 방금 온 포즈(from)를 빼고
   다시 본다 — 왕복 동작의 가운데 포즈(우쿄 서기 57c3→f629→9621→f629→57c3: f629 다음은 온 쪽의 반대) */
static uint64_t id_next(int p, uint64_t sa, uint64_t from, unsigned *hold)
{
   int pass;
   for (pass = 0; pass < 2; pass++)
   {
      int i, b1 = -1, c2 = 0;
      if (pass && !from) break;
      for (i = 0; i < ID_LEARN; i++)
      {
         if (id_lt[p][i].sa != sa || !id_lt[p][i].cnt || (pass && id_lt[p][i].sb == from)) continue;
         if (b1 < 0 || id_lt[p][i].cnt > id_lt[p][b1].cnt) { if (b1 >= 0 && id_lt[p][b1].cnt > c2) c2 = id_lt[p][b1].cnt; b1 = i; }
         else if (id_lt[p][i].cnt > c2) c2 = id_lt[p][i].cnt;
      }
      if (b1 >= 0 && id_lt[p][b1].cnt >= 2 && id_lt[p][b1].cnt >= 2 * c2)
      {
         if (hold) *hold = id_lt[p][b1].hold;
         return id_lt[p][b1].sb;
      }
   }
   return 0;
}
/* A→B 가 되풀이 동작(서기처럼 같은 포즈들이 돈다)의 한 칸인가 — B 에서 배운 다음 포즈를 따라가 A 로 돌아오면 1.
   착지→서기·공격 끝 자세→서기처럼 한 번 지나가는 바뀜은 안 그린다 — 사이 그림은 반쯤에서 다음 그림으로 넘어가서 그 자세가
   끝나는 때가 앞당겨 보인다(서기는 돌기만 하니 상관없다). 하니스: 점프 착지 a944→3902(22 프레임)를 세 번째부터 그렸다 */
static int id_loop(int p, uint64_t sa, uint64_t sb)
{
   uint64_t from = sa, cur = sb;
   int n;
   for (n = 0; n < ID_POSES; n++)
   {
      uint64_t nx = id_next(p, cur, from, 0);
      if (!nx) return 0;
      if (nx == sa) return 1;
      from = cur; cur = nx;
   }
   return 0;
}

/* B 의 칠한 화소마다 A 에서 온 이동 d — 5×5 창에서 화소(빈칸 포함)가 다른 수 × 16 + 덜 움직인 쪽을 조금 선호 */
static void id_match(const uint16_t *ca, const uint16_t *cb, int w, int h, int8_t *dx, int8_t *dy)
{
   int x, y;
   for (y = 0; y < h; y++)
      for (x = 0; x < w; x++)
      {
         int best = 1 << 30, bx = 0, by = 0, ddx, ddy, i = y * w + x;
         dx[i] = dy[i] = 0;
         if (cb[i] == ID_NONE) continue;
         for (ddy = -ID_R; ddy <= ID_R; ddy++)
            for (ddx = -ID_R; ddx <= ID_R; ddx++)
            {
               int cost = (ddx < 0 ? -ddx : ddx) + (ddy < 0 ? -ddy : ddy), wx, wy;
               for (wy = -2; wy <= 2 && cost < best; wy++)
                  for (wx = -2; wx <= 2; wx++)
                  {
                     int qx = x + wx, qy = y + wy, ax2 = qx - ddx, ay2 = qy - ddy;
                     uint16_t vb = (qx >= 0 && qy >= 0 && qx < w && qy < h) ? cb[qy * w + qx] : ID_NONE;
                     uint16_t va = (ax2 >= 0 && ay2 >= 0 && ax2 < w && ay2 < h) ? ca[ay2 * w + ax2] : ID_NONE;
                     if (va != vb) cost += 16;
                  }
               if (cost < best) { best = cost; bx = ddx; by = ddy; }
            }
         dx[i] = (int8_t)bx; dy[i] = (int8_t)by;
      }
}
static int id_med(int *v, int n)
{
   int i, j, t;
   for (i = 1; i < n; i++) for (j = i; j > 0 && v[j] < v[j - 1]; j--) { t = v[j]; v[j] = v[j - 1]; v[j - 1] = t; }
   return v[n / 2];
}
/* 칠한 화소끼리 3×3 중앙값으로 두 번 다듬는다(외톨이 엉터리 이동 지우기) */
static void id_smooth(const uint16_t *c, int w, int h, int8_t *dx, int8_t *dy)
{
   static int8_t tx[ID_W * ID_H], ty[ID_W * ID_H];
   int it, x, y;
   for (it = 0; it < 2; it++)
   {
      for (y = 0; y < h; y++)
         for (x = 0; x < w; x++)
         {
            int vx[9], vy[9], n = 0, i = y * w + x, a, b;
            tx[i] = dx[i]; ty[i] = dy[i];
            if (c[i] == ID_NONE) continue;
            for (b = -1; b <= 1; b++)
               for (a = -1; a <= 1; a++)
               {
                  int qx = x + a, qy = y + b, j;
                  if (qx < 0 || qy < 0 || qx >= w || qy >= h) continue;
                  j = qy * w + qx;
                  if (c[j] == ID_NONE) continue;
                  vx[n] = dx[j]; vy[n] = dy[j]; n++;
               }
            tx[i] = (int8_t)id_med(vx, n); ty[i] = (int8_t)id_med(vy, n);
         }
      memcpy(dx, tx, (size_t)w * h); memcpy(dy, ty, (size_t)w * h);
   }
}

static id_pair *id_get_pair(int p, uint64_t sa, uint64_t sb)
{
   int i, oldest = 0, x, y;
   id_pose *A, *B;
   id_pair *pr;
   A = id_find_pose(p, sa); B = id_find_pose(p, sb);
   for (i = 0; i < ID_PAIRS; i++)
      if (id_pair_c[p][i].sa == sa && id_pair_c[p][i].sb == sb)
      {
         pr = &id_pair_c[p][i];
         /* 99e: 포즈가 밀려났다 다시 잡혔거나 장면이 바뀌어 자리·우선순위가 달라졌으면 옛 틀로 그리면 옆으로 밀린다 — 이 칸에 다시 만든다 */
         if (A && B && pr->aox == A->ox && pr->aoy == A->oy && pr->box == B->ox && pr->boy == B->oy && pr->depth == A->depth
             && B->depth == A->depth) { pr->used = ++id_clock; return pr; }
         pr->sa = pr->sb = 0; oldest = i; break;
      }
   if (!A || !B || A->depth != B->depth) return 0;
   if (i == ID_PAIRS)
      for (i = 1; i < ID_PAIRS; i++) if (id_pair_c[p][i].used < id_pair_c[p][oldest].used) oldest = i;
   pr = &id_pair_c[p][oldest];
   {
      int x0 = A->ox < B->ox ? A->ox : B->ox, y0 = A->oy < B->oy ? A->oy : B->oy;
      int x1 = A->ox + A->w > B->ox + B->w ? A->ox + A->w : B->ox + B->w;
      int y1 = A->oy + A->h > B->oy + B->h ? A->oy + A->h : B->oy + B->h;
      if (x1 - x0 > ID_W || y1 - y0 > ID_H) return 0;
      pr->ox = x0; pr->oy = y0; pr->w = x1 - x0; pr->h = y1 - y0;
      pr->aox = A->ox; pr->aoy = A->oy; pr->box = B->ox; pr->boy = B->oy;
   }
   pr->sa = sa; pr->sb = sb; pr->used = ++id_clock;
   pr->depth = A->depth; pr->first = A->first < B->first ? A->first : B->first;
   for (i = 0; i < pr->w * pr->h; i++) pr->ca[i] = pr->cb[i] = ID_NONE;
   for (y = 0; y < A->h; y++) for (x = 0; x < A->w; x++)
      pr->ca[(y + A->oy - pr->oy) * pr->w + x + A->ox - pr->ox] = A->c[y * A->w + x];
   for (y = 0; y < B->h; y++) for (x = 0; x < B->w; x++)
      pr->cb[(y + B->oy - pr->oy) * pr->w + x + B->ox - pr->ox] = B->c[y * B->w + x];
   id_match(pr->ca, pr->cb, pr->w, pr->h, pr->dbx, pr->dby);          /* B(p) = A(p - d) */
   id_smooth(pr->cb, pr->w, pr->h, pr->dbx, pr->dby);
   id_match(pr->cb, pr->ca, pr->w, pr->h, pr->dax, pr->day);          /* A(q) = B(q - e) → A 에서 B 로는 -e */
   id_smooth(pr->ca, pr->w, pr->h, pr->dax, pr->day);
   for (i = 0; i < pr->w * pr->h; i++) { pr->dax[i] = (int8_t)-pr->dax[i]; pr->day[i] = (int8_t)-pr->day[i]; }
   {  /* 작은 바뀜인가 — 이동표로 옮긴 앞 그림이 뒤 그림 화소를(거꾸로도) 75% 넘게 맞추면. 하니스 실측(하오마루 판):
         서기 바뀜 80~94%(칼이 크게 도는 것 포함), 착지→서기 65·59%, 공격 끝 자세→서기 60·54%, 공격 중 46~70% */
      int na = 0, ga = 0, nb = 0, gb = 0, sx, sy, q;
      for (y = 0; y < pr->h; y++)
         for (x = 0; x < pr->w; x++)
         {
            q = y * pr->w + x;
            if (pr->cb[q] != ID_NONE)
            {
               nb++; sx = x - pr->dbx[q]; sy = y - pr->dby[q];
               if (sx >= 0 && sy >= 0 && sx < pr->w && sy < pr->h && pr->ca[sy * pr->w + sx] == pr->cb[q]) gb++;
            }
            if (pr->ca[q] != ID_NONE)
            {
               na++; sx = x + pr->dax[q]; sy = y + pr->day[q];
               if (sx >= 0 && sy >= 0 && sx < pr->w && sy < pr->h && pr->cb[sy * pr->w + sx] == pr->ca[q]) ga++;
            }
         }
      pr->small = (uint8_t)(na && nb && ga * 4 >= na * 3 && gb * 4 >= nb * 3);
   }
   {  /* 99f: 작은 바뀜이라도(서기 80~94% 맞음) 칼·창처럼 가는 부분이 ±3px 밖으로 옮겨 가면 그 부분만 이동표가 못 따라가
         사이 그림에서 칼 가운데가 끊기거나 조각이 흩어진다(유저 2026-10-12 「하오마루 뉴트럴 칼 빈틈」 — 서기 8장 중 5바뀜, 덩어리 22~78).
         숨쉬기처럼 1~2px 움직임은 안 맞는 화소가 흩어져 덩어리가 작다(대전 제자리 바뀜 1,045개: 가운데 14, 칼 끊김 보인 것 19 이상).
         양쪽(B→A·A→B) 안 맞는 화소의 가장 큰 덩어리를 재어 둔다 — id_plan_learned 가 캐시 항목이 있으면 캐시에 맡긴다 */
      static uint8_t um[ID_W * ID_H];
      static int stk[ID_W * ID_H];
      int side, best = 0, n = pr->w * pr->h, q;
      for (side = 0; side < 2; side++)
      {
         for (q = 0; q < n; q++)
         {
            int xq = q % pr->w, yq = q / pr->w, sx, sy, ok;
            um[q] = 0;
            if (side == 0)
            {
               if (pr->cb[q] == ID_NONE) continue;
               sx = xq - pr->dbx[q]; sy = yq - pr->dby[q];
               ok = sx >= 0 && sy >= 0 && sx < pr->w && sy < pr->h && pr->ca[sy * pr->w + sx] == pr->cb[q];
            }
            else
            {
               if (pr->ca[q] == ID_NONE) continue;
               sx = xq + pr->dax[q]; sy = yq + pr->day[q];
               ok = sx >= 0 && sy >= 0 && sx < pr->w && sy < pr->h && pr->cb[sy * pr->w + sx] == pr->ca[q];
            }
            um[q] = (uint8_t)!ok;
         }
         for (q = 0; q < n; q++)
            if (um[q])
            {
               int sp = 0, cnt = 0;
               um[q] = 0; stk[sp++] = q;
               while (sp)
               {
                  int c = stk[--sp], cx = c % pr->w, cy = c / pr->w, a, b;
                  cnt++;
                  for (b = -1; b <= 1; b++)
                     for (a = -1; a <= 1; a++)
                     {
                        int nx = cx + a, ny = cy + b, j;
                        if (nx < 0 || ny < 0 || nx >= pr->w || ny >= pr->h) continue;
                        j = ny * pr->w + nx;
                        if (um[j]) { um[j] = 0; stk[sp++] = j; }
                     }
               }
               if (cnt > best) best = cnt;
            }
      }
      pr->bigp = (uint8_t)(best >= ID_BIGP);
   }
   id_stats[4]++;
   return pr;
}

static int id_rnd(int num)                     /* num / 256 반올림(음수 대칭) */
{
   return num >= 0 ? (num + 128) >> 8 : -((-num + 128) >> 8);
}
/* 사이 그림(4배 격자) — A 화소는 t·(A→B), B 화소는 (1−t)·(B→A) 만큼 옮겨 찍고, 반 넘으면 B 를 위로.
   위 그림의 «틈»(좌우나 위아래 양쪽 한 도트 안에 위 그림이 있는 빈칸)만 아래 그림으로 메운다 — 새 자리로 간 큰 부분은
   안 메워 두 번 보이지 않게 */
static void id_draw(const id_pair *pr, int t256, uint16_t *out)
{
   int W4 = pr->w * ID_S, H4 = pr->h * ID_S, x, y, n = W4 * H4, i;
   uint16_t *top, *und;
   for (i = 0; i < n; i++) id_la[i] = id_lb[i] = ID_NONE;
   for (y = 0; y < pr->h; y++)
      for (x = 0; x < pr->w; x++)
      {
         int q = y * pr->w + x, X, Y, a, b;
         if (pr->ca[q] != ID_NONE)
         {
            X = x * ID_S + id_rnd(ID_S * pr->dax[q] * t256); Y = y * ID_S + id_rnd(ID_S * pr->day[q] * t256);
            for (b = 0; b < ID_S; b++) for (a = 0; a < ID_S; a++)
               if (X + a >= 0 && Y + b >= 0 && X + a < W4 && Y + b < H4) id_la[(Y + b) * W4 + X + a] = pr->ca[q];
         }
         if (pr->cb[q] != ID_NONE)
         {
            X = x * ID_S - id_rnd(ID_S * pr->dbx[q] * (256 - t256)); Y = y * ID_S - id_rnd(ID_S * pr->dby[q] * (256 - t256));
            for (b = 0; b < ID_S; b++) for (a = 0; a < ID_S; a++)
               if (X + a >= 0 && Y + b >= 0 && X + a < W4 && Y + b < H4) id_lb[(Y + b) * W4 + X + a] = pr->cb[q];
         }
      }
   top = t256 < 128 ? id_la : id_lb; und = t256 < 128 ? id_lb : id_la;
   for (y = 0; y < H4; y++)
      for (x = 0; x < W4; x++)
      {
         int o = y * W4 + x, k, l = 0, r = 0, u = 0, d = 0;
         out[o] = top[o];
         if (top[o] != ID_NONE || und[o] == ID_NONE) continue;
         for (k = 1; k <= ID_S; k++)
         {
            if (x - k >= 0 && top[o - k] != ID_NONE) l = 1;
            if (x + k < W4 && top[o + k] != ID_NONE) r = 1;
            if (y - k >= 0 && top[o - k * W4] != ID_NONE) u = 1;
            if (y + k < H4 && top[o + k * W4] != ID_NONE) d = 1;
         }
         if ((l && r) || (u && d)) out[o] = und[o];
      }
}

/* ── 모션 캐시(코어 패치 97) — 공격 등 모든 포즈 바뀜의 사이 그림 ─────────────────────────────────────────────
   유저 2026-10-11 「전 모션 … 바로바로 어려우면 캐시 만들어서」·「어떤 방식으로 수행이 어려우면 캐시를 만들어서 업로드」.
   사이 그림은 미리(PC) AI 흐름(RIFE v4.6)으로 계산해 두고 여기서는 꺼내 붙이기만 한다. 파일(시스템 폴더 ss2_motion.bin)엔
   그림이 없다 — 바뀜(A→B)마다 t = ¼·½·¾ 의 «1배 칸마다 A 에서 가져올지 B 에서 가져올지 + 그 이동»뿐. 색은 지금 프레임의 그림·팔레트.
   B 는 미리 돌린 D+1·D+2 에서 안다 → 바뀌기 전 마지막 2 프레임(4 출력)에 ¼·½·¾ 를 그린다(길게 서 있는 자세는 끝에만 — 끝나는 때가 안 당겨짐).
   제자리 바뀜만(몸 자리가 그대로). 캐시에 없으면 예전처럼 툭. 형식은 tools/motion_cache.py 머리글. */
#include <stdio.h>
#include <zlib.h>
typedef struct { uint64_t sa, sb; uint32_t off, len; } mc_idx_t;
typedef struct mc_ent {
   uint64_t sa, sb; unsigned used;
   int8_t cx, cy, bdx, bdy; uint8_t w, h, aw, ah, bw, bh;
   uint32_t ro[3], mo[3], fo[3];        /* t 마다 칸 비트맵·A 고르기 비트맵·이동의 자리 */
   uint8_t *buf; uint32_t blen;
} mc_ent;
static FILE    *mc_f = 0;
static mc_idx_t *mc_ix = 0;
static uint32_t mc_n = 0;
/* 순환 표(패치 99b) — 모아 둔 판들에서 본 되풀이 동작(걷기·서기 등)의 «A 다음 B, 길이». 파일 끝 12바이트 'SS2L' u32 개수 u32 자리,
   항목 20바이트(u64 A, u64 B, u16 길이, u16 0), A 오름차순. 이걸로 배우기 전(그 판 처음 몇 걸음)부터 한 걸음 내내 편다 */
typedef struct { uint64_t sa, sb; uint16_t hold; } mc_loop_t;
static mc_loop_t *mc_lp = 0;
static uint32_t mc_ln = 0;
static int      mc_on = 0;
#define MC_CN 16                    /* 99w: 8 → 16 */
static mc_ent   mc_c[MC_CN];
static int      mc_stats[4];               /* [0] 찾음 [1] 있음 [2] 그림 [3] 틀 안 맞음 */
void ss2fg_set_motion(int on) { mc_on = on ? 1 : 0; }
int  ss2fg_motion_count(void) { return mc_f ? (int)mc_n : -1; }
void ss2fg_motion_stats(int *out4) { int i; for (i = 0; i < 4; i++) out4[i] = mc_stats[i]; }
static uint32_t mc_rd32(const uint8_t *p) { return (uint32_t)p[0] | ((uint32_t)p[1] << 8) | ((uint32_t)p[2] << 16) | ((uint32_t)p[3] << 24); }
static uint64_t mc_rd64(const uint8_t *p) { return (uint64_t)mc_rd32(p) | ((uint64_t)mc_rd32(p + 4) << 32); }
void ss2fg_motion_close(void)
{
   int i;
   if (mc_f) fclose(mc_f);
   mc_f = 0; free(mc_ix); mc_ix = 0; mc_n = 0;
   free(mc_lp); mc_lp = 0; mc_ln = 0;
   for (i = 0; i < MC_CN; i++) { free(mc_c[i].buf); memset(&mc_c[i], 0, sizeof mc_c[i]); }
}
/* 반환: 바뀜 수(0 이상), 없거나 틀리면 -1 */
int ss2fg_motion_open(const char *path)
{
   uint8_t hd[16], *ib;
   uint32_t n, i;
   ss2fg_motion_close();
   if (!path || !(mc_f = fopen(path, "rb"))) return -1;
   if (fread(hd, 1, 16, mc_f) != 16 || memcmp(hd, "SS2M", 4) || hd[4] != 2 || hd[6] != 3 || hd[7] != 64 || hd[8] != 128 || hd[9] != 192)
   { ss2fg_motion_close(); return -1; }
   n = mc_rd32(hd + 10);
   if (!n || n > 4000000u || !(ib = (uint8_t *)malloc((size_t)n * 24)) || !(mc_ix = (mc_idx_t *)malloc((size_t)n * sizeof *mc_ix)))
   { if (n) free(ib); ss2fg_motion_close(); return -1; }
   if (fread(ib, 24, n, mc_f) != n) { free(ib); ss2fg_motion_close(); return -1; }
   for (i = 0; i < n; i++)
   {
      mc_ix[i].sa = mc_rd64(ib + i * 24); mc_ix[i].sb = mc_rd64(ib + i * 24 + 8);
      mc_ix[i].off = mc_rd32(ib + i * 24 + 16); mc_ix[i].len = mc_rd32(ib + i * 24 + 20);
   }
   free(ib);
   mc_n = n;
   {  /* 순환 표(있으면) */
      uint8_t tr[12];
      if (!fseek(mc_f, -12, SEEK_END) && fread(tr, 1, 12, mc_f) == 12 && !memcmp(tr, "SS2L", 4))
      {
         uint32_t ln = mc_rd32(tr + 4), lo = mc_rd32(tr + 8);
         uint8_t *lb;
         if (ln && ln < 1000000u && (lb = (uint8_t *)malloc((size_t)ln * 20)) != 0)
         {
            if (!fseek(mc_f, (long)lo, SEEK_SET) && fread(lb, 20, ln, mc_f) == ln && (mc_lp = (mc_loop_t *)malloc((size_t)ln * sizeof *mc_lp)) != 0)
            {
               for (i = 0; i < ln; i++)
               {
                  mc_lp[i].sa = mc_rd64(lb + i * 20); mc_lp[i].sb = mc_rd64(lb + i * 20 + 8);
                  mc_lp[i].hold = (uint16_t)(lb[i * 20 + 16] | (lb[i * 20 + 17] << 8));
               }
               mc_ln = ln;
            }
            free(lb);
         }
      }
   }
   return (int)n;
}
/* 순환 표에서 A 다음 — 없으면 0 */
static uint64_t mc_loop_next(uint64_t sa, unsigned *hold)
{
   int lo = 0, hi = (int)mc_ln - 1;
   while (lo <= hi)
   {
      int mid = (lo + hi) >> 1;
      if (mc_lp[mid].sa == sa) { *hold = mc_lp[mid].hold; return mc_lp[mid].sb; }
      if (mc_lp[mid].sa < sa) lo = mid + 1; else hi = mid - 1;
   }
   return 0;
}
/* 99f: 캐시에 (sa, sb) 항목이 있나 — 색인만 본다(읽지 않음) */
static int mc_has(uint64_t sa, uint64_t sb)
{
   int lo = 0, hi = (int)mc_n - 1;
   if (!mc_on || !mc_f || !mc_ix) return 0;
   while (lo <= hi)
   {
      int mid = (lo + hi) >> 1;
      const mc_idx_t *x = &mc_ix[mid];
      if (x->sa == sa && x->sb == sb) return 1;
      if (x->sa < sa || (x->sa == sa && x->sb < sb)) lo = mid + 1; else hi = mid - 1;
   }
   return 0;
}
static mc_ent *mc_get(uint64_t sa, uint64_t sb)
{
   int lo = 0, hi = (int)mc_n - 1, i, old = 0;
   uint8_t *z = 0, *raw = 0;
   uLongf rl;
   uint32_t rawlen, at, t;
   mc_ent *e;
   if (!mc_f || !mc_ix) return 0;
   mc_stats[0]++;
   for (i = 0; i < MC_CN; i++)
      if (mc_c[i].buf && mc_c[i].sa == sa && mc_c[i].sb == sb) { mc_c[i].used = ++id_clock; return &mc_c[i]; }
   while (lo <= hi)
   {
      int mid = (lo + hi) >> 1;
      const mc_idx_t *x = &mc_ix[mid];
      if (x->sa == sa && x->sb == sb) { lo = mid; break; }
      if (x->sa < sa || (x->sa == sa && x->sb < sb)) lo = mid + 1; else hi = mid - 1;
   }
   if (lo > hi || lo >= (int)mc_n || mc_ix[lo].sa != sa || mc_ix[lo].sb != sb) return 0;
   mc_stats[1]++;
   if (mc_ix[lo].len < 8 || mc_ix[lo].len > (1u << 22) || fseek(mc_f, (long)mc_ix[lo].off, SEEK_SET)) return 0;
   z = (uint8_t *)malloc(mc_ix[lo].len);
   if (!z || fread(z, 1, mc_ix[lo].len, mc_f) != mc_ix[lo].len) { free(z); return 0; }
   rawlen = mc_rd32(z);
   if (rawlen < 10 || rawlen > (1u << 22) || !(raw = (uint8_t *)malloc(rawlen))) { free(z); return 0; }
   rl = rawlen;
   if (uncompress(raw, &rl, z + 4, mc_ix[lo].len - 4) != Z_OK || rl != rawlen) { free(z); free(raw); return 0; }
   free(z);
   for (i = 1; i < MC_CN; i++) if (mc_c[i].used < mc_c[old].used) old = i;
   e = &mc_c[old];
   free(e->buf);
   memset(e, 0, sizeof *e);
   e->sa = sa; e->sb = sb; e->used = ++id_clock;
   e->cx = (int8_t)raw[0]; e->cy = (int8_t)raw[1]; e->w = raw[2]; e->h = raw[3];
   e->bdx = (int8_t)raw[4]; e->bdy = (int8_t)raw[5]; e->aw = raw[6]; e->ah = raw[7]; e->bw = raw[8]; e->bh = raw[9];
   at = 10;
   for (t = 0; t < 3; t++)
   {
      uint32_t n, rb = ((uint32_t)e->w * e->h + 7) >> 3;
      if (at + 2 > rawlen) { free(raw); e->buf = 0; return 0; }
      n = (uint32_t)raw[at] | ((uint32_t)raw[at + 1] << 8);
      e->ro[t] = at + 2; e->mo[t] = e->ro[t] + rb; e->fo[t] = e->mo[t] + ((n + 7) >> 3);
      at = e->fo[t] + n * 2;
      if (at > rawlen) { free(raw); e->buf = 0; return 0; }
      {  /* 칸 비트 수 = n 이어야(패치 99c) — 아니면 mc_draw 가 이동값 뒤를 넘어 읽는다(일부러 만든 파일만 — zlib 검사합이 우연한 깨짐은 막는다) */
         uint32_t c, cnt = 0, nb = (uint32_t)e->w * e->h;
         for (c = 0; c < nb; c++) cnt += (raw[e->ro[t] + (c >> 3)] >> (c & 7)) & 1;
         if (cnt != n) { free(raw); e->buf = 0; return 0; }
      }
   }
   e->buf = raw; e->blen = rawlen;
   return e;
}
static int mc_fdiv(int a) { return a >= 0 ? a / ID_S : -((-a + ID_S - 1) / ID_S); }
/* 캐시 사이 그림(4배 틀) — 칸마다 저장된 이동으로 A 나 B 의 그림 화소(팔레트·색 번호)를 그대로 가져온다 */
static void mc_draw(const mc_ent *e, int ti, const id_pose *A, const id_pose *B, uint16_t *out)
{
   int W4 = e->w * ID_S, x, y, a, b, idx = 0;
   uint8_t cfx = 0, cfy = 0;                       /* 이동은 앞 칸과의 차로 저장 — 누적(mod 256) */
   const uint8_t *reg = e->buf + e->ro[ti], *msk = e->buf + e->mo[ti];
   const uint8_t *fl = e->buf + e->fo[ti];
   for (y = 0; y < e->h; y++)
      for (x = 0; x < e->w; x++)
      {
         int c = y * e->w + x, i, useA, fx, fy, ox, oy;
         const id_pose *P;
         if (!((reg[c >> 3] >> (c & 7)) & 1))
         {
            for (b = 0; b < ID_S; b++) for (a = 0; a < ID_S; a++) out[(y * ID_S + b) * W4 + x * ID_S + a] = ID_NONE;
            continue;
         }
         i = idx++;
         useA = (msk[i >> 3] >> (i & 7)) & 1;
         cfx = (uint8_t)(cfx + fl[i * 2]); cfy = (uint8_t)(cfy + fl[i * 2 + 1]);
         fx = (int8_t)cfx; fy = (int8_t)cfy;
         P = useA ? A : B;
         ox = useA ? e->cx : e->cx - e->bdx; oy = useA ? e->cy : e->cy - e->bdy;     /* 틀 → P 그림 좌표 */
         for (b = 0; b < ID_S; b++)
            for (a = 0; a < ID_S; a++)
            {
               int sx = mc_fdiv(x * ID_S + a + fx) + ox, sy = mc_fdiv(y * ID_S + b + fy) + oy;
               uint16_t v = ID_NONE;
               if (sx >= 0 && sy >= 0 && sx < P->w && sy < P->h) v = P->c[sy * P->w + sx];
               out[(y * ID_S + b) * W4 + x * ID_S + a] = v;
            }
      }
}
/* 몸 p 의 그림 왼쪽 위(몸 조각 최소 − 물체 자리) — 포즈 그림(id_capture)과 같은 셈. 몸이 없으면 0 */
static int mc_top_left(const ss2fg_frame *f, int p, int *x, int *y)
{
   uint8_t m[64];
   int k, x0 = 9999, y0 = 9999;
   if (!f || !f->body_ok || !body_mask(f, p, m)) return 0;
   for (k = 0; k < 64; k++)
      if (m[k])
      {
         int sx = wrapx(f->ax[k] + f->line[0].spx) - f->ob_x[p], sy = wrapc(f->ay[k] + f->line[0].spy) - f->ob_y[p];
         if (sx < x0) x0 = sx;
         if (sy < y0) y0 = sy;
      }
   if (x0 == 9999) return 0;
   *x = x0; *y = y0;
   return 1;
}
/* 출력 칸 slot 의 몸 p — D+1·D+2 에서 포즈가 바뀌면(제자리) 캐시로. 1 = 계획함 */
static void id_realign(const ss2fg_frame *f, int p, uint64_t sg);
static int mc_plan(const ss2fg_frame *f0, const ss2fg_frame *f1, const ss2fg_frame *f2, unsigned realn, int h, int slot, int p)
{
   uint8_t mm[64];
   uint64_t sb = 0;
   int k, K = 0, L, num, ti, seen34 = 0;
   const ss2fg_frame *fk = 0;
   mc_ent *e;
   id_pose *A, *B;
   id_req_t *rq = &id_rq[slot][p];
   if (!mc_on || !mc_f || !id_cur[p]) return 0;
   for (k = 1; k <= 2; k++)
   {
      const ss2fg_frame *g = k == 1 ? f1 : f2;
      uint64_t sg;
      if (!g || !g->valid || g->mono || !g->body_ok || !body_mask(g, p, mm)) return 0;
      sg = body_sig(g, mm);
      if (sg != id_cur[p]) { sb = sg; K = k; fk = g; break; }
   }
   if (!K && id_far_want[p] && id_far[0])
   {  /* 99o: 2 프레임 더 미리 돌린 D+3·D+4 — 제자리 그대로 다른 포즈가 보이면 그때까지 고르게 편다 */
      for (k = 3; k <= 4; k++)
      {
         const ss2fg_frame *g = id_far[k - 3];
         uint64_t sg;
         if (!g || !g->valid || g->mono || !g->body_ok || !body_mask(g, p, mm)) break;
         if (g->ob_x[p] != id_ax[p] || g->ob_y[p] != id_ay[p]) break;      /* 움직이기 시작 — 아님 */
         sg = body_sig(g, mm);
         if (sg != id_cur[p]) { sb = sg; K = k; fk = g; seen34 = 1; break; }
      }
   }
   if (!K && !f0->fight && pb.found && pb.p == p && pb.from == id_cur[p] && pb.start == id_start[p] && pb.at > realn + 2u && pb.at - realn <= (unsigned)PB_MAX
       && body_mask(&pb.fk, p, mm))
   {  /* 99v: 대전 밖 멀리 미리 보기로 찾은 뒤 포즈 — 바뀔 때까지의 실제 길이로 고르게(99o 와 같은 길) */
      sb = pb.sb; K = (int)(pb.at - realn); fk = &pb.fk; seen34 = 1;
   }
   if (f0->pick && (K ? (fk->ch[p] != f0->ch[p] || fk->ch_now[p] != f0->ch[p]) : f0->pick == 2)) return 0;   /* 99s: 고르기 화면 — 배운 바뀜(id_plan_learned)과 같다 */
   /* 되풀이 동작(배운 순환 — 걷기 등): 다음 포즈를 미리 알면 사이 그림을 한 걸음 내내 고르게 편다(패치 99).
      바뀌기 직전 2 프레임에만 몰면, 걷기는 몸은 120Hz 로 매끄럽게 가는데 다리는 6 프레임 멈춰 미끄러지듯 보였다
      (유저 「앞으로 올 때 슬라이딩하는 것처럼 보일 때가 있다」). t = 지난 시간/길이 → ¼·½·¾ 중 가까운 칸(⅛ 전엔 A 그대로).
      미리 돌린 D+1·D+2 가 다른 포즈면 순환이 아닌 것으로 — 아래 «마지막 2 프레임» 으로 그 포즈를 향한다 */
   {
      unsigned hold = 0;
      uint64_t nb = id_next(p, id_cur[p], id_prev[p], &hold);
      int loop = nb && hold >= 3 && hold <= 60 && id_loop(p, id_cur[p], nb) && (!K || sb == nb);
      if (!loop && mc_ln)
      {  /* 아직 못 배웠으면 캐시의 순환 표로(패치 99b) */
         unsigned h2 = 0;
         uint64_t cb = mc_loop_next(id_cur[p], &h2);
         if (cb && h2 >= 3 && h2 <= 60 && (!K || sb == cb)) { nb = cb; hold = h2; loop = 1; }
      }
      /* 99k: 걸음 길이는 바로 앞 걸음 것으로 — 캐시 순환 표·배운 길이는 모아 둔 판의 대표값이라 지금 걷는 빠르기와 다를 수 있다
         (갈포드 앞으로 걷기: 표 14 프레임, 실제 6 — 걸음은 장마다 길이가 같다). 길게 잡으면 다리가 ¼ 에서 멈춰 있다가, 바뀔 때가 보이면(미리 돌린 D+1·D+2)
         ¾ 로 툭 건너뛰었다 — 몸은 ¼ px 로 매끄럽게 가니(99i) 더 눈에 띔(유저 2026-10-14 「걷는 거 또 찐빠 난 거 같은데」) */
      if (loop && id_prev_link[p] && id_prev_moved[p] && id_hold_prev[p] >= 3 && id_hold_prev[p] <= 60) hold = id_hold_prev[p];
      /* 99o: D+3·D+4 로 뒤 포즈를 봤으면(또는 그렇게 펴던 뒤 포즈가 이제 D+1·D+2 에 보이면) 바뀔 때까지의 실제 길이로 고르게 */
      if (seen34) { nb = sb; hold = realn + (unsigned)K - id_start[p]; loop = 1; }
      else if (K && id_far_sb[p] == sb && id_far_st[p] == id_start[p] && id_ti_last[p] >= 0 && id_ti_sb[p] == sb)
      { nb = sb; hold = realn + (unsigned)K - id_start[p]; loop = 1; seen34 = 1; }
      if (loop && (K ? 2 * (int)(realn + (unsigned)K - id_start[p]) : 2 * (int)(realn - id_start[p]) + 6) > 2 * (int)hold + 4
          && !(K && id_ti_last[p] >= 0 && id_ti_sb[p] == sb))   /* 99k: 같은 뒤 포즈로 펴던 중 바뀜이 보이면 이어서(¼ 로 되돌아가지 않게) */
         loop = 0;                     /* 99e: 배운 길이보다 오래 머묾 — 순환이 아니라 붙잡은 자세. 바뀌기 직전 2 프레임만(아래).
                                          99h: 길이는 바뀔 때를 알면 실제 길이, 모르면 가장 짧은 길이(D+2 까진 안 바뀜 — 3 프레임 더).
                                          예전엔 출력 반 칸(h)까지 더 쳐서, 배운 길이보다 1 프레임 길게 머문 걸음이 마지막에 ¾ → ¼ 로 뒤로 갔다 */
      /* 99h: 뒤 포즈를 아직 한 번도 못 봐(기억에 없음) 앞 포즈가 보이는 동안 고르게 펴지 못했으면, 뒤 포즈가 미리 돌린 D+1·D+2 에
         보일 때 t 가 이미 끝 쪽이라 ¾ 한 장만 4 칸 내내 나왔다(¼·½ 없이 툭 — 유저 2026-10-13 「수라·나찰 고르기 화면·판 시작 전 «いざ尋常に»
         에서 120 이 제대로 안 되는 듯」: 미리보기·소개는 처음 보는 포즈가 많다). 그럴 땐 순환이 아닌 바뀜처럼 바뀌기 직전 2 프레임에 ¼·½·¾ */
      if (loop && K && !seen34 && (id_sp_at[p] != id_start[p] + 1u || id_sp_b[p] != sb))
         loop = 0;
      if (!K && !loop) return 0;
      if (loop)
      {
         int e2 = 2 * (int)(realn - id_start[p]) + h, tot2;
         if (!K) sb = nb;
         tot2 = K ? 2 * (int)(realn + (unsigned)K - id_start[p]) : 2 * (int)hold;
         if (!K && tot2 < e2 + 6) tot2 = e2 + 6;                                 /* D+2 까진 안 바뀜 — 적어도 3 프레임 남음 */
         if (tot2 <= 0 || e2 < 0) return 0;
         ti = (8 * e2 + tot2) / (2 * tot2) - 1;                                   /* round(4t) − 1 */
         if (!K && tot2 >= 20) ti = 3 * e2 / (tot2 - 4) - 1;                      /* 99u: 긴 머묾 — 바뀜이 보이기 전 시간을 셋으로(앞·¼·½) */
         if (ti > 2) ti = 2;
         if (!K && ti > 1) ti = 1;   /* 99k: 바뀔 때가 안 보이면(미리 돌린 D+1·D+2 에 아직 없음) ½ 까지만 — ¾ 는 바뀜이 보인 마지막 2 프레임에.
                                        길이가 맞으면 원래도 ¾ 는 그 2 프레임이라 같고, 빗나가 오래 머물면(걷다 미끄러지며 포즈만 멈춤 등)
                                        ¾ 에서 앞 포즈로 툭 돌아가던 것이 ½ 에서로 준다 */
         if (id_ti_last[p] >= 0)
         {  /* 99k: 한 걸음 안에서는 뒤로 가지 않고 한 칸씩만 — 길이 추정이 빗나가도 ¼ → ½ → ¾ 를 건너뛰지 않는다 */
            if (ti < id_ti_last[p]) ti = id_ti_last[p];
            if (ti > id_ti_last[p] + 1) ti = id_ti_last[p] + 1;
         }
         if (ti < 0) return 0;
      }
      else
      {
         L = (int)(realn + (unsigned)K - id_start[p]);                            /* A 가 보이는 프레임 수(바뀔 때까지) */
         if (L > 2) L = 2;
         if (L < 1) return 0;
         num = 2 * L - (2 * K - h);                                               /* t = num / (2L) */
         if (num <= 0) return 0;
         ti = L == 2 ? num - 1 : 1;                                               /* ¼·½·¾ 칸 */
         if (ti < 0 || ti > 2) return 0;
      }
   }
   e = mc_get(id_cur[p], sb);
   if (!e) return 0;
   A = id_find_pose(p, id_cur[p]);
   B = id_find_pose(p, sb);
   if (!B && fk) { id_capture(fk, p, mm, sb); B = id_find_pose(p, sb); }
   else if (B && fk) id_realign(fk, p, sb);                    /* 뒤 포즈가 다른 장면에서 잡힌 것이면 지금 것으로(99e) */
   else if (A && B && B->depth != A->depth) B->depth = A->depth; /* 아직 안 보인 뒤 포즈의 우선순위는 지금 장면(A) 것으로(99e) */
   if (!A || !B || A->depth != B->depth || A->w != e->aw || A->h != e->ah || B->w != e->bw || B->h != e->bh) { mc_stats[3]++; return 0; }
   {  /* 자리(패치 99c) — 전엔 기억한 두 포즈의 «물체 자리 기준 왼쪽 위» 차가 캐시의 B 자리(bdx·bdy)와 한 픽셀이라도 다르면 버렸다.
         물체 자리(RAM)와 스프라이트가 움직일 때 한 박자 어긋나 같은 포즈라도 잡힌 때마다 1~3 픽셀 달라, 바뀜의 10% 가 사이 그림 없이 툭 바뀌었다(검수 2026-10-11).
         이제 A 는 지금 D 의 실제 자리에 놓고, B 는 D+K 의 실제 자리(K 를 모르는 되풀이 동작은 기억한 자리)와 캐시 자리의 차를 t 만큼 나눠 밀어 메운다.
         차가 4 픽셀을 넘으면 다른 상황으로 보고 예전처럼 툭 */
      int ax0, ay0, bx0, by0, rbx, rby, dx, dy;
      if (!mc_top_left(f0, p, &ax0, &ay0)) { ax0 = A->ox; ay0 = A->oy; }
      if (fk && mc_top_left(fk, p, &bx0, &by0)) { rbx = bx0 - ax0; rby = by0 - ay0; }
      else { rbx = B->ox - A->ox; rby = B->oy - A->oy; }
      dx = rbx - e->bdx; dy = rby - e->bdy;
      if (dx < -4 || dx > 4 || dy < -4 || dy > 4) { mc_stats[3]++; return 0; }
      rq->gx = ax0 + e->cx; rq->gy = ay0 + e->cy;
      rq->sx4 = (ti + 1) * dx; rq->sy4 = (ti + 1) * dy;   /* t = (ti+1)/4 → 4배 화소로 t·차·4 */
   }
   if (!K) { id_sp_at[p] = id_start[p] + 1u; id_sp_b[p] = sb; }   /* 99h: K 를 모르는데 그린다 = 순환으로 고르게 펴는 중 */
   id_ti_last[p] = (int8_t)ti; id_ti_sb[p] = sb;                   /* 99k */
   if (seen34) { id_far_sb[p] = sb; id_far_st[p] = id_start[p]; }    /* 99o */
   rq->on = 1; rq->kind = 1; rq->pr = 0; rq->t256 = 64 * (ti + 1);
   rq->e = e; rq->ti = ti; rq->A = A; rq->B = B;
   rq->ax = f0->ob_x[p]; rq->ay = f0->ob_y[p];              /* 몸 자리는 보여 줄 D 의 것 — 움직이는 몸은 그리기에서 몸 조각의 옮김만큼 더 민다(패치 98) */
   rq->gw = e->w; rq->gh = e->h;
   rq->depth = A->depth; rq->first = A->first < B->first ? A->first : B->first;
   return 1;
}

/* 99v: 멀리 미리 보기 */
static void probe_clear(void) { pb.on = pb.found = 0; pb.done_from[0] = pb.done_from[1] = 0; }
void ss2fg_probe_reset(void) { pb.on = pb.found = 0; }
static void probe_check(const ss2fg_frame *f)
{
   uint8_t mm[64];
   uint64_t s;
   pb.pos++;
   if (!pb.on || pb.found) return;
   if (!f->valid || f->mono || !f->body_ok || !body_mask(f, pb.p, mm)) { pb.on = 0; return; }      /* 몸이 없어짐 */
   if (f->ob_x[pb.p] != pb.ax || f->ob_y[pb.p] != pb.ay || f->ch[pb.p] != pb.ch) { pb.on = 0; return; }   /* 움직이기 시작·캐릭터 바뀜 */
   s = body_sig(f, mm);
   if (s != pb.from) { pb.found = 1; pb.on = 0; pb.sb = s; pb.at = pb.pos; pb.fk = *f; }
}
int ss2fg_probe_want(const ss2fg_frame *f0, const ss2fg_frame *f1, const ss2fg_frame *f2, unsigned realn, int input)
{
   int p;
   if (!id_on || !mc_on || !mc_f || !f0 || !f0->valid || f0->mono || !f0->body_ok || f0->fight) { pb.on = pb.found = 0; return 0; }
   if ((pb.on || pb.found) && (input != pb.input || id_cur[pb.p] != pb.from || id_start[pb.p] != pb.start)) pb.on = pb.found = 0;
   if (pb.found) return 0;
   if (pb.on)
   {
      if (pb.pos - realn >= (unsigned)PB_MAX) { pb.on = 0; return 0; }
      return 1;
   }
   for (p = 0; p < 2; p++)
   {
      uint8_t mm[64];
      int k, same = 1;
      if (!id_cur[p] || !id_still[p] || f0->ob_x[p] != id_ax[p] || f0->ob_y[p] != id_ay[p]) continue;
      if (pb.done_from[p] == id_cur[p] && pb.done_start[p] == id_start[p]) continue;
      for (k = 1; k <= 2 && same; k++)
      {
         const ss2fg_frame *g = k == 1 ? f1 : f2;
         if (!g || !g->valid || g->mono || !g->body_ok || !body_mask(g, p, mm) || g->ob_x[p] != id_ax[p] || g->ob_y[p] != id_ay[p]
             || body_sig(g, mm) != id_cur[p]) same = 0;
      }
      if (!same) continue;                                   /* 바뀜이 이미 보임 */
      pb.p = p; pb.from = id_cur[p]; pb.start = id_start[p]; pb.ax = id_ax[p]; pb.ay = id_ay[p]; pb.ch = f0->ch[p]; pb.input = input;
      pb.done_from[p] = id_cur[p]; pb.done_start[p] = id_start[p];
      pb.found = 0;
      return 2;
   }
   return 0;
}
void ss2fg_probe_started(unsigned pos, const ss2fg_frame *last)
{
   if (!last || !last->valid) { pb.on = 0; return; }
   pb.on = 1; pb.found = 0; pb.pos = pos; pb.last = *last;
}
void ss2fg_probe_begin(void)
{
   fg_pb_sbuild = fg_build; fg_pb_sdirty = fg_build_dirty;
   fg_slot[FG_RING] = pb.last;
   fg_pb_prev = FG_RING;
   fg_build = FG_RING + 1;
   memcpy(fg_slot[fg_build].line, pb.last.line, sizeof pb.last.line);
   fg_build_dirty = 0;
   fg_pb_mode = 1;
}
void ss2fg_probe_end(void)
{
   if (fg_pb_prev >= 0) pb.last = fg_slot[fg_pb_prev];
   fg_pb_mode = 0; fg_pb_prev = -1;
   fg_build = fg_pb_sbuild; fg_build_dirty = fg_pb_sdirty;
}
int ss2fg_probe_more(void) { return pb.on && !pb.found; }

/* 99t: 제자리 짧은 머묾 줄기 기억 */
static void id_chain_mark(int p, uint64_t s)
{
   int i, lo = 0;
   if (!s) return;
   for (i = 0; i < ID_CHAINS; i++) if (id_chs[p][i] == s) { id_chu[p][i] = ++id_clock; return; }
   for (i = 1; i < ID_CHAINS; i++) if (id_chu[p][i] < id_chu[p][lo]) lo = i;
   id_chs[p][lo] = s; id_chu[p][lo] = ++id_clock;
}
static int id_chain_has(int p, uint64_t s)
{
   int i;
   if (!s) return 0;
   for (i = 0; i < ID_CHAINS; i++) if (id_chs[p][i] == s) return 1;
   return 0;
}
static int id_is_loop(int p, uint64_t s)
{
   unsigned h = 0;
   uint64_t n;
   if (mc_ln && mc_loop_next(s, &h)) return 1;
   n = id_next(p, s, 0, 0);
   return n && id_loop(p, s, n);
}

/* 99o: 판 끝 승리 포즈(10장 안팎)·필살기(12장)·등장 연출은 제자리에서 포즈를 4 프레임씩 넘긴다. 뒤 포즈는 미리 돌린 D+2 에야
   보여 바뀌기 직전 2 프레임에만 ¼·½·¾ 를 몰았다(120Hz 여덟 칸 중 «-----¼½¾» — 유저 2026-10-14 「게임 끝나고도 적용 안 되는 거 같고」).
   앞 두 포즈가 제자리에서 3~5(그 앞은 6까지) 프레임씩 바뀌었고 지금 포즈도 제자리에서 막(2 프레임 안) 시작했는데 D+1·D+2 에
   아직 안 바뀌면 2 프레임 더(D+3·D+4) 미리 돌려 뒤 포즈를 일찍 본다 → 머묾 내내 «-¼¼½½¾¾¾». 그동안만 숨은 프레임 6 장(몸 박자의
   «2 프레임 더»와 같은 길). 맞고 멈춤(히트스톱)처럼 길게 붙잡는 자세는 D+4 안에 안 바뀌어 안 건드린다 */
int ss2fg_idle_want_far(const ss2fg_frame *f0, const ss2fg_frame *f1, const ss2fg_frame *f2, unsigned realn)
{
   int p, want = 0;
   id_far_want[0] = id_far_want[1] = 0;
   if (!id_on || !mc_on || !mc_f || !f0 || !f0->valid || f0->mono || !f0->body_ok) return 0;
   for (p = 0; p < 2; p++)
   {
      uint8_t mm[64];
      int k, same = 1;
      if (!id_cur[p] || !id_still[p] || realn - id_start[p] > 2) continue;
      if (!id_chain_has(p, id_cur[p]))   /* 99t: 전에 제자리 짧은 머묾 줄기에서 본 포즈면 앞 두 포즈를 안 봐도(승리 포즈 첫 두 장) */
      {
         if (id_hold_prev[p] < 3 || id_hold_prev[p] > 5 || id_prev_moved[p]) continue;
         if (id_hold_prev2[p] < 3 || id_hold_prev2[p] > 6 || id_prev_moved2[p]) continue;
      }
      if (f0->ob_x[p] != id_ax[p] || f0->ob_y[p] != id_ay[p]) continue;
      for (k = 1; k <= 2 && same; k++)
      {
         const ss2fg_frame *g = k == 1 ? f1 : f2;
         if (!g || !g->valid || g->mono || !g->body_ok || !body_mask(g, p, mm)) { same = 0; break; }
         if (g->ob_x[p] != id_ax[p] || g->ob_y[p] != id_ay[p] || body_sig(g, mm) != id_cur[p]) same = 0;
      }
      if (!same) continue;
      id_far_want[p] = 1; want = 1;
   }
   return want;
}
void ss2fg_idle_far(const ss2fg_frame *f3, const ss2fg_frame *f4) { id_far[0] = f3; id_far[1] = f4; }

/* 실제 프레임마다(보여 줄 D) — 포즈 그림 기억 + 제자리 바뀜 배우기 */
/* 포즈 맞춤(패치 99e) — 같은 포즈(지문)라도 장면·동작마다 물체 자리(RAM X·Y)와 그림 사이(왼쪽 위)와 스프라이트 우선순위가 다르다
   (고르기 화면 미리보기·판 시작 «승부»·대전·공격 끝 자세 등). 기억한 포즈는 처음 잡은 장면 것을 계속 써서
   ① 다른 장면에서 배운 서기 사이 그림이 그만큼 옆으로 그려졌다 — 조각 틀 밖에 남은 진짜 몸과 겹쳐 «몸이 둘»
   ② 앞·뒤 포즈의 우선순위가 달라 보여(한쪽은 이 장면, 한쪽은 다른 장면 것) 캐시·배운 바뀜 모두 «안 맞음»으로 건너뜀 — 고르기 화면에서 되다 안 되다
   (유저 2026-10-12 「뉴트럴에서 … 이러기도 함」·「캐릭 선택창에는 적용이 되다 안 되다」). 지금 몸 조각에서 다시 재 기억을 고친다 —
   그 포즈가 든 배운 바뀜은 id_get_pair 가 자리·우선순위가 다른 걸 보고 다시 만든다. */
static void id_realign(const ss2fg_frame *f, int p, uint64_t sg)
{
   id_pose *P = id_find_pose(p, sg);
   uint8_t m[64];
   int x, y, k, depth = -1;
   if (!P || !body_mask(f, p, m) || !mc_top_left(f, p, &x, &y)) return;
   for (k = 0; k < 64; k++)
      if (m[k])
      {
         int pr = (ld16(f->spr + k * 4) & 0x1800) >> 11;
         if (depth < 0) depth = pr << 1;
         else if ((pr << 1) != depth) return;                    /* 우선순위가 섞인 몸 — 그대로 둔다 */
      }
   /* 가장 앞 슬롯(first)은 프레임마다 바뀌어(스프라이트 칸 배정) 맞추지 않는다 — 자리·우선순위만 */
   if (depth <= 0 || (x == P->ox && y == P->oy && depth == P->depth)) return;
   P->ox = x; P->oy = y; P->depth = (uint8_t)depth;
}

void ss2fg_idle_observe(const ss2fg_frame *f, unsigned realn)
{
   int p;
   if (!id_on || !f || !f->valid || f->mono) return;
   for (p = 0; p < 2; p++)
   {
      uint8_t m[64];
      uint64_t sg;
      int ax, ay;
      int sw, chg = 0;
      if (!body_mask(f, p, m)) { id_cur[p] = id_prev[p] = 0; continue; }
      sg = body_sig(f, m);
      ax = f->ob_x[p]; ay = f->ob_y[p];
      if (!id_find_pose(p, sg)) id_capture(f, p, m, sg);
      else id_realign(f, p, sg);
      /* 99s: 고르기 화면 — 미리보기 몸 하나(물체 0)가 커서 따라 다른 캐릭터로 바뀐다. 그건 포즈 바뀜이 아니라 다른 몸:
         샬럿↔소게츠를 몇 번 오가면 «샬럿 포즈 → 소게츠 포즈»가 배운 왕복(순환)이 되어, 샬럿에 머무는 동안 소게츠 그림 쪽으로
         사이 그림을 폈다(반 넘으면 소게츠 모양 — 팔레트는 지금 것이라 샬럿 색, 유저 2026-10-14 화면 녹화). 캐릭터 번호(물체 +0x3C)가
         바뀐 앞뒤 2 프레임의 바뀜은 안 배우고 새 몸으로 친다. 번호가 그림보다 늦게 바뀌면 방금 배운 것을 무른다 */
      if (!id_cur[p] || f->ch[p] != id_chv[p]) { if (id_cur[p]) chg = 1; id_chv[p] = f->ch[p]; id_cht[p] = realn; }
      sw = f->pick && realn - id_cht[p] <= 2u;
      if (sg == id_cur[p])
      {
         if (chg && f->pick && id_prev[p] && realn - id_start[p] <= 2u)
         {
            id_unlearn(p, id_prev[p], id_cur[p]);
            id_prev[p] = 0; id_prev_link[p] = 0; id_hold_prev[p] = 0; id_prev_moved[p] = 0; id_hold_prev2[p] = 0; id_prev_moved2[p] = 0; id_prev2[p] = 0;
         }
         if (ax != id_ax[p] || ay != id_ay[p]) id_still[p] = 0;
         continue;
      }
      if (id_cur[p] && !sw)   /* 99s: 고르기 화면에서 캐릭터가 바뀐 때는 배우지 않는다 */
      {  /* 움직이는 바뀜도 배운다(패치 99) — 걷기 순환을 알아야 사이 그림을 한 걸음 내내 펼 수 있다. 서기 그리기(±3)는 여전히 제자리만 */
         unsigned hold = realn - id_start[p], h3 = 0;
         uint64_t ln = mc_ln ? mc_loop_next(id_cur[p], &h3) : 0;
         id_prev_link[p] = (uint8_t)(ln == sg || (id_next(p, id_cur[p], id_prev[p], 0) == sg && id_loop(p, id_cur[p], sg)));
         if (hold >= 3 && hold <= 5 && id_still[p] && ax == id_ax[p] && ay == id_ay[p]
             && id_prev[p] && id_hold_prev[p] >= 3 && id_hold_prev[p] <= 5 && !id_prev_moved[p]
             && id_prev2[p] && id_hold_prev2[p] >= 3 && id_hold_prev2[p] <= 6 && !id_prev_moved2[p])
         {  /* 99t: 셋 넘게 이어진 제자리 짧은 머묾 — 그 포즈들을 기억(첫 포즈는 서기 순환 포즈가 아닐 때만) */
            id_chain_mark(p, id_cur[p]); id_chain_mark(p, id_prev[p]);
            if (!id_is_loop(p, id_prev2[p])) id_chain_mark(p, id_prev2[p]);
         }
         id_hold_prev2[p] = id_hold_prev[p]; id_prev_moved2[p] = id_prev_moved[p];   /* 99o */
         id_hold_prev[p] = hold;
         id_prev_moved[p] = (uint8_t)(!id_still[p] || ax != id_ax[p] || ay != id_ay[p]);
         if (hold >= 3 && hold <= 60) id_learn_add(p, id_cur[p], sg, hold);
         id_prev2[p] = id_prev[p];   /* 99t */
         id_prev[p] = id_cur[p];
      }
      else { id_prev[p] = 0; id_prev_link[p] = 0; id_hold_prev[p] = 0; id_prev_moved[p] = 0; id_hold_prev2[p] = 0; id_prev_moved2[p] = 0; id_prev2[p] = 0; }
      id_ti_last[p] = -1; id_ti_sb[p] = 0;
      if (sw) { id_sp_at[p] = 0; id_sp_b[p] = 0; id_far_sb[p] = 0; }   /* 99s: 다른 캐릭터 — 펴던 기록도 버린다 */
      id_cur[p] = sg; id_start[p] = realn; id_ax[p] = ax; id_ay[p] = ay; id_still[p] = 1;
   }
}

/* ───────────── 99w: 이펙트 사이 그림 ───────────── */
#define FXG_MAX 16
typedef struct {
   uint64_t sig;                  /* 무리 그림 지문(색 번호만 — 팔레트 무관). 0 = 못 씀(크거나 우선순위 섞임) */
   int pal, depth, first, x0, y0, x1, y1;
   uint8_t m[64];
} fx_grp;
typedef struct { int on, ti, gx, gy, gw, gh, sx4, sy4, depth, first; mc_ent *e; uint8_t m[64]; } fx_req_t;
static fx_grp   fx_g[4][FXG_MAX];         /* 0 = D-1 · 1 = D · 2 = D+1 · 3 = D+2 */
static int      fx_gn[4];
static unsigned fx_g_realn = 0xFFFFFFFFu;
static const ss2fg_frame *fx_fp = 0;
static fx_req_t fx_rq[2][FX_N];
static id_pose  fx_pa[2][FX_N], fx_pb[2][FX_N];
static uint16_t fx_tc[FX_N][(ID_W * ID_S) * (ID_H * ID_S)];
static int      fx_st[4];                 /* QA: [0] 바뀜 [1] 캐시 있음 [2] 계획 [3] 그림 */
void ss2fg_fx_prev(const ss2fg_frame *fp) { fx_fp = fp; fx_g_realn = 0xFFFFFFFFu; }
static void fx_reset_slot(int slot) { int i; for (i = 0; i < FX_N; i++) fx_rq[slot][i].on = 0; }
/* 무리 그림: 슬롯 큰 조각부터 그려 작은 슬롯이 위. out = 색 번호(0 빈칸) 또는 pic 이면 팔레트<<2|색(빈칸 ID_NONE) */
static void fx_draw_grp(const ss2fg_frame *f, const fx_grp *g, uint8_t *idx, uint16_t *pic)
{
   const ss2fg_regs *r = &f->line[0];
   int w = g->x1 - g->x0, hh = g->y1 - g->y0, k, row, col;
   if (idx) memset(idx, 0, (size_t)w * hh);
   if (pic) for (k = 0; k < w * hh; k++) pic[k] = ID_NONE;
   for (k = 63; k >= 0; k--)
   {
      uint16_t wd;
      unsigned tile;
      int sx, sy;
      if (!g->m[k]) continue;
      wd = ld16(f->spr + k * 4);
      tile = wd & 0x01FF;
      sx = wrapx(f->ax[k] + r->spx) - g->x0; sy = wrapc(f->ay[k] + r->spy) - g->y0;
      for (row = 0; row < 8; row++)
      {
         unsigned rr = (wd & 0x4000) ? 7 - row : row;
         int v = ld16(f->chr + tile * 16 + rr * 2);
         if (wd & 0x8000) v = mirrored[(v & 0xff00) >> 8] | (mirrored[v & 0xff] << 8);
         for (col = 0; col < 8; col++)
         {
            int ci = (v >> (2 * (7 - col))) & 3, yy = sy + row, xx = sx + col;
            if (!ci || yy < 0 || yy >= hh || xx < 0 || xx >= w) continue;
            if (idx) idx[yy * w + xx] = (uint8_t)ci;
            if (pic) pic[yy * w + xx] = (uint16_t)((g->pal << 2) | ci);
         }
      }
   }
}
static int fx_groups(const ss2fg_frame *f, fx_grp *out, int max)
{
   uint8_t b0[64], b1[64], cand[64], used[64];
   static uint8_t idx[ID_W * ID_H];
   int px[64], py[64], k, n = 0;
   const ss2fg_regs *r;
   if (!f || !f->valid || f->mono) return 0;
   r = &f->line[0];
   memset(b0, 0, sizeof b0); memset(b1, 0, sizeof b1);
   if (f->body_ok) { body_mask(f, 0, b0); body_mask(f, 1, b1); }
   for (k = 0; k < 64; k++)
   {
      uint16_t w = ld16(f->spr + k * 4);
      cand[k] = used[k] = 0;
      if (!(w & 0x1800) || b0[k] || b1[k] || (f->sprcol[k] & 15) == 12) continue;
      px[k] = wrapx(f->ax[k] + r->spx); py[k] = wrapc(f->ay[k] + r->spy);
      if (py[k] <= -8 || py[k] >= SS2FG_H) continue;
      cand[k] = 1;
   }
   for (k = 0; k < 64 && n < max; k++)
   {
      int stack[64], sp = 0, j, pal, pr = -1, mixed = 0, w, hh, i;
      fx_grp *g;
      uint64_t hs;
      if (!cand[k] || used[k]) continue;
      g = &out[n]; memset(g, 0, sizeof *g);
      pal = f->sprcol[k] & 15;
      g->pal = pal; g->x0 = g->y0 = 9999; g->x1 = g->y1 = -9999; g->first = 64;
      stack[sp++] = k; used[k] = 1;
      while (sp)
      {
         int a = stack[--sp], p2 = (ld16(f->spr + a * 4) & 0x1800) >> 11;
         g->m[a] = 1;
         if (pr < 0) pr = p2; else if (pr != p2) mixed = 1;
         if (a < g->first) g->first = a;
         if (px[a] < g->x0) g->x0 = px[a];
         if (py[a] < g->y0) g->y0 = py[a];
         if (px[a] + 8 > g->x1) g->x1 = px[a] + 8;
         if (py[a] + 8 > g->y1) g->y1 = py[a] + 8;
         for (j = 0; j < 64; j++)
            if (cand[j] && !used[j] && (f->sprcol[j] & 15) == pal && abs(px[j] - px[a]) <= 9 && abs(py[j] - py[a]) <= 9)
            { used[j] = 1; stack[sp++] = j; }
      }
      g->depth = mixed ? -1 : pr << 1;
      w = g->x1 - g->x0; hh = g->y1 - g->y0;
      if (!mixed && w > 0 && hh > 0 && w <= ID_W && hh <= ID_H)
      {  /* 지문: FNV-1a(폭·높이·화소 색 번호) — 오프라인 캐시 만들기(fxharvest.py)와 같게 */
         fx_draw_grp(f, g, idx, 0);
         hs = 1469598103934665603ULL;
         hs = (hs ^ (uint64_t)(w & 0xff)) * 1099511628211ULL;
         hs = (hs ^ (uint64_t)(hh & 0xff)) * 1099511628211ULL;
         for (i = 0; i < w * hh; i++) hs = (hs ^ (uint64_t)idx[i]) * 1099511628211ULL;
         g->sig = hs | 1;
      }
      n++;
   }
   return n;
}
static const fx_grp *fx_match(const fx_grp *a, const fx_grp *arr, int n)
{
   int i, best = 41, cx = a->x0 + a->x1, cy = a->y0 + a->y1;
   const fx_grp *r = 0;
   for (i = 0; i < n; i++)
   {
      int d;
      if (arr[i].pal != a->pal) continue;
      d = (abs(arr[i].x0 + arr[i].x1 - cx) + abs(arr[i].y0 + arr[i].y1 - cy)) / 2;
      if (d < best) { best = d; r = &arr[i]; }
   }
   return r;
}
static void fx_pic(const ss2fg_frame *f, const fx_grp *g, id_pose *P)
{
   P->sig = g->sig; P->ox = g->x0; P->oy = g->y0; P->w = g->x1 - g->x0; P->h = g->y1 - g->y0;
   P->depth = (uint8_t)g->depth; P->first = (uint8_t)g->first;
   fx_draw_grp(f, g, 0, P->c);
}
/* 출력 칸 slot 의 이펙트 사이 그림 계획 — 바뀌기 직전 2 프레임에 ¼·½·¾(몸 캐시의 «마지막 2 프레임»과 같은 셈) */
static int fx_plan(const ss2fg_frame *f0, const ss2fg_frame *f1, const ss2fg_frame *f2, unsigned realn, int h, int slot)
{
   int i, n = 0;
   fx_reset_slot(slot);
   if (!mc_on || !mc_f || !f0 || !f1) return 0;
   if (fx_g_realn != realn)
   {
      fx_gn[0] = fx_fp ? fx_groups(fx_fp, fx_g[0], FXG_MAX) : 0;
      fx_gn[1] = fx_groups(f0, fx_g[1], FXG_MAX);
      fx_gn[2] = fx_groups(f1, fx_g[2], FXG_MAX);
      fx_gn[3] = f2 ? fx_groups(f2, fx_g[3], FXG_MAX) : 0;
      fx_g_realn = realn;
   }
   for (i = 0; i < fx_gn[1] && n < FX_N; i++)
   {
      const fx_grp *a = &fx_g[1][i], *b = 0, *m1, *pv;
      const ss2fg_frame *fk;
      int K = 0, L, num, ti, dx, dy;
      mc_ent *e;
      if (!a->sig) continue;
      m1 = fx_match(a, fx_g[2], fx_gn[2]);
      if (!m1) continue;
      if (m1->sig != a->sig) { K = 1; b = m1; }
      else if (f2)
      {
         const fx_grp *m2 = fx_match(m1, fx_g[3], fx_gn[3]);
         if (m2 && m2->sig != a->sig) { K = 2; b = m2; }
      }
      if (!K || !b->sig || b->depth != a->depth) continue;
      if (slot == 0) fx_st[0]++;
      pv = fx_match(a, fx_g[0], fx_gn[0]);
      L = (pv && pv->sig == a->sig) ? 2 : K;                 /* A 가 보이는 프레임 수(바뀔 때까지, 2 까지) */
      if (L > 2) L = 2;
      num = 2 * L - (2 * K - h);
      if (num <= 0) continue;
      ti = L == 2 ? num - 1 : 1;
      if (ti < 0 || ti > 2) continue;
      e = mc_get(a->sig, b->sig);
      if (!e) continue;
      if (slot == 0) fx_st[1]++;
      if (e->aw != a->x1 - a->x0 || e->ah != a->y1 - a->y0 || e->bw != b->x1 - b->x0 || e->bh != b->y1 - b->y0) continue;
      dx = (b->x0 - a->x0) - e->bdx; dy = (b->y0 - a->y0) - e->bdy;
      if (dx < -4 || dx > 4 || dy < -4 || dy > 4) continue;
      fk = K == 1 ? f1 : f2;
      fx_pic(f0, a, &fx_pa[slot][n]);
      fx_pic(fk, b, &fx_pb[slot][n]);
      {
         fx_req_t *rq = &fx_rq[slot][n];
         rq->on = 1; rq->e = e; rq->ti = ti;
         rq->gx = a->x0 + e->cx; rq->gy = a->y0 + e->cy; rq->gw = e->w; rq->gh = e->h;
         rq->sx4 = (ti + 1) * dx; rq->sy4 = (ti + 1) * dy;
         rq->depth = a->depth; rq->first = a->first;
         memcpy(rq->m, a->m, 64);
      }
      if (slot == 0) fx_st[2]++;
      n++;
   }
   return n > 0;
}
void ss2fg_fx_stats4(int *o) { int i; for (i = 0; i < 4; i++) o[i] = fx_st[i]; }

static int id_plan_learned(const ss2fg_frame *f0, const ss2fg_frame *f1, const ss2fg_frame *f2, unsigned realn, int h, int slot, int p);
/* 출력 칸 slot(0 = τD, 1 = τD+½, h = 반 프레임) 의 사이 그림 계획. f1·f2 = 미리 돌린 D+1·D+2. 반환 1 = 그릴 몸이 있음 */
int ss2fg_idle_plan(const ss2fg_frame *f0, const ss2fg_frame *f1, const ss2fg_frame *f2, unsigned realn, int h, int slot)
{
   int p, any = 0;
   if (slot < 0 || slot > 1) return 0;
   for (p = 0; p < 2; p++) id_rq[slot][p].on = 0;
   for (p = 0; p < ID_NR; p++) id_pt[slot][p].on = 0;
   if (!id_on || !f0 || !f0->body_ok) { fx_reset_slot(slot); return 0; }
   for (p = 0; p < 2; p++)
   {
      if (id_plan_learned(f0, f1, f2, realn, h, slot, p) || mc_plan(f0, f1, f2, realn, h, slot, p)) any = 1;
   }
   if (fx_plan(f0, f1, f2, realn, h, slot)) any = 1;   /* 99w */
   return any;
}

/* 서기(배운 되풀이 바뀜) — 지난 시간/길이로 t, ±3px 이동표(id_pair) */
static int id_plan_learned(const ss2fg_frame *f0, const ss2fg_frame *f1, const ss2fg_frame *f2, unsigned realn, int h, int slot, int p)
{
   {
      unsigned hold = 0;
      uint64_t sb;
      int k, K = 0, bad = 0, e2, tot2, t256, tl;
      id_pair *pr;
      id_req_t *rq = &id_rq[slot][p];
      if (!id_cur[p] || !id_still[p] || f0->ob_x[p] != id_ax[p] || f0->ob_y[p] != id_ay[p]) return 0;
      sb = id_next(p, id_cur[p], id_prev[p], &hold);
      if (!sb || !id_find_pose(p, sb)) return 0;
      for (k = 1; k <= 2 && !K && !bad; k++)
      {
         const ss2fg_frame *fk = k == 1 ? f1 : f2;
         uint8_t mm[64];
         uint64_t s;
         if (!fk || !fk->body_ok || !body_mask(fk, p, mm)) { bad = 1; break; }
         if (fk->ob_x[p] != id_ax[p] || fk->ob_y[p] != id_ay[p]) { bad = 1; break; }   /* 움직이기 시작 */
         s = body_sig(fk, mm);
         if (s == id_cur[p]) continue;
         if (s == sb) K = k; else bad = 1;
      }
      if (bad) { id_stats[3]++; return 0; }
      if (f0->pick)
      {  /* 99s: 고르기 화면 — 보이는 바뀜은 같은 캐릭터만. 캐릭터 고르기(2)의 미리보기는 커서를 둔 동안 멈춰 있어 바뀔 때를 모르고 펴면 늘 빗나간다 */
         const ss2fg_frame *fk = K == 1 ? f1 : f2;
         if (K ? (fk->ch[p] != f0->ch[p] || fk->ch_now[p] != f0->ch[p]) : f0->pick == 2) return 0;
      }
      if (K) id_realign(K == 1 ? f1 : f2, p, sb);      /* 뒤 포즈도 지금 장면 것으로(99e) */
      else
      {  /* 아직 안 보인 뒤 포즈 — 우선순위는 지금 장면(A) 것으로 본다(다른 장면에서 잡힌 값이면 바뀜을 못 만든다). 보이면 id_realign 이 고친다 */
         id_pose *QA = id_find_pose(p, id_cur[p]), *QB = id_find_pose(p, sb);
         if (QA && QB && QB->depth != QA->depth) QB->depth = QA->depth;
      }
      e2 = 2 * (int)(realn - id_start[p]) + h;
      /* 99e: 배운 길이보다 2 프레임 넘게 머물면 붙잡은 자세(앉아 방어·서서 막기 등) — 예전엔 «적어도 3 프레임 남음»으로 길이를 늘려
         t 가 1 쪽으로 다가가, 자세를 쥐고 있는 내내 다음 포즈 쪽으로 ¾ 쯤 바뀐 그림이 나왔다(유저 2026-10-12 「앉아 방어 자세에서 글리치」).
         그동안은 그리지 않고, 실제로 바뀔 때는(미리 돌린 D+1·D+2 에 보이면) 바뀌기 직전 2 프레임에만 */
      /* 99h: ① 길이는 바뀔 때를 알면 실제 길이, 모르면 가장 짧은 길이 — 예전엔 출력 반 칸(h)까지 더 쳐서 제 길이로 머문 서기도
         마지막 칸이 «오래 머묾»으로 잡혀 …0.9 → 0.75 로 뒤로 갔다(대전·«いざ尋常に» 서기마다 한 번).
         ② 뒤 포즈를 기억에서 잃어(포즈 기억이 차서 밀림) 앞 포즈가 보이는 동안 고르게 펴지 못했으면, 끝쪽 t(0.9 쯤)부터 나오지 말고
         바뀌기 직전 2 프레임에 ¼·½·¾ — 캐시(mc_plan)와 같은 표시(id_sp_at)를 같이 본다 */
      tl = K ? 2 * (int)(realn + K - id_start[p]) : 2 * (int)(realn - id_start[p]) + 6;
      if (tl > 2 * (int)hold + 4 || (K && (id_sp_at[p] != id_start[p] + 1u || id_sp_b[p] != sb)))
      {
         if (!K) return 0;
         tot2 = tl;
         e2 -= tot2 - 4; tot2 = 4;
         if (e2 <= 0) return 0;
      }
      else if (K) tot2 = tl;
      else { tot2 = 2 * (int)hold; if (tot2 < e2 + 6) tot2 = e2 + 6; }      /* D+2 까진 안 바뀜 — 적어도 3 프레임 남음 */
      if (tot2 <= 0) return 0;
      t256 = 256 * e2 / tot2;
      if (t256 <= 0) return 0;
      if (t256 > 255) t256 = 255;
      pr = id_get_pair(p, id_cur[p], sb);
      if (!pr) return 0;
      /* 큰 바뀜(사이 그림이 반쯤에서 뒤 그림으로 넘어감)은 되풀이 동작(서기)일 때만 — 착지→서기·공격 끝 자세→서기처럼 한 번 지나가는
         바뀜이면 그 자세가 끝나는 때가 앞당겨 보인다 */
      if (!pr->small && !id_loop(p, id_cur[p], sb)) return 0;
      if (pr->bigp && mc_has(id_cur[p], sb)) return 0;           /* 99f: 가는 부분이 멀리 가는 바뀜 — 캐시 사이 그림(칼이 이어짐)으로 */
      if (!K) { id_sp_at[p] = id_start[p] + 1u; id_sp_b[p] = sb; }   /* 99h: 뒤 포즈를 모른 채 고르게 펴는 중 */
      rq->on = 1; rq->kind = 0; rq->pr = pr; rq->t256 = t256; rq->sx4 = rq->sy4 = 0;
      rq->ax = id_ax[p]; rq->ay = id_ay[p];
      rq->gx = pr->ox; rq->gy = pr->oy; rq->gw = pr->w; rq->gh = pr->h; rq->depth = pr->depth; rq->first = pr->first;
      id_stats[1]++;
      return 1;
   }
}

/* 99j: 배경 스크롤도 ¼ px — 카메라는 2 프레임에 1 px 씩만 움직인다(대전 실측 92%). 사이 칸의 스크롤을 1배 정수로 반올림하면
   120Hz 네 칸 중 한 칸만 움직여 배경이 30Hz 계단이었다(몸이 ¼ px 로 부드러워지자(99i) 더 눈에 띔).
   스크롤 «바뀜» 박자는 화면 전체 하나(fg_predict4 의 Kb)로 정했는데, 어느 줄이든 값이 바뀌면 바뀜으로 쳐서
   (실측: 한 줄의 플레인1 세로값이 2 프레임마다 0↔120 — 카메라와 엇박자) 늘 «매 프레임 바뀜»이 되어 ½ px 두 번에 그쳤다.
   → 플레인·줄·축(값 4개)마다 따로 «지난 바뀜 L · 다음 바뀜 K»를 찾아 τ 의 정확한 자리(4배 화소)를 낸다.
   1배 그림을 그릴 때 그 자리가 1배 그림의 정수 자리와 다른 줄은 ① 스프라이트만의 맨 앞(깊이·색) ② 플레인 줄(그 자리의
   정수 스크롤로, 화면 한 칸 더 넓게, 세로 ¼ 이 걸치면 다음 행도)을 남기고, 4배로 늘릴 때(내보내기·몸 조각) 4배 화소마다
   «스프라이트 · ¼ px 옮긴 앞 플레인 · 뒤 플레인 · 배경색» 중 앞의 것을 고른다 */
typedef struct {
   int on;
   uint8_t  sz[SS2FG_H][SS2FG_W];                      /* 스프라이트만의 맨 앞 깊이(0 = 없음) */
   uint16_t sc[SS2FG_H][SS2FG_W];                      /* 그 색 */
   uint8_t  sz2[SS2FG_H][SS2FG_W];                     /* 포즈 섞기 줄: 둘째 판(다음 포즈)의 스프라이트만 */
   uint16_t sc2[SS2FG_H][SS2FG_W];
   uint8_t  pp[SS2FG_H];                               /* 포즈 섞기 줄 — 두 판을 각각 고른 뒤 섞는다 */
   int      ppa;                                      /* 섞는 비율(t_spr) */
   uint16_t pf[2][SS2FG_H][SS2FG_W + 1];               /* 앞 플레인: [0] 그 줄의 행, [1] 다음 행(세로 ¼ 이 걸칠 때만) — 0xFFFF = 빈 */
   uint16_t pb[2][SS2FG_H][SS2FG_W + 1];               /* 뒤 플레인 */
   int8_t   rfx[SS2FG_H], rfy[SS2FG_H], rbx[SS2FG_H], rby[SS2FG_H];   /* 정수 스크롤 다음의 ¼ px(0..3) */
   uint8_t  wx0[SS2FG_H], wx1[SS2FG_H], any[SS2FG_H];
   uint16_t back[SS2FG_H];                             /* 배경색(12비트, 반전 반영) */
} fg_sp_t;
static fg_sp_t fg_sp[2];
static const uint32_t *fg_sp_cmap;                     /* 4배 내보내기에서 12비트 색 → 화면 색 */
static unsigned sp_lastc[SS2FG_H][4];                  /* 값마다 지난 바뀜(실제 프레임 번호) */
static int8_t   sp_lastd[SS2FG_H][4];                  /* 그 바뀜의 방향(-1·+1) */
static int16_t  sp_E[2][SS2FG_H][4];                   /* τD·τD+½ 의 정확한 옮김(4배 화소, D 값 기준) */
static uint8_t  sp_planned[2];
static int      sp_stats[4];                           /* 시험용: 계획한 칸·옮긴 줄·포즈 섞기 칸·끔(이펙트 섞기) */
static inline uint8_t sp_v(const ss2fg_regs *r, int v) { return v == 0 ? r->s1x : v == 1 ? r->s1y : v == 2 ? r->s2x : r->s2y; }
int ss2fg_scroll_plan(const ss2fg_frame *fp, const ss2fg_frame *f0, const ss2fg_frame *f1, const ss2fg_frame *f2, unsigned realn)
{
   int y, v, h, m = 0;
   fg_sp[0].on = fg_sp[1].on = 0;
   sp_planned[0] = sp_planned[1] = 0;
   if (!f0 || !f0->valid || f0->mono) return 0;
   if (fp && !fp->valid) fp = 0;
   if (f1 && !f1->valid) f1 = 0;
   if (f2 && !f2->valid) f2 = 0;
   for (y = 0; y < SS2FG_H; y++)
      for (v = 0; v < 4; v++)
      {
         uint8_t a0 = sp_v(&f0->line[y], v);
         int K = 0, d = 0, rel, L;
         if (fp && sp_v(&fp->line[y], v) != a0)
         {
            sp_lastc[y][v] = realn;
            sp_lastd[y][v] = (int8_t)((int8_t)(uint8_t)(a0 - sp_v(&fp->line[y], v)) > 0 ? 1 : -1);
         }
         sp_E[0][y][v] = sp_E[1][y][v] = 0;
         if (f1 && sp_v(&f1->line[y], v) != a0) { K = 1; d = (int8_t)(uint8_t)(sp_v(&f1->line[y], v) - a0); }
         else if (f2 && sp_v(&f2->line[y], v) != a0) { K = 2; d = (int8_t)(uint8_t)(sp_v(&f2->line[y], v) - a0); }
         if (!K || d > SS2FG_SCROLL_MAX_STEP || d < -SS2FG_SCROLL_MAX_STEP) continue;   /* 안 바뀜 · 장면 전환 */
         rel = (int)(sp_lastc[y][v] - realn);
         if (rel > 0 || rel < -64) rel = -64;
         /* 흔들림은 옮기지 않는다 — 큰 한 걸음(3 px 이상)이나 막(4 프레임 안) 반대로 간 것. 대전 실측: 세로 값의 바뀜은 거의 다
            맞을 때의 화면 흔들림(7→6→…→1 px 로 줄며 2 프레임마다 오감), 가로 카메라는 1 px. 흔들림을 사이 칸으로 이으면
            배경이 출렁여(흔들림 대신 물결) 원래처럼 두 프레임씩 끊어 보인다 */
         if (d >= 3 || d <= -3 || (rel >= -4 && sp_lastd[y][v] && (d > 0) != (sp_lastd[y][v] > 0))) continue;
         L = rel > K - 2 ? rel : K - 2;                                                 /* 전체 박자와 같은 규칙(K-2 이상) */
         for (h = 0; h < 2; h++)
         {
            int t = (256 * (h - 2 * L)) / (2 * (K - L)), e = d * t;
            e = e >= 0 ? (e + 32) >> 6 : -((-e + 32) >> 6);
            sp_E[h][y][v] = (int16_t)e;
            if (e) m |= 1 << h;
         }
      }
   sp_planned[0] = sp_planned[1] = 1;
   return m;
}
/* 플레인 한 행(화면 0..W, 한 칸 더) — draw_scroll·draw_pattern 과 같은 화소, 창은 안 자른다(4배로 고를 때 자른다) */
static void sp_row(const ss2fg_frame *f, const ss2fg_regs *r, int plane, uint8_t sx, uint8_t line, uint16_t *out)
{
   const uint8_t *map = f->scroll + (plane == 2 ? 0x0800 : 0) + (((unsigned)(line >> 3) << 5) << 1);
   const uint8_t *pal = f->pal + (plane == 2 ? 0x0100 : 0x0080);
   unsigned row = line & 7;
   int X = 0;
   while (X <= SS2FG_W)
   {
      unsigned px = (unsigned)(X + sx) & 0xFF, j = px & 7;
      uint16_t d = ld16(map + ((px >> 3) << 1));
      unsigned tiley = (d & 0x4000) ? 7 - row : row;
      int index = ld16(f->chr + ((d & 0x01FF) * 16) + (tiley * 2));
      const uint8_t *pp = pal + (((d & 0x1E00) >> 9) << 3);
      if (d & 0x8000) index = mirrored[(index & 0xff00) >> 8] | (mirrored[index & 0xff] << 8);
      for (; j < 8 && X <= SS2FG_W; j++, X++)
      {
         unsigned ci = (index >> ((7 - j) * 2)) & 3;
         if (!ci) out[X] = 0xFFFF;
         else
         {
            uint16_t c = ld16(pp + (ci << 1));
            if (r->neg) c = (uint16_t)~c;
            out[X] = (uint16_t)(c & 0x0FFF);
         }
      }
   }
}
/* 스프라이트만 맨 앞(zs 깊이·sc 색, 0 = 없음) · 앞 플레인 f · 뒤 플레인 b(0xFFFF = 빈) · 배경색 중 앞 */
static inline unsigned sp_pick(int zs, unsigned sc, unsigned f, unsigned b, unsigned back)
{
   if (zs > ZD_FG_SCROLL) return sc;
   if (f != 0xFFFF) return f;
   if (zs > ZD_BG_SCROLL) return sc;
   if (b != 0xFFFF) return b;
   return zs > 0 ? sc : back;
}
/* 4배 화소 (X, 4y+sy) 의 색(12비트) — zs·sc = 그 1배 화소의 스프라이트만 맨 앞(깊이 0 = 없음). *zw = 이긴 깊이(0 = 배경색) */
static unsigned sp_px(const fg_sp_t *sp, int y, int sy, int X, int zs, unsigned sc, int *zw)
{
   int best = zs;
   unsigned c = sc;
   uint16_t v;
   v = sp->pf[sy + sp->rfy[y] >= 4][y][(X + sp->rfx[y]) >> 2];
   if (v != 0xFFFF && ZD_FG_SCROLL > best) { best = ZD_FG_SCROLL; c = v; }
   v = sp->pb[sy + sp->rby[y] >= 4][y][(X + sp->rbx[y]) >> 2];
   if (v != 0xFFFF && ZD_BG_SCROLL > best) { best = ZD_BG_SCROLL; c = v; }
   if (best <= 0) c = sp->back[y];
   if (zw) *zw = best;
   return c;
}
void ss2fg_scroll_stats(int *out4) { int i; for (i = 0; i < 4; i++) out4[i] = sp_stats[i]; }
/* 99n: 플레인 깜빡임 섞기 — 사무쇼2 는 대전 내내 앞 플레인(플레인 1)의 스크롤을 2 프레임마다 (0,0) ↔ (x,120) 으로 옮겨 두 자리를
   번갈아 보인다(10판 실측: 대전 처음부터 끝까지). 평소엔 둘 다 비어 안 보이지만 필살기의 빛기둥(흰·노랑, 화면 ⅕~¼)은 한쪽 자리에만
   그려져 2 프레임 켜짐·2 프레임 꺼짐(15Hz)으로 번쩍인다 — 옛 기계의 느린 액정에서는 반투명처럼 보였을 연출.
   줄마다 플레인 스크롤이 지금만 멀고(16px 넘게) 1~2 프레임 앞·뒤는 서로 같은(8px 안) «켰다 끄기» 박자이고, 4 프레임 앞(1·1 박자면
   2 프레임 앞)도 지금과 같은 자리여야(되풀이) 깜빡임으로 친다. 그런 줄은 그 플레인만 다른 위상(지난 프레임)의 것으로 바꿔 다시 고른다
   (스프라이트·다른 플레인·배경색·창은 지금 것) — 바뀐 칸만 om=1, 색은 oc(12비트). 출력에서 이 색을 섞는다(libretro.c pf_apply) */
static int fk_d8(uint8_t a, uint8_t b) { int d = (uint8_t)(a - b); return d > 128 ? 256 - d : d; }
static int fk_dist(const ss2fg_regs *a, const ss2fg_regs *b, int p)
{
   int dx = p == 1 ? fk_d8(a->s1x, b->s1x) : fk_d8(a->s2x, b->s2x);
   int dy = p == 1 ? fk_d8(a->s1y, b->s1y) : fk_d8(a->s2y, b->s2y);
   return dx > dy ? dx : dy;
}
#define FK_FAR  16
#define FK_NEAR 8
/* 줄 y 의 플레인 p 가 D(h[4])에서 깜빡이는 박자면 다른 위상의 지난 프레임, 아니면 0 */
static const ss2fg_frame *fk_other(const ss2fg_frame *const *h, int y, int p)
{
   const ss2fg_regs *r0 = &h[4]->line[y];
   int dk[7], k;
   for (k = 0; k < 7; k++) dk[k] = (h[k] && h[k]->valid && !h[k]->mono) ? fk_dist(r0, &h[k]->line[y], p) : -1;
#define FK_F(k)    (dk[k] >= FK_FAR)
#define FK_S(k)    (dk[k] >= 0 && dk[k] <= FK_NEAR)
#define FK_N(a, b) (fk_dist(&h[a]->line[y], &h[b]->line[y], p) <= FK_NEAR)
   if (FK_F(3) && FK_F(6) && FK_S(5) && FK_S(0) && FK_N(3, 6)) return h[3];   /* 2·2 박자, D 가 첫 칸 — 다른 위상 D-1 */
   if (FK_F(2) && FK_F(5) && FK_S(3) && FK_S(0) && FK_N(2, 5)) return h[2];   /* 2·2 박자, D 가 둘째 칸 — D-2 */
   if (FK_F(3) && FK_F(5) && FK_S(2) && FK_N(3, 5)) return h[3];              /* 1·1 박자 — D-1 */
#undef FK_F
#undef FK_S
#undef FK_N
   return 0;
}
static void fk_row(const ss2fg_frame *f, int y, int p, int on, uint16_t *out)
{
   const ss2fg_regs *r = &f->line[y];
   int X;
   if (!on) { for (X = 0; X <= SS2FG_W; X++) out[X] = 0xFFFF; return; }
   if (p == 1) sp_row(f, r, 1, r->s1x, (uint8_t)(y + r->s1y), out);
   else        sp_row(f, r, 2, r->s2x, (uint8_t)(y + r->s2y), out);
}
int ss2fg_flicker_plan(const ss2fg_frame *const *h, uint16_t *oc, uint8_t *om, uint8_t *oline)
{
   static uint16_t rFD[SS2FG_W + 1], rFO[SS2FG_W + 1], rBD[SS2FG_W + 1], rBO[SS2FG_W + 1], scan[SS2FG_W], sc[SS2FG_W];
   static uint8_t zs[SS2FG_W];
   const ss2fg_frame *f0 = h[4];
   int y, n = 0;
   memset(oline, 0, SS2FG_H);
   if (!f0 || !f0->valid || f0->mono) return 0;
   for (y = 0; y < SS2FG_H; y++)
   {
      const ss2fg_regs *r0 = &f0->line[y];
      const ss2fg_frame *o1, *o2, *oF, *oB;
      int pF = r0->swap ? 2 : 1, x, x0, x1, any = 0, nl = 0;
      unsigned bc;
      if (!(y >= r0->winy && y < r0->winy + r0->winh)) continue;
      x0 = r0->winx; x1 = imin(r0->winx + r0->winw, SS2FG_W);
      if (x0 >= x1) continue;
      o1 = fk_other(h, y, 1); o2 = fk_other(h, y, 2);
      if (!o1 && !o2) continue;
      oF = pF == 1 ? o1 : o2; oB = pF == 1 ? o2 : o1;
      if (oF)
      {
         fk_row(f0, y, pF, f0->layers & 2, rFD);
         fk_row(oF, y, pF, oF->layers & 2, rFO);
         for (x = x0; x < x1 && !any; x++) any = rFD[x] != rFO[x];
      }
      if (oB)
      {
         fk_row(f0, y, 3 - pF, f0->layers & 1, rBD);
         fk_row(oB, y, 3 - pF, oB->layers & 1, rBO);
         for (x = x0; x < x1 && !any; x++) any = rBD[x] != rBO[x];
      }
      if (!any) continue;                               /* 두 위상 모두 비었다(평소 대전 — 줄마다 두 행만 보고 끝) */
      if (!oF) { fk_row(f0, y, pF, f0->layers & 2, rFD); memcpy(rFO, rFD, sizeof rFO); }
      if (!oB) { fk_row(f0, y, 3 - pF, f0->layers & 1, rBD); memcpy(rBO, rBD, sizeof rBO); }
      {  /* 지금 프레임의 스프라이트만 맨 앞(깊이·색) — 다른 단계의 설정은 잠시 끈다 */
         const uint8_t *sk = rl_skip; uint8_t *zo = rl_zout; int16_t *sl = rl_slot; int ppo = pp_on, ffo = fx_fade_on;
         rl_skip = 0; rl_zout = 0; rl_slot = 0; pp_on = 0; fx_fade_on = 0;
         rl_sprz = zs; rl_sprc = sc; rl_sprs = 0;
         render_line(f0, 0, 0, 0, 0, y, scan);
         rl_sprz = 0; rl_sprc = 0;
         rl_skip = sk; rl_zout = zo; rl_slot = sl; pp_on = ppo; fx_fade_on = ffo;
      }
      {
         uint16_t c = ld16(f0->pal + 0x01E0 + ((r0->bgc & 7) << 1));
         if (r0->neg) c = (uint16_t)~c;
         bc = c & 0x0FFF;
      }
      memset(om + y * SS2FG_W, 0, SS2FG_W);
      for (x = x0; x < x1; x++)
      {
         unsigned d = sp_pick(zs[x], sc[x], rFD[x], rBD[x], bc), o = sp_pick(zs[x], sc[x], rFO[x], rBO[x], bc);
         if (o == d) continue;
         om[y * SS2FG_W + x] = 1; oc[y * SS2FG_W + x] = (uint16_t)o; nl++;
      }
      if (nl) { oline[y] = 1; n += nl; }
   }
   return n;
}
/* 99l: 사무쇼2 는 큰 타격 때 창(window) 폭을 0 으로 접어 화면 전체를 창 밖 색(흰 fff·검은 000)으로 1 프레임 칠한다
   (실측: 반전 NEG 는 한 번도 안 씀). 줄의 9할 넘게 창 밖이면 그런 프레임 */
int ss2fg_flash_frame(const ss2fg_frame *f, uint16_t *c12)
{
   int y, n = 0;
   if (!f || !f->valid || f->mono) return 0;
   for (y = 0; y < SS2FG_H; y++)
   {
      const ss2fg_regs *r = &f->line[y];
      if (!(y >= r->winy && y < r->winy + r->winh && r->winw > 0 && r->winx < SS2FG_W)) n++;
   }
   if (n * 10 < SS2FG_H * 9) return 0;
   if (c12)
   {
      const ss2fg_regs *r = &f->line[SS2FG_H / 2];
      uint16_t c = ld16(f->pal + 0x01F0 + ((r->oowc & 7) << 1));
      if (r->neg) c = (uint16_t)~c;
      *c12 = (uint16_t)(c & 0x0FFF);
   }
   return 1;
}

/* 99i: 지금 포즈 그대로 4배로(사이 그림 없이 ¼ px 자리만 옮길 때) */
static void id_draw_self(const id_pose *P, uint16_t *out)
{
   int W4 = P->w * ID_S, x, y, a, b;
   for (y = 0; y < P->h; y++)
      for (x = 0; x < P->w; x++)
      {
         uint16_t v = P->c[y * P->w + x];
         for (b = 0; b < ID_S; b++) for (a = 0; a < ID_S; a++) out[(y * ID_S + b) * W4 + x * ID_S + a] = v;
      }
}
static int id_round4(int v256) { return v256 >= 0 ? (v256 + 32) >> 6 : -((-v256 + 31) >> 6); }   /* 1/256 px → 4배 화소 */

/* ss2fg_render2 끝에서 — 이 출력 칸의 몸마다 «몸 뺀 줄 + 사이 그림» 4배 조각 */
static void id_build(const ss2fg_frame *base, const ss2fg_frame *to_scr, int t_scr,
                     const int16_t *offx, const int16_t *offy, const uint32_t *colormap)
{
   /* 99i: 두 단계 — ① 몸마다 그릴 것(사이 그림 또는 지금 포즈를 ¼ px 자리에)을 정해 4배 그림으로 만들고
      ② 조각마다 «그릴 몸 둘 다 뺀 줄» 위에 두 몸을 앞뒤(우선순위·슬롯) 순서대로 얹는다.
      예전엔 조각마다 자기 몸만 빼고 다른 몸은 1배 그림(사이 그림 없는 자리) 그대로 둬서, 두 몸이 겹치면
      뒤에 붙인 조각이 앞 몸의 사이 그림을 덮어 그 부분만 사이 그림이 빠졌다(¼ px 몸 조각을 늘 그리면 자주 생김) */
   static uint16_t id_tc2[(ID_W * ID_S) * (ID_H * ID_S)];
   struct { int on, W4, gh, ux0, uy0, sh4x, sh4y, x0, y0, x1, y1, depth, first, cur, r4x, r4y, an, ax0, ay0, ax1, ay1; const uint16_t *img; uint8_t m[64]; } dr[ID_NR];   /* 99w: 몸 둘 + 이펙트 */
   id_req_t self[2];
   uint8_t skip[64], zrow[256], szr[256], bm[2][64], am[2][64];
   static uint16_t al_c[2][ID_W * ID_H];                      /* 99r: 붙은 조각만 그린 1배 그림(색·깊이·슬롯) */
   static uint8_t  al_z[2][ID_W * ID_H];
   static int8_t   al_s[2][ID_W * ID_H];
   int an_any = 0;
   int16_t srow[256], ssr[256];
   uint16_t scan[256], scr[256];
   int s = id_slot, p, q, k;
   if (s < 0 || s > 1 || !id_on) return;
   memset(dr, 0, sizeof dr);
   for (p = 0; p < ID_NR; p++) id_pt[s][p].on = 0;
   if (pp_on || fx_fade_on) return;                            /* 포즈·이펙트 섞기 중엔 몸 뺀 줄을 같게 못 만든다 */
   memset(am, 0, sizeof am);
   for (p = 0; p < 2; p++) body_mask(base, p, bm[p]);         /* 99r: 두 몸 조각(붙은 조각에서 뺀다) */
   for (p = 0; p < 2; p++)
   {
      const id_req_t *rq = &id_rq[s][p];
      uint16_t *img = p ? id_tc2 : id_tc;
      int mvx = 0, mvy = 0, r4x = 0, r4y = 0;
      if (!rq->on && !fg_ex_on[p]) continue;
      if (!body_mask(base, p, dr[p].m)) continue;
      {  /* 몸 조각이 옮겨 그려지는 만큼(보간 자리) — 모두 같아야. 서기(배운 바뀜)는 제자리만, 캐시는 움직이는 몸도(걷기·점프 등, 패치 98) */
         int seen = 0, same = 1;
         for (k = 0; k < 64; k++)
            if (dr[p].m[k])
            {
               int dx = offx ? offx[k] : 0, dy = offy ? offy[k] : 0;
               if (!seen) { mvx = dx; mvy = dy; seen = 1; }
               else if (dx != mvx || dy != mvy) { same = 0; break; }
            }
         if (!same) continue;
      }
      if (fg_ex_on[p])
      {  /* 정확한 옮김과 1배 정수 옮김의 차(4배 화소, ±2) */
         r4x = id_round4(fg_ex_x[p]) - mvx * ID_S; r4y = id_round4(fg_ex_y[p]) - mvy * ID_S;
         if (r4x < -3 || r4x > 3 || r4y < -3 || r4y > 3) r4x = r4y = 0;
      }
      if (!rq->on || (rq->kind == 0 && (mvx || mvy)))
      {  /* 사이 그림이 없거나(서기 사이 그림은 제자리 몸만) — 움직이는 몸을 지금 포즈 그대로 ¼ px 자리에 */
         id_pose *P;
         int tlx, tly;
         if (!r4x && !r4y) continue;
         P = id_find_pose(p, body_sig(base, dr[p].m));
         if (!P || !mc_top_left(base, p, &tlx, &tly) || tlx != P->ox || tly != P->oy) continue;
         memset(&self[p], 0, sizeof self[p]);
         self[p].on = 1; self[p].kind = 2; self[p].A = P;
         self[p].ax = base->ob_x[p]; self[p].ay = base->ob_y[p];
         self[p].gx = P->ox; self[p].gy = P->oy; self[p].gw = P->w; self[p].gh = P->h;
         self[p].depth = P->depth;
         for (k = 0; k < 64 && !dr[p].m[k]; k++) ;
         self[p].first = k;
         rq = &self[p];
      }
      if (rq->kind == 0) r4x = r4y = 0;   /* 99r ②: 서기 사이 그림(제자리 몸)은 ¼ px 로 안 옮긴다 — 99h 처럼. 몸 따로 박자가 조금 움직이라 해도
                                              사이 그림만 ¾ px 밀려 나머지와 어긋났다(붙잡기 → 머리 펼치기 같은 빠른 바뀜에서 몸이 섞여 흔들림) */
      if ((r4x || r4y) && !base->fight)
      {  /* 99r ③: 대전 밖(고르기 화면·판 시작 전)에서 몸 조각이 화면·창 가장자리에 걸치면 안 옮긴다 — 들어오는 미리보기는 가장자리 밖 조각을
            게임이 안 그려 옮긴 만큼 들어오는 쪽 끝이 비었다. 대전에서는 구석에 몰린 몸도 조각이 화면 밖까지 있어(봇 판 측정) 그대로 옮긴다 */
         int bx0 = 9999, bx1 = -9999, by0 = 9999, by1 = -9999, cy;
         for (k = 0; k < 64; k++)
            if (bm[p][k])
            {
               int sx = wrapx(base->ax[k] + base->line[0].spx) + mvx, sy = wrapc(base->ay[k] + base->line[0].spy) + mvy;
               if (sx < bx0) bx0 = sx;
               if (sx + 8 > bx1) bx1 = sx + 8;
               if (sy < by0) by0 = sy;
               if (sy + 8 > by1) by1 = sy + 8;
            }
         cy = (by0 + by1) / 2;
         if (cy < 0) cy = 0;
         if (cy >= SS2FG_H) cy = SS2FG_H - 1;
         if (bx0 <= imax(0, base->line[cy].winx) || bx1 >= imin(SS2FG_W, base->line[cy].winx + base->line[cy].winw)
             || by0 <= 0 || by1 >= SS2FG_H)
            r4x = r4y = 0;
      }
      if (rq->kind == 2 && !r4x && !r4y) continue;                /* 지금 포즈를 그대로 다시 그릴 까닭이 없어짐 */
      dr[p].r4x = r4x; dr[p].r4y = r4y; dr[p].an = 0;
      if ((r4x || r4y) && (base->layers & 4))
      {  /* 99r ①: 몸과 같이 움직이는 «붙은» 조각 — 몸 팔레트가 아니라 몸 조각에 안 드는 무기·베기 효과·그림자 등. 몸만 ¼ px 옮기면 1배 자리에 남아
            가장자리로 몸이 1~2 px 비쳤다(창 찌르기의 베기 효과 — 커스텀 apk 방 검수). 몸 틀에 닿고, 이 칸의 정확한 옮김이 몸과 똑같고(같은 이동량 × t),
            1배 정수 옮김도 같은 조각을 몸과 같은 ¼ px 로 같이 옮긴다 */
         int fx0 = rq->ax + rq->gx + mvx - 2, fy0 = rq->ay + rq->gy + mvy - 2, fx1 = rq->ax + rq->gx + mvx + rq->gw + 2, fy1 = rq->ay + rq->gy + mvy + rq->gh + 2;
         int ax0 = 9999, ay0 = 9999, ax1 = -9999, ay1 = -9999, na = 0;
         for (k = 0; k < 64; k++)
         {
            uint16_t w = ld16(base->spr + k * 4);
            int sx, sy;
            if (!(w & 0x1800) || bm[0][k] || bm[1][k] || (p == 1 && am[0][k])) continue;
            if (fg_spe_x[k] != fg_ex_x[p] || fg_spe_y[k] != fg_ex_y[p]) continue;   /* 같은 이동량(무리 벡터) — 몸 따로 박자(덮어쓴 자리)면 안 붙음 */
            if ((offx ? offx[k] : 0) != mvx || (offy ? offy[k] : 0) != mvy) continue;
            sx = wrapx(base->ax[k] + base->line[0].spx) + mvx; sy = wrapc(base->ay[k] + base->line[0].spy) + mvy;
            if (sx + 8 <= fx0 || sx >= fx1 || sy + 8 <= fy0 || sy >= fy1) continue;
            am[p][k] = 1; na++;
            if (sx < ax0) ax0 = sx;
            if (sx + 8 > ax1) ax1 = sx + 8;
            if (sy < ay0) ay0 = sy;
            if (sy + 8 > ay1) ay1 = sy + 8;
         }
         if (ax0 < 0) ax0 = 0;
         if (ay0 < 0) ay0 = 0;
         if (ax1 > SS2FG_W) ax1 = SS2FG_W;
         if (ay1 > SS2FG_H) ay1 = SS2FG_H;
         if (na && ax1 > ax0 && ay1 > ay0 && (ax1 - ax0) * (ay1 - ay0) <= ID_W * ID_H)
         { dr[p].an = na; dr[p].ax0 = ax0; dr[p].ay0 = ay0; dr[p].ax1 = ax1; dr[p].ay1 = ay1; }
         else memset(am[p], 0, sizeof am[p]);
      }
      if (rq->gw * ID_S * rq->gh * ID_S > (int)(sizeof id_tc / sizeof id_tc[0])) continue;
      if (rq->kind == 1) { mc_draw(rq->e, rq->ti, rq->A, rq->B, img); mc_stats[2]++; }
      else if (rq->kind == 2) id_draw_self(rq->A, img);
      else id_draw(rq->pr, rq->t256, img);
      dr[p].W4 = rq->gw * ID_S; dr[p].gh = rq->gh; dr[p].img = img;
      dr[p].ux0 = rq->ax + rq->gx + mvx; dr[p].uy0 = rq->ay + rq->gy + mvy;
      dr[p].depth = rq->depth; dr[p].first = rq->first;
      for (k = 0; k < 64 && !dr[p].m[k]; k++) ;
      dr[p].cur = k;                                          /* 지금 프레임의 가장 앞 슬롯 — 두 몸끼리 앞뒤는 이것으로 */
      {  /* 캐시 사이 그림의 4배 밀기(패치 99c) + ¼ px 자리(99i) — 틀이 그만큼 한두 픽셀 넓어진다. 조각 버퍼를 넘으면 밀지 않는다 */
         int s4x = rq->sx4 + r4x, s4y = rq->sy4 + r4y, ux0 = dr[p].ux0, uy0 = dr[p].uy0;
         int ex0 = s4x < 0 ? -((-s4x + ID_S - 1) / ID_S) : 0, ex1 = s4x > 0 ? (s4x + ID_S - 1) / ID_S : 0;
         int ey0 = s4y < 0 ? -((-s4y + ID_S - 1) / ID_S) : 0, ey1 = s4y > 0 ? (s4y + ID_S - 1) / ID_S : 0;
         if ((rq->gw + ex1 - ex0) * (rq->gh + ey1 - ey0) > ID_W * ID_H) { s4x = s4y = 0; ex0 = ex1 = ey0 = ey1 = 0; }
         dr[p].sh4x = s4x; dr[p].sh4y = s4y;
         dr[p].x0 = ux0 + ex0 < 0 ? 0 : ux0 + ex0; dr[p].y0 = uy0 + ey0 < 0 ? 0 : uy0 + ey0;
         dr[p].x1 = ux0 + rq->gw + ex1 > SS2FG_W ? SS2FG_W : ux0 + rq->gw + ex1;
         dr[p].y1 = uy0 + rq->gh + ey1 > SS2FG_H ? SS2FG_H : uy0 + rq->gh + ey1;
      }
      if (dr[p].an)
      {  /* 99r: 틀을 붙은 조각까지(옮긴 만큼 한 칸 더) — 조각 버퍼를 넘으면 붙은 조각은 예전처럼 1배 자리에 */
         int nx0 = imin(dr[p].x0, dr[p].ax0 - 1), ny0 = imin(dr[p].y0, dr[p].ay0 - 1);
         int nx1 = imax(dr[p].x1, dr[p].ax1 + 1), ny1 = imax(dr[p].y1, dr[p].ay1 + 1);
         if (nx0 < 0) nx0 = 0;
         if (ny0 < 0) ny0 = 0;
         if (nx1 > SS2FG_W) nx1 = SS2FG_W;
         if (ny1 > SS2FG_H) ny1 = SS2FG_H;
         if ((nx1 - nx0) * (ny1 - ny0) <= ID_W * ID_H) { dr[p].x0 = nx0; dr[p].y0 = ny0; dr[p].x1 = nx1; dr[p].y1 = ny1; }
         else { dr[p].an = 0; memset(am[p], 0, sizeof am[p]); }
      }
      if (dr[p].x1 <= dr[p].x0 || dr[p].y1 <= dr[p].y0) { dr[p].an = 0; memset(am[p], 0, sizeof am[p]); continue; }
      dr[p].on = 1;
   }
   {  /* 99w: 이펙트 사이 그림 — 무리 조각이 모두 같은 만큼 옮겨 그려질 때만(이펙트 옮기기 60·붙은 조각 99r 과 같이) */
      int i;
      for (i = 0; i < FX_N; i++)
      {
         const fx_req_t *fq = &fx_rq[s][i];
         int q = 2 + i, mvx = 0, mvy = 0, seen = 0, same = 1;
         if (!fq->on) continue;
         for (k = 0; k < 64; k++)
            if (fq->m[k])
            {
               int dx = offx ? offx[k] : 0, dy = offy ? offy[k] : 0;
               if ((dr[0].on && dr[0].m[k]) || (dr[1].on && dr[1].m[k])) same = 0;
               if (!seen) { mvx = dx; mvy = dy; seen = 1; }
               else if (dx != mvx || dy != mvy) same = 0;
            }
         if (!seen || !same) continue;
         if (fq->gw * ID_S * fq->gh * ID_S > (int)(sizeof fx_tc[0] / sizeof fx_tc[0][0])) continue;
         mc_draw(fq->e, fq->ti, &fx_pa[s][i], &fx_pb[s][i], fx_tc[i]);
         fx_st[3]++;
         memcpy(dr[q].m, fq->m, 64);
         for (k = 0; k < 64; k++) if (fq->m[k]) am[0][k] = am[1][k] = 0;   /* 몸에 붙은 조각이었으면 그쪽에서 뺀다 */
         dr[q].W4 = fq->gw * ID_S; dr[q].gh = fq->gh; dr[q].img = fx_tc[i];
         dr[q].ux0 = fq->gx + mvx; dr[q].uy0 = fq->gy + mvy;
         dr[q].depth = fq->depth; dr[q].first = fq->first; dr[q].cur = fq->first;
         {
            int s4x = fq->sx4, s4y = fq->sy4, ux0 = dr[q].ux0, uy0 = dr[q].uy0;
            int ex0 = s4x < 0 ? -((-s4x + ID_S - 1) / ID_S) : 0, ex1 = s4x > 0 ? (s4x + ID_S - 1) / ID_S : 0;
            int ey0 = s4y < 0 ? -((-s4y + ID_S - 1) / ID_S) : 0, ey1 = s4y > 0 ? (s4y + ID_S - 1) / ID_S : 0;
            if ((fq->gw + ex1 - ex0) * (fq->gh + ey1 - ey0) > ID_W * ID_H) { s4x = s4y = 0; ex0 = ex1 = ey0 = ey1 = 0; }
            dr[q].sh4x = s4x; dr[q].sh4y = s4y;
            dr[q].x0 = ux0 + ex0 < 0 ? 0 : ux0 + ex0; dr[q].y0 = uy0 + ey0 < 0 ? 0 : uy0 + ey0;
            dr[q].x1 = ux0 + fq->gw + ex1 > SS2FG_W ? SS2FG_W : ux0 + fq->gw + ex1;
            dr[q].y1 = uy0 + fq->gh + ey1 > SS2FG_H ? SS2FG_H : uy0 + fq->gh + ey1;
         }
         if (dr[q].x1 <= dr[q].x0 || dr[q].y1 <= dr[q].y0) continue;
         dr[q].on = 1;
      }
   }
   memset(skip, 0, sizeof skip);
   for (p = 0; p < ID_NR; p++) if (dr[p].on) for (k = 0; k < 64; k++) if (dr[p].m[k]) skip[k] = 1;
   for (q = 0; q < 2; q++)
   {  /* 99r: 붙은 조각 — 몸 뺀 줄에서도 빼고, 따로 1배 그림(창·슬롯 규칙은 render_line 과 같게)을 만들어 4배로 고를 때 몸과 같은 ¼ px 로 */
      int yy, aw;
      if (!dr[q].on || !dr[q].an) continue;
      an_any = 1;
      for (k = 0; k < 64; k++) if (am[q][k]) skip[k] = 1;
      aw = dr[q].ax1 - dr[q].ax0;
      for (yy = dr[q].ay0; yy < dr[q].ay1; yy++)
      {
         const ss2fg_regs *rb = &base->line[yy];
         uint16_t esc[256];
         uint8_t ezb[256];
         int16_t esl[256];
         int xx;
         memset(ezb, 0, sizeof ezb);
         if (yy >= rb->winy && yy < rb->winy + rb->winh)
         {
            int16_t *sv_slot = rl_slot;
            uint8_t *sv_sprz = rl_sprz;
            int sv_cur = rl_cur_slot;
            rl_slot = esl; rl_sprz = 0;
            for (k = 0; k < 64; k++)
            {
               uint16_t d;
               int sxx, syy;
               if (!am[q][k]) continue;
               d = ld16(base->spr + k * 4);
               sxx = wrapx(base->ax[k] + rb->spx) + (offx ? offx[k] : 0);
               syy = wrapc(base->ay[k] + rb->spy) + (offy ? offy[k] : 0);
               if (yy < syy || yy > syy + 7) continue;
               rl_cur_slot = k;
               draw_pattern(base, rb, esc, ezb, sxx, d & 0x01FF, (d & 0x4000) ? 7 - ((unsigned)(yy - syy) & 7) : ((unsigned)(yy - syy) & 7),
                            d & 0x8000, base->pal, base->sprcol[k] & 0xF, (uint8_t)(((d & 0x1800) >> 11) << 1));
            }
            rl_slot = sv_slot; rl_sprz = sv_sprz; rl_cur_slot = sv_cur;
         }
         for (xx = dr[q].ax0; xx < dr[q].ax1; xx++)
         {
            int o = (yy - dr[q].ay0) * aw + (xx - dr[q].ax0);
            al_z[q][o] = ezb[xx];
            al_c[q][o] = ezb[xx] ? esc[xx] : 0;
            al_s[q][o] = (int8_t)(ezb[xx] ? esl[xx] : -1);
         }
      }
   }
   for (p = 0; p < ID_NR; p++)
   {
      id_patch_t *pt = &id_pt[s][p];
      int x0 = dr[p].x0, y0 = dr[p].y0, x1 = dr[p].x1, y1 = dr[p].y1, y, x, sx, sy;
      if (!dr[p].on) continue;
      rl_skip = skip; rl_zout = zrow; rl_slot = srow;
      for (y = y0; y < y1; y++)
      {
         const ss2fg_regs *rb = &base->line[y];
         int in_win = (y >= rb->winy) && (y < rb->winy + rb->winh);
         int wx0 = rb->winx, wx1 = imin(rb->winx + rb->winw, SS2FG_W);
         int spl = fg_sp[s].on && fg_sp[s].any[y];             /* 99j: 배경을 ¼ px 옮긴 줄 */
         if (spl) { rl_sprz = szr; rl_sprc = scr; rl_sprs = ssr; }
         render_line(base, to_scr, offx, offy, t_scr, y, scan);
         rl_sprz = 0; rl_sprc = 0; rl_sprs = 0;
         for (sy = 0; sy < ID_S; sy++)
         {
            uint16_t *dst = pt->px + ((y - y0) * ID_S + sy) * ((x1 - x0) * ID_S);
            const uint16_t *tw[ID_NR];
            for (q = 0; q < ID_NR; q++)
            {
               int ty = (y - dr[q].uy0) * ID_S + sy - dr[q].sh4y;
               tw[q] = (dr[q].on && ty >= 0 && ty < dr[q].gh * ID_S) ? dr[q].img + ty * dr[q].W4 : 0;
            }
            for (x = x0; x < x1; x++)
               for (sx = 0; sx < ID_S; sx++)
               {
                  uint16_t c = scan[x];
                  int z = zrow[x], sl = srow[x], win = -1;
                  if (spl && in_win && x >= wx0 && x < wx1)
                  {  /* 99j: 몸 뺀 줄의 스프라이트 · ¼ px 옮긴 플레인 · 배경색 중 앞 */
                     int zw;
                     c = (uint16_t)sp_px(&fg_sp[s], y, sy, x * ID_S + sx, szr[x], scr[x], &zw);
                     z = zw; sl = (zw > 0 && !(zw & 1)) ? ssr[x] : -1;
                  }
                  if (in_win && x >= wx0 && x < wx1)
                     for (q = 0; q < ID_NR; q++)                 /* 두 몸 + 이펙트(99w) — 앞뒤는 우선순위, 같으면 앞 슬롯 */
                     {
                        int tx;
                        uint16_t v;
                        if (!tw[q]) continue;
                        tx = (x - dr[q].ux0) * ID_S + sx - dr[q].sh4x;
                        if (tx < 0 || tx >= dr[q].W4) continue;
                        v = tw[q][tx];
                        if (v == ID_NONE) continue;
                        if (win < 0 ? (dr[q].depth > z || (dr[q].depth == z && sl > dr[q].first))
                                    : (dr[q].depth > dr[win].depth || (dr[q].depth == dr[win].depth && dr[q].cur < dr[win].cur)))
                        {
                           uint16_t col = ld16(base->pal + ((v >> 2) << 3) + ((v & 3) << 1)) & 0x0FFF;
                           c = rb->neg ? (uint16_t)~col : col;
                           z = dr[q].depth; sl = dr[q].first; win = q;
                        }
                     }
                  if (an_any && in_win && x >= wx0 && x < wx1)
                     for (q = 0; q < 2; q++)                     /* 99r: 붙은 조각 — 몸과 같은 ¼ px 자리에서 */
                     {
                        int X4, Y4, xs, ys, o, ez, es, wz, ws;
                        if (!dr[q].on || !dr[q].an) continue;
                        X4 = x * ID_S + sx - dr[q].r4x; Y4 = y * ID_S + sy - dr[q].r4y;
                        xs = X4 >= 0 ? X4 / ID_S : -((-X4 + ID_S - 1) / ID_S);
                        ys = Y4 >= 0 ? Y4 / ID_S : -((-Y4 + ID_S - 1) / ID_S);
                        if (xs < dr[q].ax0 || xs >= dr[q].ax1 || ys < dr[q].ay0 || ys >= dr[q].ay1) continue;
                        o = (ys - dr[q].ay0) * (dr[q].ax1 - dr[q].ax0) + (xs - dr[q].ax0);
                        ez = al_z[q][o];
                        if (!ez) continue;
                        es = al_s[q][o];
                        if (win >= 0 && win < ID_NR) { wz = dr[win].depth; ws = dr[win].cur; }
                        else { wz = z; ws = sl; }
                        if (ez > wz || (ez == wz && es < ws)) { c = al_c[q][o]; z = ez; sl = es; win = ID_NR + q; }
                     }
                  *dst++ = (uint16_t)colormap[c & 4095];
               }
         }
      }
      rl_skip = 0; rl_zout = 0; rl_slot = 0;
      pt->x0 = x0; pt->y0 = y0; pt->w = x1 - x0; pt->h = y1 - y0; pt->on = 1;
      id_stats[2]++;
   }
}

/* 내보내기 — 원래 그림(16bpp)을 4배로 늘리고 출력 칸 slot 의 조각을 붙인다 */
void ss2fg_idle_compose(uint16_t *dst, int dpitch, const uint16_t *src, int spitch, int w, int h, int slot)
{
   int y, x, sy, p;
   const fg_sp_t *sp = (slot == 0 || slot == 1) && fg_sp[slot].on && fg_sp_cmap && w == SS2FG_W && h == SS2FG_H ? &fg_sp[slot] : 0;
   for (y = 0; y < h; y++)
   {
      uint16_t *row = dst + (size_t)(y * ID_S) * dpitch;
      const uint16_t *s = src + (size_t)y * spitch;
      if (sp && sp->any[y])
      {  /* 99j: 창 안은 4배 화소마다 스프라이트 · ¼ px 옮긴 플레인 · 배경색 중 앞, 창 밖은 그대로.
            세로 ¼ 이 안 걸친 아래 칸은 같은 줄이라 베끼고(가로로만 움직이는 카메라는 1/4 만 계산), 1배 칸마다 앞·뒤 플레인 두 칸만 본다 */
         const uint8_t *SZ = sp->sz[y], *SZ2 = sp->sz2[y];
         const uint16_t *SC = sp->sc[y], *SC2 = sp->sc2[y];
         int wx0 = sp->wx0[y], wx1 = sp->wx1[y], rfx = sp->rfx[y], rbx = sp->rbx[y], pk = -1, pp = sp->pp[y];
         unsigned back = sp->back[y];
         for (sy = 0; sy < ID_S; sy++)
         {
            uint16_t *r = row + (size_t)sy * dpitch;
            int ff = sy + sp->rfy[y] >= ID_S, fb = sy + sp->rby[y] >= ID_S, key = ff | (fb << 1);
            const uint16_t *F = sp->pf[ff][y], *Bk = sp->pb[fb][y];
            if (key == pk) { memcpy(r, r - dpitch, (size_t)w * ID_S * sizeof(uint16_t)); continue; }
            pk = key;
            for (x = 0; x < w; x++)
            {
               uint16_t *o = r + x * ID_S;
               unsigned lf = 0x10000, lb = 0x10000, lo = 0;
               int i;
               if (x < wx0 || x >= wx1) { o[0] = o[1] = o[2] = o[3] = s[x]; continue; }
               for (i = 0; i < ID_S; i++)
               {
                  unsigned f = F[x + ((i + rfx) >> 2)], b = Bk[x + ((i + rbx) >> 2)];
                  if (f != lf || b != lb)
                  {
                     unsigned c = sp_pick(SZ[x], SC[x], f, b, back);
                     if (pp)
                     {  /* 포즈 섞기 — 1배 그림처럼 두 판이 다른 곳만 섞는다 */
                        unsigned c2 = sp_pick(SZ2[x], SC2[x], f, b, back);
                        if (c2 != c) c = mix12((uint16_t)c, (uint16_t)c2, sp->ppa);
                     }
                     lo = (uint16_t)fg_sp_cmap[c & 4095]; lf = f; lb = b;
                  }
                  o[i] = (uint16_t)lo;
               }
            }
         }
         continue;
      }
      for (x = 0; x < w; x++)
      {
         uint16_t v = s[x];
         row[x * 4] = row[x * 4 + 1] = row[x * 4 + 2] = row[x * 4 + 3] = v;
      }
      for (sy = 1; sy < ID_S; sy++) memcpy(row + (size_t)sy * dpitch, row, (size_t)w * ID_S * sizeof(uint16_t));
   }
   if (slot < 0 || slot > 1) return;
   for (p = 0; p < ID_NR; p++)   /* 99w: 몸 둘 + 이펙트 */
   {
      const id_patch_t *pt = &id_pt[slot][p];
      int pw = pt->w * ID_S, r;
      if (!pt->on || pt->x0 + pt->w > w || pt->y0 + pt->h > h) continue;
      for (r = 0; r < pt->h * ID_S; r++)
         memcpy(dst + (size_t)(pt->y0 * ID_S + r) * dpitch + pt->x0 * ID_S, pt->px + (size_t)r * pw, (size_t)pw * sizeof(uint16_t));
   }
}

/* 4배(게임 박자 맞춤)용 — 스프라이트와 스크롤의 목표 프레임·진행도를 따로 준다.
   사무쇼2 는 캐릭터를 짝수 프레임에만, 배경 스크롤을 홀수 프레임에만 움직인다(실측) — 둘의 «다음 바뀌는 때»가
   서로 다르다. to_spr/to_scr 가 0 이거나 t 가 0 이면 그쪽은 base 그대로. */
int ss2fg_render2(const ss2fg_frame *base, const ss2fg_frame *to_spr, int t_spr,
                  const ss2fg_frame *to_scr, int t_scr,
                  void *dst, int pitch_px, int bpp, const uint32_t *colormap)
{
   int y, x;
   uint16_t scan[256];
   fg_move mv[64];
   int16_t offx[64], offy[64];
   int have_off = 0;
   if (!base || !base->valid || base->mono) { fg_ov_on[0] = fg_ov_on[1] = 0; return 0; }
   if (bpp != 2 && bpp != 4) return 0;
   /* 표시 도중 스프라이트표/타일맵이 바뀐 프레임은 끝 시점 사본이 위쪽 줄과 안 맞는다 — 합성 포기 */
   if (base->dirty & (SS2FG_DIRTY_SPR | SS2FG_DIRTY_SCROLL)) return 0;
   if (to_spr && (!to_spr->valid || to_spr->mono || (to_spr->dirty & (SS2FG_DIRTY_SPR | SS2FG_DIRTY_SCROLL)))) to_spr = 0;
   if (to_scr && (!to_scr->valid || to_scr->mono || (to_scr->dirty & (SS2FG_DIRTY_SPR | SS2FG_DIRTY_SCROLL)))) to_scr = 0;
   if (t_spr < 0) t_spr = 0;
   if (t_spr > 256) t_spr = 256;
   if (t_scr < 0) t_scr = 0;
   if (t_scr > 256) t_scr = 256;
   if (to_spr && t_spr == 0) to_spr = 0;
   if (to_scr && t_scr == 0) to_scr = 0;
   fx_fade_on = 0; fx_fade_to = 0;
   if (to_spr) { fx_in_render = 1; sprite_moves(base, to_spr, mv); fx_in_render = 0; }
   else if ((fg_ov_on[0] || fg_ov_on[1]) && base->body_ok) sprite_moves(base, base, mv);   /* 몸 따로 박자만 — 조각 → 몸 표가 필요 */
   else memset(fg_body_of, 0xFF, sizeof fg_body_of);
   {
      int k2;
      have_off = 0;
      for (k2 = 0; k2 < 64; k2++)
      {
         int p2 = fg_body_of[k2];
         offx[k2] = offy[k2] = 0;
         if (p2 >= 0 && fg_ov_on[p2])
         {
            int vx = fg_ov_x[p2], vy = fg_ov_y[p2];
            offx[k2] = (int16_t)(vx >= 0 ? (vx + 128) >> 8 : -((-vx + 127) >> 8));
            offy[k2] = (int16_t)(vy >= 0 ? (vy + 128) >> 8 : -((-vy + 127) >> 8));
            have_off = 1;
         }
         else if (to_spr && mv[k2].has)
         {
            offx[k2] = (int16_t)lerp_i(0, mv[k2].dx, t_spr);
            offy[k2] = (int16_t)lerp_i(0, mv[k2].dy, t_spr);
            have_off = 1;
         }
      }
   }
   {  /* 99i: 몸마다 정확한 옮김(1/256 px) — 몸 따로 박자면 그 값, 아니면 몸 조각의 이동량 × t */
      int p3, k3;
      for (k3 = 0; k3 < 64; k3++)
      {  /* 99r */
         fg_spe_x[k3] = (to_spr && mv[k3].has) ? mv[k3].dx * t_spr : 0;
         fg_spe_y[k3] = (to_spr && mv[k3].has) ? mv[k3].dy * t_spr : 0;
      }
      for (p3 = 0; p3 < 2; p3++)
      {
         fg_ex_on[p3] = 0;
         if (fg_ov_on[p3]) { fg_ex_x[p3] = fg_ov_x[p3]; fg_ex_y[p3] = fg_ov_y[p3]; fg_ex_on[p3] = 1; continue; }
         if (!to_spr) continue;
         for (k3 = 0; k3 < 64; k3++)
            if (fg_body_of[k3] == p3 && mv[k3].has && (ld16(base->spr + k3 * 4) & 0x1800))
            { fg_ex_x[p3] = mv[k3].dx * t_spr; fg_ex_y[p3] = mv[k3].dy * t_spr; fg_ex_on[p3] = 1; break; }
      }
   }
   if (to_spr && fx_mode == 2)
   {
      /* 나타날 to 이펙트 = 몸·그림자 팔레트가 아니고, base 의 «정해진(옮겨 그려지는)» 이펙트 조각이 도착할 자리(8px)에
         있지 않은 조각. 정해진 무리는 base 그림을 옮겨 그리므로 to 쪽을 또 그리면 겹친다 */
      const ss2fg_regs *rb0 = &base->line[0], *rt0 = &to_spr->line[0];
      int i, j, any = 0;
      memset(fx_fade_in, 0, sizeof fx_fade_in);
      for (j = 0; j < 64; j++)
      {
         uint16_t wt = ld16(to_spr->spr + j * 4);
         int tx, ty, cov = 0;
         uint8_t pal = to_spr->sprcol[j];
         if (!(wt & 0x1800) || pal == 0 || pal == 5 || pal == 12) continue;
         tx = wrapx(to_spr->ax[j] + rt0->spx); ty = wrapc(to_spr->ay[j] + rt0->spy);
         for (i = 0; i < 64 && !cov; i++)
         {
            uint16_t wb = ld16(base->spr + i * 4);
            int bx, by;
            if (!(wb & 0x1800) || base->sprcol[i] != pal || fx_fade_b[i]) continue;
            bx = wrapx(base->ax[i] + rb0->spx) + (mv[i].has ? mv[i].dx : 0);
            by = wrapc(base->ay[i] + rb0->spy) + (mv[i].has ? mv[i].dy : 0);
            if (abs(bx - tx) <= 8 && abs(by - ty) <= 8) cov = 1;
         }
         if (!cov) { fx_fade_in[j] = 1; any = 1; }
      }
      for (i = 0; i < 64; i++) if (fx_fade_b[i]) any = 1;
      if (any) { fx_fade_on = 1; fx_fade_to = to_spr; fx_fade_t = t_spr; }
   }

   /* 포즈 섞기 — 번갈아 바뀌는 몸(들)을 고른다 */
   pp_on = 0;
   if (pose_mode && to_spr && t_spr > 0 && t_spr < 256 && base->body_ok && to_spr->body_ok)
   {
      int p, ymin = 999, ymax = -999;
      uint8_t mb[64], mt[64];
      memset(pp_skip, 0, sizeof pp_skip); memset(pp_add, 0, sizeof pp_add);
      for (p = 0; p < 2; p++)
      {
         uint64_t sb, st;
         int k, vx, vy, ox, oy;
         if (fg_ov_on[p]) continue;                              /* 몸 따로 박자 중 — 박자가 달라 안 섞는다 */
         if (!body_mask(base, p, mb) || !body_mask(to_spr, p, mt)) continue;
         sb = body_sig(base, mb); st = body_sig(to_spr, mt);
         if (sb == st) continue;
         pose_stats[0]++;
         if (!pose_alternates(base, to_spr, p, sb, st)) { pose_stats[1]++; continue; }
         pose_stats[2]++;
         vx = (int8_t)(uint8_t)(to_spr->ob_x[p] - base->ob_x[p]);
         vy = (int8_t)(uint8_t)(to_spr->ob_y[p] - base->ob_y[p]);
         if (vx > SS2FG_SPR_MAX_STEP || vx < -SS2FG_SPR_MAX_STEP || vy > SS2FG_SPR_MAX_STEP || vy < -SS2FG_SPR_MAX_STEP) vx = vy = 0;
         ox = lerp_i(0, vx, t_spr) - vx; oy = lerp_i(0, vy, t_spr) - vy;   /* 다음 포즈: 몸 이동만큼 뒤에서 출발 */
         for (k = 0; k < 64; k++)
         {
            int sy;
            if (mb[k])
            {
               pp_skip[k] = 1;
               sy = wrapc(base->ay[k] + base->line[0].spy) + (have_off ? offy[k] : 0);
               if (sy < ymin) ymin = sy;
               if (sy + 7 > ymax) ymax = sy + 7;
            }
            if (mt[k])
            {
               pp_add[k] = 1; pp_dx[k] = (int16_t)ox; pp_dy[k] = (int16_t)oy;
               sy = wrapc(to_spr->ay[k] + to_spr->line[0].spy) + oy;
               if (sy < ymin) ymin = sy;
               if (sy + 7 > ymax) ymax = sy + 7;
            }
         }
         pp_on = 1;
      }
      pp_to = to_spr;
      pp_ymin = ymin; pp_ymax = ymax;
   }

   {  /* 99j: 이 칸(4배 내보내기)의 배경 스크롤 ¼ px — 줄마다 계획한 자리가 1배 그림의 정수 자리와 다르면 다시 고를 줄 */
      fg_sp_t *sp = (bpp == 2 && (id_slot == 0 || id_slot == 1)) ? &fg_sp[id_slot] : 0;
      if (sp)
      {
         int hh = id_slot;
         sp->on = 0;
         fg_sp_cmap = colormap;
         if (sp_planned[hh] && pp_on) sp_stats[2]++;              /* 포즈 섞기 칸(켬 — 두 판 따로 고름) */
         if (sp_planned[hh] && fx_fade_on) sp_stats[3]++;
         sp->ppa = t_spr;
         if (sp_planned[hh] && !fx_fade_on)
         {
            sp_stats[0]++;
            for (y = 0; y < SS2FG_H; y++)
            {
               const ss2fg_regs *rb = &base->line[y];
               int v, need = 0, I[4], R[4], fv, bv, fpl, bpl;
               sp->any[y] = 0; sp->pp[y] = 0;
               if (!(y >= rb->winy && y < rb->winy + rb->winh)) continue;
               fpl = rb->swap ? 2 : 1; bpl = rb->swap ? 1 : 2;
               fv = fpl == 1 ? 0 : 2; bv = bpl == 1 ? 0 : 2;
               for (v = 0; v < 4; v++)
               {
                  int E = sp_E[hh][y][v], G = 0, on = (v >> 1) == (fv >> 1) ? (base->layers & 2) : (base->layers & 1);
                  I[v] = R[v] = 0;
                  if (!on) continue;
                  if (to_scr) G = (int8_t)(uint8_t)(lerp_wrap8(sp_v(rb, v), sp_v(&to_scr->line[y], v), t_scr) - sp_v(rb, v));
                  I[v] = E >= 0 ? E >> 2 : -((-E + 3) >> 2);
                  R[v] = E - 4 * I[v];
                  if (E != 4 * G) need = 1;
               }
               if (!need) continue;
               {
                  uint16_t bc = ld16(base->pal + 0x01E0 + ((rb->bgc & 7) << 1));
                  uint8_t fsx = (uint8_t)(sp_v(rb, fv) + I[fv]), fsy = (uint8_t)(sp_v(rb, fv + 1) + I[fv + 1]);
                  uint8_t bsx = (uint8_t)(sp_v(rb, bv) + I[bv]), bsy = (uint8_t)(sp_v(rb, bv + 1) + I[bv + 1]);
                  sp->back[y] = (uint16_t)((rb->neg ? (uint16_t)~bc : bc) & 0x0FFF);
                  sp->wx0[y] = rb->winx; sp->wx1[y] = (uint8_t)imin(rb->winx + rb->winw, SS2FG_W);
                  sp->rfx[y] = (int8_t)R[fv]; sp->rfy[y] = (int8_t)R[fv + 1];
                  sp->rbx[y] = (int8_t)R[bv]; sp->rby[y] = (int8_t)R[bv + 1];
                  if (base->layers & 2)
                  {
                     sp_row(base, rb, fpl, fsx, (uint8_t)(y + fsy), sp->pf[0][y]);
                     if (R[fv + 1]) sp_row(base, rb, fpl, fsx, (uint8_t)(y + fsy + 1), sp->pf[1][y]);
                  }
                  else { for (x = 0; x <= SS2FG_W; x++) sp->pf[0][y][x] = sp->pf[1][y][x] = 0xFFFF; }
                  if (base->layers & 1)
                  {
                     sp_row(base, rb, bpl, bsx, (uint8_t)(y + bsy), sp->pb[0][y]);
                     if (R[bv + 1]) sp_row(base, rb, bpl, bsx, (uint8_t)(y + bsy + 1), sp->pb[1][y]);
                  }
                  else { for (x = 0; x <= SS2FG_W; x++) sp->pb[0][y][x] = sp->pb[1][y][x] = 0xFFFF; }
               }
               sp->any[y] = 1; sp->on = 1; sp_stats[1]++;
            }
         }
         sp_planned[hh] = 0;
      }
   }
   for (y = 0; y < SS2FG_H; y++)
   {
      fg_sp_t *sp = (bpp == 2 && (id_slot == 0 || id_slot == 1) && fg_sp[id_slot].on && fg_sp[id_slot].any[y]) ? &fg_sp[id_slot] : 0;
      if (sp) { rl_sprz = sp->sz[y]; rl_sprc = sp->sc[y]; }
      render_line(base, to_scr, have_off ? offx : 0, offy, t_scr, y, scan);
      rl_sprz = 0; rl_sprc = 0;
      if (sp && pp_on && y >= pp_ymin && y <= pp_ymax) { sp->pp[y] = 1; rl_sprz = sp->sz2[y]; rl_sprc = sp->sc2[y]; }
      if (pp_on && y >= pp_ymin && y <= pp_ymax)
      {
         uint16_t scan2[256];
         int a = t_spr;
         pp_on = 2;                                             /* 둘째 판: 섞을 몸을 다음 포즈로 */
         render_line(base, to_scr, have_off ? offx : 0, offy, t_scr, y, scan2);
         pp_on = 1;
         for (x = 0; x < SS2FG_W; x++)
            if (scan2[x] != scan[x]) scan[x] = mix12(scan[x], scan2[x], a);
      }
      rl_sprz = 0; rl_sprc = 0;
      if (bpp == 4)
      {
         uint32_t *row = (uint32_t *)dst + (size_t)y * pitch_px;
         for (x = 0; x < SS2FG_W; x++)
            row[x] = colormap[scan[x] & 4095];
      }
      else
      {
         uint16_t *row = (uint16_t *)dst + (size_t)y * pitch_px;
         for (x = 0; x < SS2FG_W; x++)
            row[x] = (uint16_t)colormap[scan[x] & 4095];
      }
   }
   if (bpp == 2) id_build(base, to_scr, t_scr, have_off ? offx : 0, offy, colormap);   /* 서기 사이 그림 조각(패치 100) */
   fg_ov_on[0] = fg_ov_on[1] = 0;                              /* 몸 따로 박자는 한 번 그리기용 */
   pp_on = 0;
   return 1;
}

int ss2fg_render_ex(const ss2fg_frame *base, const ss2fg_frame *to, int t256,
                    void *dst, int pitch_px, int bpp, const uint32_t *colormap)
{
   return ss2fg_render2(base, to, t256, to, t256, dst, pitch_px, bpp, colormap);
}

int ss2fg_render(const ss2fg_frame *base, const ss2fg_frame *to, int t256,
                 uint16_t *dst, int pitch_px, const uint32_t *colormap)
{
   return ss2fg_render_ex(base, to, t256, dst, pitch_px, 2, colormap);
}

/* a→b 사이에 무엇이 움직였나 — 비트0 스프라이트(무리 합의·겉모습 짝짓기를 거친 최종 이동량이 0 이 아닌 조각),
   비트1 스크롤(어느 줄이든 플레인 스크롤값이 다름). 4배 모드가 «다음에 바뀌는 프레임»을 찾을 때 쓴다. */
int ss2fg_motion(const ss2fg_frame *a, const ss2fg_frame *b)
{
   int f = 0, i, y;
   fg_move mv[64];
   if (!a || !b || !a->valid || !b->valid) return 0;
   sprite_moves(a, b, mv);
   for (i = 0; i < 64; i++)
      if (mv[i].has && (mv[i].dx || mv[i].dy)) { f |= 1; break; }
   for (y = 0; y < SS2FG_H; y++)
   {
      const ss2fg_regs *ra = &a->line[y], *rb = &b->line[y];
      if (ra->s1x != rb->s1x || ra->s1y != rb->s1y || ra->s2x != rb->s2x || ra->s2y != rb->s2y) { f |= 2; break; }
   }
   return f;
}
