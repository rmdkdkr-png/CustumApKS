//---------------------------------------------------------------------------
// NEOPOP : Emulator as in Dreamland
//
// Copyright (c) 2001-2002 by neopop_uk
//---------------------------------------------------------------------------

//---------------------------------------------------------------------------
//	This program is free software; you can redistribute it and/or modify
//	it under the terms of the GNU General Public License as published by
//	the Free Software Foundation; either version 2 of the License, or
//	(at your option) any later version. See also the license.txt file for
//	additional informations.
//---------------------------------------------------------------------------

#include <stdlib.h>
#include <string.h>

#include "neopop.h"
#include "flash.h"
#include "interrupt.h"
#include "rom.h"
#include "../mednafen-types.h"

#ifdef MSB_FIRST
#define HTOLE16(l)      ((((l)>>8) & 0xff) | (((l)<<8) & 0xff00))
#else
#define HTOLE16(l) (l)
#endif

#define MATCH_CATALOG(c, s)	(rom_header->catalog == HTOLE16(c) \
				 && rom_header->subCatalog == (s))

RomInfo ngpc_rom;
RomHeader* rom_header = NULL;

/* 코어 패치 zz_ss2_ko_guard — 사무쇼2 막타 반응 표 지킴이.
   막타(맞는 쪽 체력 0)의 반응은 0x2246FE 에서 KO 전용 표(포인터 0x224825 → 0x224A7F·0x224BA8, 297칸씩)를 먼저 본다.
   원판은 두 표가 0xFF(= 보통 표를 써라)뿐이고 0x77 이 12칸 있을 뿐이다. 한글패치(동봉 ss2_ko.ips·v1.01 모두)가
   이 «빈 것처럼 보이는» 0xFF 자리에 글자 그림을 넣어, 막타가 반응 0x7B~0x7F(반응 대본 표 0x2414F1 은 123개뿐)를 고르면
   대본이 엉뚱한 데로 튄다 — 0x7C 는 그 프레임에서 멈춤(유저 «프리징»), 0x7B·0x7E 는 KO 뒤 라운드가 안 끝남.
   비교 두 바이트만 바꿔 «0x77 일 때만 KO 표 값을 쓰고, 아니면 보통 표»로 한다:
   cp D,0xFF / jr Z  →  cp D,0x77 / jr NZ. 원판에선 칸이 0xFF·0x77 뿐이라 동작이 똑같다(실측: 램 바이트까지 같음).
   롬 파일·md5 는 그대로 — 메모리 안 사본만 고친다. 상태 불러오기가 롬을 orig_data 로 되돌리므로(system.c) 거기서도 다시 부른다. */
static void ss2_ko_reaction_guard(void)
{
   static const uint8 want[14] = { 0xC3,0x07,0xEC,0xE4,0x24, 0xCC,0xCF,0xFF, 0x66,0x04, 0xCC,0x8B, 0x68,0x0F };
   if (!MATCH_CATALOG(48, 26) || ngpc_rom.length < 0x024716)
      return;                                   /* 사무쇼2 가 아니다 */
   if (memcmp(ngpc_rom.data + 0x024708, want, sizeof want))
      return;                                   /* 모르는 판 — 손대지 않는다 */
   ngpc_rom.data[0x02470F] = 0x77;              /* cp D,0xFF → cp D,0x77 */
   ngpc_rom.data[0x024710] = 0x6E;              /* jr Z      → jr NZ     */
}


/* ==== u159 topicD EXPERIMENT (scratch only): in-memory ROM overlay for stage pick / stage palette variants ====
   retro_ngp_rom_overlay(cart_addr, data, len): set bytes of the in-memory ROM copy (only inside whitelisted stage regions);
   data == NULL or len == 0 -> restore every overlaid byte from orig_data and forget. Re-applied by rom_hack() (load + state load). */
#define OV_MAX 8192
static uint32 ov_off[OV_MAX]; static uint8 ov_val[OV_MAX]; static int ov_n = 0;
static int ov_ok(uint32 off)
{
   uint32 a = off + 0x200000;
   if (!MATCH_CATALOG(48, 26)) return 0;
   return (a >= 0x239056 && a < 0x2390A6)      /* bout -> stage table (10 x 8) */
       || (a >= 0x259190 && a < 0x25AF88)      /* global palette table incl. zero padding 0x25A9D8.. */
       || (a >= 0x2CA0E2 && a < 0x2CA1E2)      /* stage table 16 x 16 */
       || (a >= 0x2D8086 && a < 0x2D8270);     /* palette-set lists (bgc, bg colour, indices) */
}
void retro_ngp_rom_overlay(uint32_t cart_addr, const uint8_t *data, uint32_t len)
{
   uint32 i; int k;
   if (!ngpc_rom.data) return;
   if (!data || !len) {
      for (k = 0; k < ov_n; k++) ngpc_rom.data[ov_off[k]] = ngpc_rom.orig_data ? ngpc_rom.orig_data[ov_off[k]] : ngpc_rom.data[ov_off[k]];
      ov_n = 0; return;
   }
   for (i = 0; i < len; i++) {
      uint32 off = cart_addr - 0x200000 + i;
      if (cart_addr < 0x200000 || off >= ngpc_rom.length || !ov_ok(off)) continue;
      for (k = 0; k < ov_n; k++) if (ov_off[k] == off) break;
      if (k == ov_n) { if (ov_n >= OV_MAX) return; ov_off[ov_n++] = off; }
      ov_val[k] = data[i]; ngpc_rom.data[off] = data[i];
   }
}
static void ov_apply(void) { int k; for (k = 0; k < ov_n; k++) ngpc_rom.data[ov_off[k]] = ov_val[k]; }

void rom_hack(void)
{
   ss2_ko_reaction_guard();
   ov_apply();

   /*=============================
    * SPECIFIC ROM HACKS !
    *=============================
    */

   /* "Neo-Neo! V1.0 (PD)" */
   if (MATCH_CATALOG(0, 16))
      ngpc_rom.data[0x23] = 0x10;	/* Fix ROM header */

   /* "Cool Cool Jam SAMPLE (U)" */
   if (MATCH_CATALOG(4660, 161))
      ngpc_rom.data[0x23] = 0x10;	/* Fix ROM header */

   /* "Dokodemo Mahjong (J)" */
   if (MATCH_CATALOG(51, 33))
      ngpc_rom.data[0x23] = 0x00;	/* Fix ROM header */
}

void rom_loaded(uint8_t *buf, size_t len)
{
   int i;

   ngpc_rom.data = (uint8 *)malloc(ngpc_rom.length);
   memcpy(ngpc_rom.data, buf, len);

   /* Extract the header */
   rom_header = (RomHeader*)(ngpc_rom.data);

   /* ROM Name */
   for(i = 0; i < 12; i++)
   {
      ngpc_rom.name[i] = ' ';
      if (rom_header->name[i] >= 32 && rom_header->name[i] < 128)
         ngpc_rom.name[i] = rom_header->name[i];
   }
   ngpc_rom.name[i] = 0;

   /* Apply a hack if required! */
   rom_hack();	

   flash_read();
}

void rom_unload(bool is_persistent)
{
   if (ngpc_rom.data)
   {
      int i;

      flash_commit();

      free(ngpc_rom.data);
      ngpc_rom.data = NULL;
      ngpc_rom.length = 0;
      rom_header = 0;

      for (i = 0; i < 16; i++)
         ngpc_rom.name[i] = 0;
   }		

   if(ngpc_rom.orig_data)
   {
      if (!is_persistent)
         free(ngpc_rom.orig_data);
      ngpc_rom.orig_data = NULL;
   }
}
