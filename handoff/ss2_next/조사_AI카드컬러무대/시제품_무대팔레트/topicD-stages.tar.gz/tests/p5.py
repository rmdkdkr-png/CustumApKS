"""what sets 0x5818? from stage-0 round-1 state (no hub): scenario lose / draw / win; watch 5818, 624D, 5827, MODE"""
import sys
from dp import *
sc = sys.argv[1]
p = P('ko', wd=W + '/wd_p5')
p.load(W + '/r1_st0_ROM_KO.st'); p.frame = 0
prev = None; rnd = 0; wait = None
for f in range(9000):
    live = p.peek(0x40A7) == 241 and p.peek(0x411A) == 1 and p.peek(0x5824) == 0 and p.peek(0x5A46) > 0 and p.peek(0x5C46) > 0
    if live:
        if wait is None: wait = f + 60
        if f >= wait:
            if sc == 'lose': p.poke(0x5A46, 0)
            elif sc == 'win': p.poke(0x5C46, 0)
            elif sc == 'draw': p.poke(0x5A46, 0); p.poke(0x5C46, 0)
            elif sc == 'time': p.poke(0x5A46, 50); p.poke(0x5C46, 50); p.poke(0x582F, 2); p.poke(0x5830, 0)
            rnd += 1; wait = None
    if not live and f % 40 == 0 and p.peek(0x40A7) != 241: p.press('A', 3); continue
    p.run(1)
    v = (p.peek(0x5818), p.peek16(0x624D), p.peek(0x5827), p.peek(0x40A7), p.peek(0x41C0), p.peek(0x57CB), p.peek(0x5821), p.peek(0x5822), p.peek(0x57FE))
    if v != prev:
        print('%5d 5818=%d 624D=%04X bout=%d MODE=%d SCR=%d 57CB=%02X W=%d/%d ch57FE=%d' % ((f,) + v)); prev = v
    if f in (3000, 6000, 8999): p.shot(W + '/p5_%s_%d.png' % (sc, f), scale=1)
