"""offline variant previews (static renderer) — scratch only"""
import os
from PIL import Image, ImageDraw
import rs, tint
W = os.environ['LEAGUE_WORK']
ENT = [(0, 'bout0 Fuji'), (6, 'bout1 lake'), (2, 'bout2 shrine'), (5, 'bout3 temple red'), (4, 'bout4 temple day'), (10, 'bout5 cave'), (12, 'bout6 altar'), (13, 'bout7 crystal')]
FNS = ['orig', 'night', 'sunset', 'snow', 'bloodmoon']
cols = len(FNS); rows = len(ENT)
out = Image.new('RGB', (cols * 324, rows * 132), (255, 255, 255))
for r, (e, name) in enumerate(ENT):
    st = rs.stage(e)
    for c, fnn in enumerate(FNS):
        if fnn == 'orig': im = rs.render(st)
        else:
            fn = tint.FN[fnn]; pals = [[p[0]] + [fn(x) for x in p[1:]] for p in st['pals']]
            im = rs.render(st, pals=pals, bg=fn(st['bg']))
        out.paste(im, (c * 324, r * 132))
out.save(W + '/variants_static.png')
print('ok', out.size)
