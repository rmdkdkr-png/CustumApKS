"""from pre-load state, log VRAM writes + ROM data reads with PC"""
import sys
from dp import *
s = int(sys.argv[1]); n = int(sys.argv[2]) if len(sys.argv) > 2 else 100
p = P('ko', wd=W + '/wd_p4')
p.load(W + '/pre_st%d.st' % s); p.frame = 0
log = W + '/p4_st%d.log' % s
p.watch(log, [(0x8300, 0x837F), (0x83E0, 0x83FF), (0x9800, 0x9FFF), (0xA000 + 0x107 * 16, 0xBFFF)], romlog=True)
for i in range(n):
    p.poke(0x5827, s); p.run(1)
p.unwatch()
print('pal2 now', hx3(p.palb(), 0, 0x80), 'mode', p.peek(0x40A7))
