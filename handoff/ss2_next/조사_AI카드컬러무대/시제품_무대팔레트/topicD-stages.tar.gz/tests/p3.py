"""prep (clean mode, debug core) and save a state ~N frames before stage palettes appear"""
import os, sys, ctypes as C, collections
import lh, ph
from ph import hub
import hosttest as T
import q_common as Q
lg = ph.lg
W = os.environ['LEAGUE_WORK']
s = int(sys.argv[1]); back = int(sys.argv[2]) if len(sys.argv) > 2 else 40
v = open(W + '/p1/st%d.vram' % s, 'rb').read(); want = v[0x100:0x110]
h = lh.mk(os.environ['ROM_KO'], 'p3_%d' % s, fast=True); p = h.p
ring = collections.deque(maxlen=back + 2); done = [None]
def hook(hh):
    if done[0] is not None: return
    ring.append((hh.frames, hh.serialize(), (lg.league_hub_status, )))
    if C.string_at(hh.pal + 0x100, 16) == want:
        f, st, _ = ring[0]
        open(W + '/pre_st%d.st' % s, 'wb').write(st); done[0] = (f, hh.frames)
        print('stage pal appears at frame', hh.frames, 'saved state of frame', f, 'MODE', p.peek(0x40A7), 'SCR', p.peek(0x41C0), flush=True)
h.pre_hook = hook
lg.league_hub(1, Q.NONE, Q.ONE); lg.league_hub_ranked(1)
ph.to_title(h); h.press('A', 4, 30)
assert lg.league_hub_match(4, 0, 1, s, -1, -1, -1, -1, -1, 1) == 1
f = 0
while f < 600 and not (p.peek(0x40A7) == 240 and p.peek(0x41C0) == 2 and hub()[7] == 0): h.run(1); f += 1
h.run(30); h.press('A', 4, 200); h.press('A', 4, 200); h.run(240)
Q.to_round1(h)
print('done', done[0], 'frames', h.frames, T.status()[:5])
