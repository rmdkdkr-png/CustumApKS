"""topicC — 상대(P2) 컬러 시제품 측정 공통. host_p2.so(look.c 사본 + look_set_opp) + 실제 코어.
흐름 = q_common.prep 과 같은 랭크 허브(찾기 → league_hub_match → 내 캐릭터 → 첫 라운드) + 결판 + 승리 대사(걸쇠)까지, 매 프레임 팔레트 기록."""
import os, sys, ctypes as C, zlib
import lh, ph
from ph import hub
import hosttest as T
lg = ph.lg
lg.league_hub_match.argtypes = [C.c_int] * 10; lg.league_hub_match.restype = C.c_int
lg.league_post_hold.restype = C.c_int
HAS_OPP = hasattr(lg, 'look_set_opp')
if HAS_OPP:
    lg.look_set_opp.argtypes = [C.c_int] * 14
    lg.look_opp_status.argtypes = [C.c_void_p]
NONE = (C.c_byte * 15)(*([-1] * 15)); ONE = (C.c_byte * 15)(*([1] * 15))
W = os.environ['LEAGUE_WORK']

def st():
    v = (C.c_int * 64)(); lg.league_status(v); return list(v)[:26]
def opp_st():
    v = (C.c_int * 4)(); lg.look_opp_status(v); return list(v)

class HoldLH(lh.LH):
    """native.c 처럼: 걸쇠(league_post_hold)가 서 있으면 다음 프레임을 돌리지 않는다"""
    ran = 0
    def run(self, n=1):
        for _ in range(n):
            if lg.league_post_hold(): continue
            super().run(1); self.ran += 1

def mk(name, fast=True):
    import hosttest
    hosttest.Harness.__init__.__defaults__ = (not fast,)
    h = HoldLH(os.environ[os.environ.get('QROM', 'ROM_KO')], os.path.join(W, name))
    L = h.p.lib; L.retro_ngp_spritecol.restype = C.c_void_p; h.col = L.retro_ngp_spritecol()
    return h

def pal(h, p):
    b = C.string_at(h.pal + p * 8, 8); return tuple((b[2 * j] | (b[2 * j + 1] << 8)) & 0xFFF for j in range(1, 4))
def spr_pals(h):
    """보이는 스프라이트(우선순위 비트 ≠ 0)가 쓰는 팔레트 번호 → 개수"""
    sv = C.string_at(h.spr, 256); col = C.string_at(h.col, 64); d = {}
    for i in range(64):
        if (sv[i * 4 + 1] >> 3) & 3: d[col[i] & 15] = d.get(col[i] & 15, 0) + 1
    return d

WATCH = [('MODE', 0x40A7), ('SCR', 0x41C0), ('FIGHT', 0x411A), ('KO', 0x5823), ('RES', 0x5824), ('RSCR', 0x5825),
         ('W1', 0x5821), ('W2', 0x5822), ('P1B', 0x5B51), ('P2B', 0x5D51), ('OPP', 0x57DF), ('SEQ', 0x57CB)]
def snap(p): return tuple(p.peek(a) for _, a in WATCH)
def fmt(v): return ' '.join('%s=%02X' % (WATCH[i][0], x) for i, x in enumerate(v))

class Rec:
    """pre_hook(코어가 그 프레임을 다 그린 직후 — look 의 프레임 뒤 고쳐 쓰기 전)에 팔레트 0·5 와 스프라이트 팔레트를 본다."""
    def __init__(self, h, tag, b0, b1, tgt, p1base=None, p1tgt=None, shots=True):
        self.h = h; self.tag = tag; self.b0, self.b1, self.tgt = tuple(b0), tuple(b1), tuple(tgt)
        self.p1base, self.p1tgt = p1base, p1tgt
        self.n = 0; self.cnt = {}; self.leak = []; self.p1leak = []; self.other_pal = {}; self.phase_cnt = {}
        self.prev = None; self.shots = shots; self.shot_n = 0; self.last_shot = -999
        self.d = os.path.join(W, tag); os.makedirs(self.d, exist_ok=True)
        self.log = open(os.path.join(self.d, 'log.txt'), 'w')
    def phase(self, v):
        md, sc = v[0], v[1]
        if md == 241: return 'fight' if v[4] == 0 else 'fight_end'
        if md == 240 and sc in (2, 4, 6): return 'select%d' % sc
        if md == 240 and sc == 8: return 'intro8'
        if md == 240 and sc == 10: return 'between10'
        return 'm%d_s%d' % (md, sc)
    def __call__(self, h):
        p = h.p; self.n += 1
        v = snap(p); ph_ = self.phase(v)
        p5 = pal(h, 5); p0 = pal(h, 0); sp = spr_pals(h)
        cls = 'tgt' if p5 == self.tgt else 'b0' if p5 == self.b0 else 'b1' if p5 == self.b1 else 'other'
        uses5 = sp.get(5, 0)
        key = (ph_, cls, uses5 > 0)
        self.cnt[key] = self.cnt.get(key, 0) + 1
        if cls in ('b0', 'b1') and uses5 and not ph_.startswith('select'): self.leak.append((self.n, ph_, cls))
        if self.p1base is not None and p0 == tuple(self.p1base) and sp.get(0, 0) and not ph_.startswith('select'): self.p1leak.append((self.n, ph_))
        # 다른 팔레트에 P2 원래 색(기본·2P색)이 있고 스프라이트가 그 팔레트를 쓰나
        for q in range(16):
            if q in (5,): continue
            t = pal(h, q)
            if (t == self.b0 or t == self.b1) and sp.get(q, 0):
                k = (ph_, q); self.other_pal[k] = self.other_pal.get(k, 0) + 1
        if v != self.prev:
            self.log.write('%6d %-10s %s p5=%s(%s) p0=%s spr=%s\n' % (self.n, ph_, fmt(v), '/'.join('%03X' % c for c in p5), cls,
                           '/'.join('%03X' % c for c in p0), sorted(sp.items())))
        if self.shots and self.shot_n < 60 and ((self.prev is None or v[:2] != self.prev[:2] or v[4] != self.prev[4] or v[5] != self.prev[5]) or self.n - self.last_shot >= 300):
            p.shot(os.path.join(self.d, 'f%05d_%s_%s.png' % (self.n, ph_, cls)), scale=1); self.shot_n += 1; self.last_shot = self.n
        self.prev = v
    def report(self):
        self.log.close()
        return dict(frames=self.n, leak=len(self.leak), leak_first=self.leak[:5], p1leak=len(self.p1leak), p1leak_first=self.p1leak[:5],
                    other_pal=self.other_pal, cnt=self.cnt)

def to_round1(h, limit=6000):
    p = h.p; f = 0
    while f < limit and not st()[3]:
        md, sc = p.peek(0x40A7), p.peek(0x41C0)
        if md == 240 and sc == 6 and f % 60 == 0: h.press('R', 4, 10); h.press('A', 4, 30); f += 48; continue
        if f % 30 == 0 and ((md == 241 and sc == 0 and p.peek(0x411A) == 0) or (md == 240 and sc == 8) or (md != 241 and sc not in (2, 4, 6))): h.press('A', 4); f += 4
        else: h.run(1); f += 1
    return f

def go_select(h, opp, sty, stage=3):
    p = h.p
    lg.league_hub(1, NONE, ONE); lg.league_hub_ranked(1)
    ph.to_title(h)
    h.press('A', 4, 30)
    assert hub()[0] == 6, hub()
    assert lg.league_hub_match(opp, sty, 1, stage, -1, -1, -1, -1, -1, 1) == 1
    f = 0
    while f < 600 and not (p.peek(0x40A7) == 240 and p.peek(0x41C0) == 2 and hub()[7] == 0): h.run(1); f += 1

def pick_me(h, my_moves='', style='A'):
    for m in my_moves: h.press(m, 4, 30)
    h.run(30); h.press('A', 4, 200)
    if style == 'R': h.press('R', 4, 30)
    if style == 'L': h.press('L', 4, 30)
    h.press('A', 4, 200); h.run(240)

def kill(p, who):
    if who & 1: p.poke(0x5C46, 0)
    if who & 2: p.poke(0x5A46, 0)

def to_done(h, seq, limit=30000, mash_fn=None):
    p = h.p; f = 0; rnd = 0; wait = None
    while f < limit and not st()[4]:
        live = p.peek(0x40A7) == 241 and p.peek(0x411A) == 1 and p.peek(0x5824) == 0 and p.peek(0x5A46) > 0 and p.peek(0x5C46) > 0
        if live:
            if wait is None: wait = f + 240
            if f >= wait:
                kill(p, seq[min(rnd, len(seq) - 1)]); rnd += 1; wait = None
        if not live and p.peek(0x40A7) != 241 and f % 60 == 0: h.press('A', 2); f += 2; continue
        h.run(1); f += 1
    return st()

def to_quote(h, n=3000):
    r0 = h.ran; f = 0
    while h.ran - r0 < n and f < n + 50:
        if h.ran - r0 == 15: lg.league_disarm()
        h.run(1); f += 1
        if lg.league_post_hold(): return h.ran - r0
    return None
