import sys, bisect, collections
W = '/tmp/claude-0/-home-user-CustumApKS/e6c46352-6bb9-5a9d-8b3a-f2da7447674e/scratchpad/u159/topicD-stages/work'
def region(a):
    if 0x8200 <= a < 0x8280: return 'sprpal'
    if 0x8280 <= a < 0x8300: return 's1pal'
    if 0x8300 <= a < 0x8380: return 's2pal'
    if 0x83E0 <= a < 0x83F0: return 'bgcol'
    if 0x83F0 <= a < 0x8400: return 'wincol'
    if 0x8380 <= a < 0x83E0: return 'palhole'
    if 0x9800 <= a < 0xA000: return 'map2'
    if 0xA000 <= a < 0xC000: return 'tiles106+'
    if 0x8000 <= a < 0x8040 or a == 0x8118: return 'reg%04X' % a
    return 'other'
for s in range(8):
    ph = [l.split() for l in open(W + '/p7_st%d_phase.txt' % s)]
    fr = [int(x[0]) for x in ph]
    def phase(f):
        i = bisect.bisect_right(fr, f) - 1
        x = ph[max(i, 0)]; m, sc, fi = int(x[1]), int(x[2]), int(x[3])
        if m == 241 and fi == 1: return 'FIGHT'
        if m == 241: return 'M241f%d' % fi
        return 'M240s%d' % sc
    cnt = collections.Counter(); pcs = collections.defaultdict(collections.Counter); frames = collections.defaultdict(set)
    s2pal_fight = collections.Counter()
    for line in open(W + '/p7_st%d.log' % s):
        t = line.split()
        if not t[2].startswith('W'): continue
        f = int(t[0]); pc = t[1]; a = int(t[3], 16); r = region(a); phs = phase(f)
        if r.startswith('reg') and r not in ('reg8118',): r = 'regs'
        cnt[(phs, r)] += 1; pcs[(phs, r)][pc] += 1; frames[(phs, r)].add(f)
        if r == 's2pal' and phs == 'FIGHT': s2pal_fight[((a - 0x8300) // 8, pc)] += 1
    print('=== stage %d phases: %s' % (s, ' '.join('%s@%s' % (x[0], 'M%sS%sF%s r%s 624D=%s' % (x[1], x[2], x[3], x[4], x[5])) for x in ph[:40])))
    for k in sorted(cnt):
        if k[1] in ('regs',): continue
        print('  %-10s %-10s writes %6d frames %4d  PCs %s' % (k[0], k[1], cnt[k], len(frames[k]), dict(pcs[k].most_common(5))))
    if s2pal_fight: print('  FIGHT s2pal by (palette, PC):', dict(s2pal_fight.most_common(20)))
