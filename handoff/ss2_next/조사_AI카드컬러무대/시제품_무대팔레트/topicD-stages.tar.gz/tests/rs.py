"""static stage renderer from ROM tables (reimplements 0x2014A9 loader) -> PNG 320x128 per table entry"""
import sys, os
from PIL import Image
from dp import ROMS, W, rgb
romname = (sys.argv[1] if len(sys.argv) > 1 else 'ko') if __name__ == '__main__' else 'ko'
rom = open(ROMS[romname], 'rb').read()
def r8(a): return rom[a - 0x200000]
def r16(a): return r8(a) | r8(a + 1) << 8
def r24(a): return r16(a) | r8(a + 2) << 16
def r32(a): return r16(a) | r16(a + 2) << 16
M8 = r32(0x250008) & 0xFFFFFF
ST, PS_OFF, PS_BASE = r24(M8), r24(M8 + 3), r24(M8 + 6)
PALTAB = r32(0x250038) & 0xFFFFFF
def stage(e):
    a = ST + 16 * e
    cnt = r16(a); tp = r24(a + 2); ps = r8(a + 5); bmo = r16(a + 6); mto = r16(a + 8)
    s16 = lambda v: v - 0x10000 if v & 0x8000 else v
    bm = tp + s16(bmo); mt = tp + s16(mto)
    w, hh = r8(bm), r8(bm + 1); bm += 2
    pso = r16(PS_OFF + 2 * ps); pl = PS_BASE + pso
    bgc = r8(pl - 3); bgv = r16(pl - 2)
    idx = []
    q = pl
    while len(idx) < 16:
        v = r16(q); q += 2
        if v == 0xFFFF: break
        idx.append(v)
    pals = [[r16(PALTAB + v + 2 * j) & 0xFFF for j in range(4)] for v in idx]
    chr_ = bytearray(512 * 16); chr_[0x106 * 16:0x106 * 16 + cnt] = rom[tp - 0x200000:tp - 0x200000 + cnt]
    return dict(e=e, cnt=cnt, tp=tp, ps=ps, bm=bm, mt=mt, w=w, h=hh, bgc=bgc, bg=bgv, palidx=idx, pals=pals, chr=chr_, psaddr=pl)
def tilepx(chr_, t, x, y):
    v = chr_[t * 16 + y * 2] | chr_[t * 16 + y * 2 + 1] << 8
    return (v >> ((7 - x) * 2)) & 3
def render(st, pals=None, bg=None):
    pals = pals or st['pals']; bg = st['bg'] if bg is None else bg
    W_, H_ = 10 * 32, 4 * 32
    im = Image.new('RGB', (W_, H_), rgb(bg)); px = im.load()
    maxmt = 0
    for by in range(4):
        for bx in range(10):
            m = r8(st['bm'] + by * 10 + bx); flip = m & 0x80; mi = m & 0x7F; maxmt = max(maxmt, mi)
            base = st['mt'] + mi * 32
            for ty in range(4):
                for tx in range(4):
                    sx = 3 - tx if flip else tx
                    e = r16(base + (ty * 4 + sx) * 2)
                    if flip: e ^= 0x8000
                    t = e & 0x1FF; pl = (e >> 9) & 15; hf = e & 0x8000; vf = e & 0x4000
                    for y in range(8):
                        for x in range(8):
                            i = tilepx(st['chr'], t, 7 - x if hf else x, 7 - y if vf else y)
                            if i and pl < len(pals): px[bx * 32 + tx * 8 + x, by * 32 + ty * 8 + y] = rgb(pals[pl][i])
                            elif i: px[bx * 32 + tx * 8 + x, by * 32 + ty * 8 + y] = (255, 0, 255)
    st['maxmt'] = maxmt
    return im
if __name__ == '__main__':
    os.makedirs(W + '/rs', exist_ok=True)
    ims = []
    for e in range(16):
        st = stage(e); im = render(st); ims.append(im)
        im.save(W + '/rs/%s_e%02d.png' % (romname, e))
        print('e%2d tiles %06X %4dB palset %2d @%06X bgc %02X bg %03X npal %2d palidx %s.. blk %dx%d metatiles used max %d (%dB) bm %06X mt %06X' % (
            e, st['tp'], st['cnt'], st['ps'], st['psaddr'], st['bgc'], st['bg'], len(st['pals']), ['%03X' % v for v in st['palidx'][:3]], st['w'], st['h'], st['maxmt'], (st['maxmt'] + 1) * 32, st['bm'], st['mt']))
    out = Image.new('RGB', (2 * 324, 8 * 132), (255, 255, 255))
    for i, im in enumerate(ims): out.paste(im, ((i % 2) * 324, (i // 2) * 132))
    out.resize((out.width * 2, out.height * 2), Image.NEAREST).save(W + '/rs/%s_all.png' % romname)
