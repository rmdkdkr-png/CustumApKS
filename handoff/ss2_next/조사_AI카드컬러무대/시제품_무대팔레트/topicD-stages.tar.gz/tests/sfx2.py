"""cut-in (MAX secret technique) with/without stage-palette overlay; per-frame plane-2 class + screenshots"""
import sys, random, ctypes as C
from dp import *
import aex, tint
s, N, seed, mode = int(sys.argv[1]), int(sys.argv[2]), int(sys.argv[3]), sys.argv[4]
random.seed(seed)
p = P('ko', wd=W + '/wd_sfx2_%s' % mode); L = p.lib
L.retro_ngp_rom_overlay.argtypes = [C.c_uint32, C.c_char_p, C.c_uint32]; L.retro_ngp_rom_overlay(0, None, 0)
L.retro_ngp_bgtint(None)
fn = tint.night
if mode == 'pv':
    for a, b in tint.overlay_for_entries(tint.BOUT_ENTRIES[s], fn): L.retro_ngp_rom_overlay(a, b, len(b))
if mode == 'lut':
    L.retro_ngp_bgtint((C.c_uint16 * 4096)(*tint.lut(fn)))
p.load(W + '/r1_st%d_ROM_KO.st' % s); p.frame = 0
if mode in ('pv', 'lut'):   # state was saved untinted: force the first stage reload like a real match start would have
    pass
BTN = ['L', 'R', 'U', 'D', 'A', 'B', 'DA', 'DB', 'LA', 'RA', 'DRA', 'DLA', 'AB', 'DR', 'DL', 'UR']
out = open(W + '/sfx2_%s.txt' % mode, 'w')
for f in range(N):
    if p.peek(0x40A7) == 241 and p.peek(0x411A) == 1:
        if f % 4 == 0: p.release(); p.hold(*random.choice(BTN))
        if f % 200 == 0:
            for a in (0x5A47, 0x5C47):
                if p.peek(a) < 0x2F: p.poke(a, 0x2F)
        p.poke(0x5A46, max(p.peek(0x5A46), 60)); p.poke(0x5C46, max(p.peek(0x5C46), 60)); p.poke(0x582F, 0x80); p.poke(0x5830, 0x07)
    else:
        p.release()
        if f % 30 == 0: p.press('A', 2)
    p.run(1)
    e = p.peek16(0x624D) // 16; ra, st = aex.rom_s2(e); rb, _ = aex.rom_s2(e, fn)
    s2 = p.palb()[0x100:0x180]
    cls = 'orig' if s2[:len(ra)] == ra else 'tint' if s2[:len(rb)] == rb else 'other'
    out.write('%d %d %d %s %s %08X\n' % (f, p.peek(0x5B53), p.peek(0x5D53), cls, s2.hex(), __import__('zlib').crc32(p.palb()[:0x100])))
    if f in (640, 660, 700, 1000): p.shot(W + '/sfx2_%s_f%d.png' % (mode, f), scale=1)
