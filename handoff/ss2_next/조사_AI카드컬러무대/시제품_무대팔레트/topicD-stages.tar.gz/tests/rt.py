"""decode stage table from ROM (static)"""
import sys, struct
from dp import ROMS
rom = open(ROMS[sys.argv[1] if len(sys.argv) > 1 else 'ko'], 'rb').read()
def r8(a): return rom[a - 0x200000]
def r16(a): return rom[a - 0x200000] | rom[a - 0x1FFFFF] << 8
def r24(a): return r16(a) | r8(a + 2) << 16
def r32(a): return r16(a) | r16(a + 2) << 16
for a in (0x250000, 0x250004, 0x250008, 0x25000C, 0x250024, 0x250038):
    print('ptr @%06X = %08X' % (a, r32(a)))
M8 = r32(0x250008) & 0xFFFFFF
print('master @%06X:' % M8, ' '.join('%06X' % (r32(M8 + 3 * i) & 0xFFFFFF) for i in range(4)), '(3-byte?)')
print('  as 24-bit at +0,+3,+6:', ['%06X' % r24(M8 + k) for k in (0, 3, 6, 9)])
ST = r24(M8 + 0)
PS_OFF = r24(M8 + 3); PS_BASE = r24(M8 + 6)
PALTAB = r32(0x250038) & 0xFFFFFF
print('stage tab %06X  palset-offsets %06X  palset-base %06X  global pal table %06X' % (ST, PS_OFF, PS_BASE, PALTAB))
for s in range(16):
    e = ST + 16 * s
    raw = rom[e - 0x200000:e - 0x200000 + 16]
    cnt = r16(e); tp = r24(e + 2); ps = r8(e + 5); bm = r16(e + 6); mt = r16(e + 8)
    print('st %2d @%06X raw %s | tiles %06X len %5d (%3d tiles) palset %2d blockmap %06X metatiles %06X' % (s, e, raw.hex(), tp, cnt, cnt // 16, ps, tp + bm, tp + mt))
