"""same deterministic hub flow as p3; enable debug write/ROM-read log between frames F0..F1; also dump palettes each frame of window"""
import os, sys, ctypes as C
import lh, ph
from ph import hub
import hosttest as T
import q_common as Q
lg = ph.lg
W = os.environ['LEAGUE_WORK']
s = int(sys.argv[1]); F0 = int(sys.argv[2]); F1 = int(sys.argv[3]); romlog = len(sys.argv) > 4 and sys.argv[4] == '1'
extra = [tuple(int(x, 16) for x in r.split('-')) for r in os.environ.get('XR', '').split(',') if r]
h = lh.mk(os.environ['ROM_KO'], 'p3b_%d' % s, fast=True); p = h.p; L = p.lib
L.retro_dbg_open.argtypes = [C.c_char_p]; L.retro_dbg_range.argtypes = [C.c_uint32, C.c_uint32]
on = C.c_int.in_dll(L, 'retro_dbg_on'); fr = C.c_uint32.in_dll(L, 'retro_dbg_frame'); rl = C.c_int.in_dll(L, 'retro_dbg_romlog')
log = W + '/p3b_st%d.log' % s
pl = open(W + '/p3b_st%d_pal.txt' % s, 'w')
def hook(hh):
    fr.value = hh.frames + 1
    if hh.frames + 1 == F0:
        L.retro_dbg_clear()
        for lo, hi in [(0x8300, 0x837F), (0x83E0, 0x83FF), (0x9800, 0x9FFF), (0xA000 + 0x107 * 16, 0xBFFF)] + extra: L.retro_dbg_range(lo, hi)
        L.retro_dbg_open(log.encode()); rl.value = 1 if romlog else 0; on.value = 1
    if hh.frames + 1 == F1:
        on.value = 0; L.retro_dbg_flush(); L.retro_dbg_open(None)
    if F0 <= hh.frames <= F1 + 200:
        pb = C.string_at(hh.pal, 512)
        pl.write('%d M%d S%d F%d %s | bg %s\n' % (hh.frames, p.peek(0x40A7), p.peek(0x41C0), p.peek(0x411A),
                 ' '.join('%04X' % (pb[0x100 + 2*i] | pb[0x101 + 2*i] << 8) for i in range(0, 64, 4)), '%04X' % (pb[0x1EC] | pb[0x1ED] << 8)))
h.pre_hook = hook
lg.league_hub(1, Q.NONE, Q.ONE); lg.league_hub_ranked(1)
ph.to_title(h); h.press('A', 4, 30)
assert lg.league_hub_match(4, 0, 1, s, -1, -1, -1, -1, -1, 1) == 1
f = 0
while f < 600 and not (p.peek(0x40A7) == 240 and p.peek(0x41C0) == 2 and hub()[7] == 0): h.run(1); f += 1
h.run(30); h.press('A', 4, 200); h.press('A', 4, 200); h.run(240)
Q.to_round1(h)
print('frames', h.frames, T.status()[:5])
