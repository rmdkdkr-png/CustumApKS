"""fight-time VRAM write census per stage (debug core, clean): random P1 input, 2 rounds won, then post-match screens.
log: frame PC type addr val ; plus phase file (frame MODE SCR FIGHT 5818 624D)"""
import sys, random
from dp import *
s = int(sys.argv[1]); seed = int(sys.argv[2]) if len(sys.argv) > 2 else 1
random.seed(seed)
p = P('ko', wd=W + '/wd_p7')
p.load(W + '/r1_st%d_ROM_KO.st' % s); p.frame = 0
p.watch(W + '/p7_st%d.log' % s, [(0x8200, 0x83FF), (0x9800, 0x9FFF), (0xA000 + 0x106 * 16, 0xBFFF), (0x8000, 0x8035), (0x8118, 0x8118)])
ph = open(W + '/p7_st%d_phase.txt' % s, 'w')
prev = None; kills = 0; live_since = None
BTN = ['L', 'R', 'U', 'D', 'A', 'B', 'DA', 'DB', 'LA', 'RA', 'DRA', 'DLA']
for f in range(4200):
    live = p.peek(0x40A7) == 241 and p.peek(0x411A) == 1 and p.peek(0x5824) == 0
    if live:
        if live_since is None: live_since = f
        if f - live_since > 700 and kills < 2: p.poke(0x5C46, 0); kills += 1; live_since = None
    else: live_since = None
    if live and f % 6 == 0:
        p.release(); p.hold(*random.choice(BTN))
    if not live: p.release()
    p.run(1)
    v = (p.peek(0x40A7), p.peek(0x41C0), p.peek(0x411A), p.peek(0x5818), p.peek16(0x624D), p.peek(0x5824))
    if v != prev: ph.write('%d %d %d %d %d %04X %02X\n' % ((p.frame,) + v)); prev = v
    if f % 300 == 0: p.shot(W + '/p7_st%d_f%04d.png' % (s, f), scale=1)
p.unwatch()
