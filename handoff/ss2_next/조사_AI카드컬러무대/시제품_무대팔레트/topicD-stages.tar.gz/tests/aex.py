"""compare variant run vs control run frame by frame"""
import sys, os, collections
import rs, tint
W = os.environ['LEAGUE_WORK']
def load(tag):
    out = []
    for l in open(os.path.join(W, tag, 'frames.txt')):
        t = l.split()
        out.append(dict(n=int(t[0]), md=int(t[1]), sc=int(t[2]), fi=int(t[3]), e=int(t[4], 16) // 16, rnd=int(t[5]), s2=bytes.fromhex(t[6]), bg=bytes.fromhex(t[7]),
                        sh=t[8], win=t[9], fl=int(t[10]), hp=(int(t[11]), int(t[12]))))
    return out
def phase(r):
    if r['md'] == 241 and r['fi'] == 1: return 'fight'
    if r['md'] == 241 and r['fi'] == 3: return 'roundend/KO'
    if r['md'] == 241: return 'intro/241f%d' % r['fi']
    return 'm240s%d' % r['sc']
def rom_s2(e, fn=None):
    st = rs.stage(e); b = bytearray(128)
    for k, pal in enumerate(st['pals']):
        for j, c in enumerate(pal):
            if fn and j: c = fn(c)
            b[k * 8 + j * 2] = c & 0xFF; b[k * 8 + j * 2 + 1] = c >> 8
    return bytes(b[:8 * len(st['pals'])]), st
def main(ctl, var, fnname=None):
    A, B = load(ctl), load(var)
    fn = tint.FN.get(fnname) if fnname else None
    n = min(len(A), len(B))
    c = collections.Counter(); bad = []
    for i in range(n):
        a, b = A[i], B[i]; ph = phase(a)
        if a['hp'] != b['hp'] or (a['md'], a['sc'], a['fi']) != (b['md'], b['sc'], b['fi']): c['desync'] += 1
        if a['sh'] != b['sh']: c[('spr+hud pal differ', ph)] += 1
        if a['win'] != b['win']: c[('window col differ', ph)] += 1
        ra, st = rom_s2(a['e'])
        shown = a['s2'][:len(ra)] == ra
        if shown:
            c[('ctl stage shown', ph)] += 1
            if fn:
                rb, _ = rom_s2(b['e'], fn)
                ok = b['s2'][:len(rb)] == rb
                bgok = (b['bg'][0] | b['bg'][1] << 8) & 0xFFF == fn(st['bg'])
                c[('variant == tinted ROM', ph, ok and bgok)] += 1
                if not (ok and bgok) and len(bad) < 5: bad.append((a['n'], ph))
        else:
            if a['s2'] != b['s2']: c[('NOT-shown frame, plane2 differs', ph)] += 1
            else: c[('NOT-shown frame, plane2 same', ph)] += 1
        if a['fl']: c[('flash frame', ph, 'plane2 tinted' if b['s2'] != a['s2'] else 'plane2 same')] += 1
    print('== %s vs %s (%s): frames %d/%d' % (var, ctl, fnname, len(A), len(B)))
    for k in sorted(c, key=str): print('   ', k, c[k])
    if bad: print('    first mismatches', bad)
    # rounds/entries
    ents = collections.OrderedDict()
    for r in B:
        if r['md'] == 241 and r['fi'] == 1: ents.setdefault(r['rnd'], set()).add(r['e'])
    print('    fight entries by round (variant):', {k: sorted(v) for k, v in ents.items()})
if __name__ == '__main__':
    main(sys.argv[1], sys.argv[2], sys.argv[3] if len(sys.argv) > 3 else None)
