"""topicD exp — stage variants through the whole ranked-hub match: intro, 3 rounds (random input + forced MAX), KO, quote latch.
usage: ex.py <case> <stage> [fast|app] [seed]
 case: ctl | night | daylock | pv_<fn> (ROM overlay palettes) | lut_<fn> (plane-2 write LUT armed all session)"""
import os, sys, json, random, zlib, ctypes as C
import oc, lh, ph, tint
lg = oc.lg
CASE, ST = sys.argv[1], int(sys.argv[2]); MODE = sys.argv[3] if len(sys.argv) > 3 else 'fast'; SEED = int(sys.argv[4]) if len(sys.argv) > 4 else 7
tag = 'ex_%s_s%d_%s_jue' % (CASE, ST, MODE)
h = oc.mk(tag, fast=(MODE != 'app')); p = h.p; L = p.lib
L.retro_ngp_rom_overlay.argtypes = [C.c_uint32, C.c_char_p, C.c_uint32]
L.retro_dbg_gfxp.restype = C.c_void_p; GFX = L.retro_dbg_gfxp()
def ov(addr, b): L.retro_ngp_rom_overlay(addr, b, len(b))
desc = ''
if CASE == 'night' or CASE == 'daylock':
    raw = bytearray(p.peek(0x4000, 1) and b'')  # placeholder
    rom = open(os.environ['ROM_KO'], 'rb').read(); o = 0x239056 - 0x200000 + 8 * ST
    e = bytearray(rom[o:o + 8])
    if CASE == 'night': e[0:4] = e[4:8]
    else: e[4:8] = e[0:4]
    ov(0x239056 + 8 * ST, bytes(e)); desc = 'bout %d table -> %s' % (ST, e.hex())
elif CASE.startswith('pv_'):
    fn = tint.FN[CASE[3:]]
    for a, b in tint.overlay_for_entries(tint.BOUT_ENTRIES[ST], fn): ov(a, b)
    desc = 'ROM overlay %s on entries %s' % (CASE[3:], tint.BOUT_ENTRIES[ST])
elif CASE == 'newstage':
    import json as _j
    for a, hx in _j.load(open(os.path.join(os.environ['LEAGUE_WORK'], 'pack_overlay.json'))): ov(a, bytes.fromhex(hx))
    desc = 'new stage from pack via entry 8'
    hp = os.path.join(os.environ['LEAGUE_WORK'], 'hirom_pack.bin')
    if os.environ.get('USE_EXT') == '1':
        L.retro_ngp_hirom_ext.argtypes = [C.c_char_p, C.c_uint32]; d = open(hp, 'rb').read(); L.retro_ngp_hirom_ext(d, len(d)); desc += ' (core ext buffer at 0x800000, ROM stays 2MB)'
elif CASE.startswith('lut_'):
    arr = (C.c_uint16 * 4096)(*tint.lut(tint.FN[CASE[4:]])); L.retro_ngp_bgtint(arr); desc = 'plane-2 LUT %s armed whole session' % CASE[4:]
print('CASE', tag, desc, flush=True)
D = os.path.join(os.environ['LEAGUE_WORK'], tag); os.makedirs(D, exist_ok=True)
fl = open(os.path.join(D, 'frames.txt'), 'w')
random.seed(SEED)
BTN = ['L', 'R', 'U', 'D', 'A', 'B', 'DA', 'DB', 'LA', 'RA', 'DRA', 'DLA', 'AB']
state = dict(n=0, prev=None, shots=0, last=-999, flash=0, live=0)
def rec(hh):
    n = state['n'] = state['n'] + 1
    pb = C.string_at(hh.pal, 512); rg = C.string_at(GFX, 14)
    md, sc, fi = p.peek(0x40A7), p.peek(0x41C0), p.peek(0x411A)
    flash = rg[1] == 0 or rg[3] == 0   # window folded (game flash)
    if flash: state['flash'] += 1
    s2 = pb[0x100:0x180].hex(); bg = pb[0x1EC:0x1EE].hex()
    spr_hud = zlib.crc32(pb[0:0x100]); win = pb[0x1F0:0x200].hex()
    fl.write('%d %d %d %d %04X %d %s %s %08X %s %d %d %d\n' % (n, md, sc, fi, p.peek16(0x624D), p.peek(0x5818), s2, bg, spr_hud, win, flash, p.peek(0x5A46), p.peek(0x5C46)))
    v = (md, sc, fi, p.peek16(0x624D), p.peek(0x5818))
    if state['shots'] < 80 and (v != state['prev'] or n - state['last'] >= 240 or (flash and state['flash'] < 3)):
        p.shot(os.path.join(D, 'f%05d_m%d_s%d_f%d_r%d%s.png' % (n, md, sc, fi, v[4], '_FLASH' if flash else '')), scale=1); state['shots'] += 1; state['last'] = n
    state['prev'] = v
h.pre_hook = rec
# random input + forced MAX during live fight (user input path)
orig_run = h.run
def run_with_input(k=1):
    for _ in range(k):
        live = p.peek(0x40A7) == 241 and p.peek(0x411A) == 1 and p.peek(0x5824) == 0
        if live:
            state['live'] += 1
            if state['live'] % 6 == 0: h.user = ph.bits(random.choice(BTN))
            if state['live'] % 300 == 100 and p.peek(0x5A47) < 0x2F: p.poke(0x5A47, 0x2F)   # next hit -> true MAX (game's own increment)
        orig_run(1)
oc.go_select(h, 4, 0, stage=ST)
oc.pick_me(h)
oc.to_round1(h)
h.run = run_with_input
s = oc.to_done(h, [1, 2, 1])
h.user = 0; h.run = orig_run
hq = oc.to_quote(h)
p.shot(os.path.join(D, 'zz_quote_hold.png'), scale=1)
fl.close()
print('done', s[:6], 'quote_hold', hq, 'frames', state['n'], 'flash frames', state['flash'], flush=True)
json.dump(dict(case=CASE, stage=ST, mode=MODE, desc=desc, frames=state['n'], flash=state['flash'], quote=hq), open(os.path.join(D, 'res.json'), 'w'))
