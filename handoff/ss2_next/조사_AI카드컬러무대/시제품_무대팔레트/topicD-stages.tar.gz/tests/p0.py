"""topicD: get to round 1 on each stage via league hub (q_common.prep), save states."""
import os, sys, time
import q_common as Q
W = os.environ['LEAGUE_WORK']
stages = [int(x) for x in sys.argv[1].split(',')] if len(sys.argv) > 1 else list(range(8))
opp = int(os.environ.get('OPP', '4'))
for s in stages:
    t = time.time()
    path = os.path.join(W, 'r1_st%d_%s.st' % (s, os.environ.get('QROM', 'ROM_KO')))
    h = Q.prep(path, opp=opp, sty=0, stage=s)
    p = h.p
    print('stage', s, 'BOUT', p.peek(0x5827), 'MODE', p.peek(0x40A7), 'FIGHT', p.peek(0x411A), 'secs %.1f' % (time.time() - t), flush=True)
    p.shot(os.path.join(W, 'r1_st%d.png' % s), scale=1)
