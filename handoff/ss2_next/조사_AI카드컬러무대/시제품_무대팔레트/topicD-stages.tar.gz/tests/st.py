"""overlay vs save states: set overlay mid-match, save/load with and without overlay (plain debug core, no hub)"""
import os, ctypes as C
from dp import *
import rs, tint, aex
os.environ.setdefault('U159_FIXTIME', '1790000000')
def mk():
    p = P('ko', wd=W + '/wd_st'); L = p.lib
    L.retro_ngp_rom_overlay.argtypes = [C.c_uint32, C.c_char_p, C.c_uint32]
    return p
def set_ov(p, e_list, fn):
    for a, b in tint.overlay_for_entries(e_list, fn): p.lib.retro_ngp_rom_overlay(a, b, len(b))
def clr(p): p.lib.retro_ngp_rom_overlay(0, None, 0)
def status(p, fn):
    e = p.peek16(0x624D) // 16; ra, st = aex.rom_s2(e); rb, _ = aex.rom_s2(e, fn)
    s2 = p.palb()[0x100:0x180]
    return 'orig' if s2[:len(ra)] == ra else 'TINT' if s2[:len(rb)] == rb else 'other'
def to_next_round(p, kill=True, lim=3000):
    r0 = p.peek(0x5818)
    if kill: p.poke(0x5C46, 0)
    for f in range(lim):
        p.run(1)
        if p.peek(0x5818) != r0 and p.peek(0x40A7) == 241 and p.peek(0x411A) == 1: break
    p.run(20)
fn = tint.night
p = mk(); p.load(W + '/r1_st4_ROM_KO.st'); p.run(10)
print('A. loaded r1 (no overlay):', status(p, fn))
set_ov(p, [4], fn); p.run(30)
print('B. overlay set mid-round 1 (no reload yet):', status(p, fn))
to_next_round(p)
print('C. round 2 after stage reload:', status(p, fn), 'round', p.peek(0x5818))
p.run(100); p.save(W + '/st_r2_tinted.st')
clr(p); p.run(30)
print('D. overlay cleared mid-round 2:', status(p, fn))
to_next_round(p, kill=False) if False else None
p2 = mk(); clr(p2); p2.load(W + '/st_r2_tinted.st'); p2.run(10)
print('E. fresh core, NO overlay, load tinted state:', status(p2, fn))
p2.poke(0x5A46, 0); 
for f in range(3000):
    p2.run(1)
    if p2.peek(0x5818) == 2 and p2.peek(0x40A7) == 241 and p2.peek(0x411A) == 1: break
p2.run(20)
print('F.   ... after next round reload:', status(p2, fn), 'round', p2.peek(0x5818))
p3 = mk(); clr(p3); set_ov(p3, [4], fn); p3.load(W + '/st_r2_tinted.st'); p3.run(10)
print('G. fresh core, overlay set BEFORE load:', status(p3, fn))
p3.poke(0x5A46, 0)
for f in range(3000):
    p3.run(1)
    if p3.peek(0x5818) == 2 and p3.peek(0x40A7) == 241 and p3.peek(0x411A) == 1: break
p3.run(20)
print('H.   ... after next round reload:', status(p3, fn), 'round', p3.peek(0x5818))
p4 = mk(); clr(p4); p4.load(W + '/st_r2_tinted.st'); set_ov(p4, [4], fn); p4.load(W + '/st_r2_tinted.st'); p4.run(10)
p4.poke(0x5A46, 0)
for f in range(3000):
    p4.run(1)
    if p4.peek(0x5818) == 2 and p4.peek(0x40A7) == 241 and p4.peek(0x411A) == 1: break
p4.run(20)
print('I. overlay set after a load, then state re-loaded (rom_hack re-applies):', status(p4, fn))
clr(p4); p4.load(W + '/st_r2_tinted.st'); p4.poke(0x5A46, 0)
for f in range(3000):
    p4.run(1)
    if p4.peek(0x5818) == 2 and p4.peek(0x40A7) == 241 and p4.peek(0x411A) == 1: break
p4.run(20)
print('J. overlay cleared, state loaded, next reload:', status(p4, fn))
rom = open(ROMS['ko'], 'rb').read()
print('K. ROM bytes restored after clear:', bytes(C.string_at(0, 0) or b'') == b'', 'n/a (checked via J)')
