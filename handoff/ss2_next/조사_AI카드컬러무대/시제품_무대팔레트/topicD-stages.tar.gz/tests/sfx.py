"""hunt the special-background effect (0x5B53/0x5D53 flags -> stage reload 0x201492): long random fight, both at MAX often"""
import sys, random
from dp import *
import aex
s = int(sys.argv[1]); N = int(sys.argv[2]); seed = int(sys.argv[3])
random.seed(seed)
p = P('ko', wd=W + '/wd_sfx%d' % s)
p.load(W + '/r1_st%d_ROM_KO.st' % s); p.frame = 0
BTN = ['L', 'R', 'U', 'D', 'A', 'B', 'DA', 'DB', 'LA', 'RA', 'DRA', 'DLA', 'AB', 'DR', 'DL', 'UR']
seq = []
prev = None; shots = 0; notshown = 0
for f in range(N):
    if p.peek(0x40A7) == 241 and p.peek(0x411A) == 1:
        if f % 4 == 0: p.release(); p.hold(*random.choice(BTN))
        if f % 200 == 0:
            for a in (0x5A47, 0x5C47):
                if p.peek(a) < 0x2F: p.poke(a, 0x2F)
        p.poke(0x5A46, max(p.peek(0x5A46), 60)); p.poke(0x5C46, max(p.peek(0x5C46), 60)); p.poke(0x582F, 0x80); p.poke(0x5830, 0x07)
    else:
        p.release()
        if f % 30 == 0: p.press('A', 2)
    p.run(1)
    v = (p.peek(0x5B53), p.peek(0x5D53))
    ra, st = aex.rom_s2(p.peek16(0x624D) // 16)
    shown = p.palb()[0x100:0x100 + len(ra)] == ra
    if not shown and p.peek(0x40A7) == 241 and p.peek(0x411A) == 1: notshown += 1
    if v != prev or (not shown and shots < 40 and f % 10 == 0 and p.peek(0x411A) == 1):
        print(f, 'flags5B53/5D53', v, 'stage pal shown', shown, 'MAX', p.peek(0x59CA) & 4, p.peek(0x5BCA) & 4, 'act', hex(p.peek16(0x4E3E)), hex(p.peek16(0x4E7E)), flush=True)
        if shots < 40: p.shot(W + '/sfx_s%d_f%05d.png' % (s, f), scale=1); shots += 1
        prev = v
print('fight frames with stage palette NOT shown:', notshown)
