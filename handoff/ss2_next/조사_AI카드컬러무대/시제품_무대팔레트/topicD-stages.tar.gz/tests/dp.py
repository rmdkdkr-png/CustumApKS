"""topicD common: debug-core probe with VRAM/regs access + renderers (scratch only)."""
import os, sys, ctypes as C
sys.path.insert(0, '/home/user/CustumApKS/handoff/ss2_league')
import ss2probe
S = '/tmp/claude-0/-home-user-CustumApKS/e6c46352-6bb9-5a9d-8b3a-f2da7447674e/scratchpad'
M = S + '/u159/topicD-stages'
W = M + '/work'
DBGCORE = os.environ.get('DBGCORE', M + '/core_dbg/mednafen_ngp_libretro.so')
ROMS = {'ko': S + '/prac1/mute/roms/ss2_ko_bundled_mute.ngc', 'jue': S + '/prac1/mute/roms/ss2_mute.ngc'}
class P(ss2probe.Probe):
    def __init__(self, rom='ko', wd=None, core=DBGCORE):
        super().__init__(core, ROMS.get(rom, rom), wd or (W + '/wd_' + str(rom).split('/')[-1]))
        L = self.lib
        for f in ('retro_ngp_charram', 'retro_ngp_scrollram', 'retro_ngp_palram', 'retro_ngp_spriteram', 'retro_ngp_spritecol'):
            getattr(L, f).restype = C.c_void_p
        self.chr = L.retro_ngp_charram(); self.scr = L.retro_ngp_scrollram(); self.pal = L.retro_ngp_palram()
        self.spr = L.retro_ngp_spriteram(); self.col = L.retro_ngp_spritecol()
        self.dbg = hasattr(L, 'retro_dbg_open')
        if hasattr(L, 'retro_dbg_gfxp'):
            L.retro_dbg_gfxp.restype = C.c_void_p; self.gfx = L.retro_dbg_gfxp()
        else: self.gfx = None
        if self.dbg:
            L.retro_dbg_open.argtypes = [C.c_char_p]; L.retro_dbg_range.argtypes = [C.c_uint32, C.c_uint32]
            self.on = C.c_int.in_dll(L, 'retro_dbg_on'); self.fr = C.c_uint32.in_dll(L, 'retro_dbg_frame')
            self.romlog = C.c_int.in_dll(L, 'retro_dbg_romlog')
            self.pclo = C.c_uint32.in_dll(L, 'retro_dbg_pclo'); self.pchi = C.c_uint32.in_dll(L, 'retro_dbg_pchi')
    def run(self, n=1):
        for _ in range(n):
            self.lib.retro_run(); self.frame += 1
            if self.dbg: self.fr.value = self.frame
    def watch(self, path, ranges, romlog=False):
        L = self.lib; L.retro_dbg_clear()
        for lo, hi in ranges: L.retro_dbg_range(lo, hi)
        L.retro_dbg_open(path.encode()); self.romlog.value = 1 if romlog else 0; self.on.value = 1
    def unwatch(self):
        self.on.value = 0; self.lib.retro_dbg_flush(); self.lib.retro_dbg_open(None)
    # raw views
    def palb(self): return C.string_at(self.pal, 512)
    def scrb(self): return C.string_at(self.scr, 4096)
    def chrb(self): return C.string_at(self.chr, 8192)
    def sprb(self): return C.string_at(self.spr, 256)
    def colb(self): return C.string_at(self.col, 64)
    def regs(self):
        if not self.gfx: return {}
        b = C.string_at(self.gfx, 14)
        k = 'winx winw winy winh s1x s1y s2x s2y sprx spry swap bgc oowc neg'.split()
        return dict(zip(k, b))
def col12(pb, idx): return (pb[idx * 2] | (pb[idx * 2 + 1] << 8)) & 0xFFF
def rgb(c): return ((c & 15) * 17, ((c >> 4) & 15) * 17, ((c >> 8) & 15) * 17)
def tile_px(chrb, t, x, y):
    v = chrb[t * 16 + y * 2] | (chrb[t * 16 + y * 2 + 1] << 8)
    return (v >> ((7 - x) * 2)) & 3
def render_plane(chrb, scrb, palb, plane, bgcol=None, show_pal=None):
    """full 256x256 map render of plane (0 = scroll1 @0x9000, 1 = scroll2 @0x9800)"""
    from PIL import Image
    im = Image.new('RGB', (256, 256), rgb(bgcol) if bgcol is not None else (255, 0, 255)); px = im.load()
    pbase = 0x40 if plane == 0 else 0x80
    for r in range(32):
        for c in range(32):
            o = plane * 0x800 + (r * 32 + c) * 2; e = scrb[o] | (scrb[o + 1] << 8)
            t = e & 0x1FF; pl = (e >> 9) & 15; hf = e & 0x8000; vf = e & 0x4000
            if show_pal is not None and pl not in show_pal: continue
            for y in range(8):
                for x in range(8):
                    sx = 7 - x if hf else x; sy = 7 - y if vf else y
                    i = tile_px(chrb, t, sx, sy)
                    if i: px[c * 8 + x, r * 8 + y] = rgb(col12(palb, pbase + pl * 4 + i))
    return im
def plane_stats(scrb, plane):
    tiles = {}; pals = {}; ents = 0
    for i in range(1024):
        o = plane * 0x800 + i * 2; e = scrb[o] | (scrb[o + 1] << 8)
        t = e & 0x1FF; pl = (e >> 9) & 15
        tiles[t] = tiles.get(t, 0) + 1; pals[pl] = pals.get(pl, 0) + 1
    return tiles, pals
def sprites(sprb, colb):
    out = []; lx = ly = 0
    for s in range(64):
        e = sprb[s * 4] | (sprb[s * 4 + 1] << 8); sx = sprb[s * 4 + 2]; sy = sprb[s * 4 + 3]
        x = (lx + sx) if e & 0x400 else sx; y = (ly + sy) if e & 0x200 else sy
        lx, ly = x, y
        pr = (e >> 11) & 3
        if pr: out.append(dict(i=s, t=e & 0x1FF, pal=colb[s] & 15, pr=pr, x=x & 0xFF, y=y & 0xFF))
    return out
def hx3(pb, p, base):
    return '/'.join('%03X' % col12(pb, base + p * 4 + j) for j in range(4))
