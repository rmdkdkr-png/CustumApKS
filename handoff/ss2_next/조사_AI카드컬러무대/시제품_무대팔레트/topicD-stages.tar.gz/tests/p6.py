"""round 2 stage per bout: win round 1 then capture round-2 screen + 624D/5828"""
from dp import *
from PIL import Image
ims = []
for s in range(8):
    p = P('ko', wd=W + '/wd_p6')
    p.load(W + '/r1_st%d_ROM_KO.st' % s); p.frame = 0
    r1 = (p.peek16(0x624D), p.peek(0x5828))
    p.run(60); p.poke(0x5C46, 0)
    f = 0
    while f < 3000:
        p.run(1); f += 1
        if p.peek(0x5818) == 1 and p.peek(0x40A7) == 241 and p.peek(0x411A) == 1: break
    p.run(30)
    p.shot(W + '/p6_r2_st%d.png' % s, scale=1)
    print('stage %d: round1 624D=%04X 5828=%d | round2 624D=%04X 5828=%d 5818=%d f=%d' % (s, r1[0], r1[1], p.peek16(0x624D), p.peek(0x5828), p.peek(0x5818), f))
    ims.append(Image.open(W + '/p6_r2_st%d.png' % s))
out = Image.new('RGB', (4 * 160, 2 * 152))
for i, im in enumerate(ims): out.paste(im, ((i % 4) * 160, (i // 4) * 152))
out.resize((1280, 608), Image.NEAREST).save(W + '/sheet_r2.png')
