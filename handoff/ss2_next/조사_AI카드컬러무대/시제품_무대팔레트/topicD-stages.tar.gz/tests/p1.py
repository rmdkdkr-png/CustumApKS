import os, sys, json
from dp import *
os.makedirs(W + '/p1', exist_ok=True)
res = {}
for s in range(8):
    p = P('ko', wd=W + '/wd_p1')
    p.load(W + '/r1_st%d_ROM_KO.st' % s); p.run(2)
    pb, sb, cb = p.palb(), p.scrb(), p.chrb()
    open(W + '/p1/st%d.vram' % s, 'wb').write(pb + sb + cb + p.sprb() + p.colb())
    rg = p.regs()
    bgc = rg.get('bgc', 0)
    bgv = col12(pb, 0xF0 + (bgc & 7))
    t2, p2 = plane_stats(sb, 1); t1, p1 = plane_stats(sb, 0)
    spr = sprites(p.sprb(), p.colb())
    sp_pals = {}
    for q in spr: sp_pals[q['pal']] = sp_pals.get(q['pal'], 0) + 1
    print('stage %d regs %s bgcol[%d]=%03X' % (s, rg, bgc & 7, bgv))
    print('  plane2 pals', dict(sorted(p2.items())), 'tiles %d uniq range %03X-%03X' % (len(t2), min(t2), max(t2)))
    print('  plane1 pals', dict(sorted(p1.items())), 'tiles %d uniq' % len(t1))
    print('  sprites %d pals %s' % (len(spr), dict(sorted(sp_pals.items()))))
    for k in sorted(p2): print('    S2 pal %2d %s' % (k, hx3(pb, k, 0x80)))
    render_plane(cb, sb, pb, 1, bgv).save(W + '/p1/st%d_plane2.png' % s)
    render_plane(cb, sb, pb, 0).save(W + '/p1/st%d_plane1.png' % s)
    res[s] = dict(regs=rg, bg=bgv, p2pals=sorted(p2), t2=sorted(t2), sp=spr)
json.dump(res, open(W + '/p1/res.json', 'w'))
