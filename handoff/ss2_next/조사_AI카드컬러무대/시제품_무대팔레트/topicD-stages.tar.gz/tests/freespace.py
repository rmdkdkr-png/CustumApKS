import sys
def runs(d, val, minlen=1024):
    out=[]; i=0; n=len(d)
    while i<n:
        if d[i]==val:
            j=i
            while j<n and d[j]==val: j+=1
            if j-i>=minlen: out.append((i,j-i))
            i=j
        else: i+=1
    return out
for path in sys.argv[1:]:
    d=open(path,'rb').read()
    print(path.split('/')[-1], 'size', hex(len(d)), 'hdr', d[0:28], 'cat', d[0x20:0x22].hex(), 'name', d[0x24:0x30])
    for v in (0xFF,0x00):
        r=runs(d,v)
        tot=sum(l for _,l in r)
        print('  byte %02X runs>=1KB: %d total %d (0x%X)'%(v,len(r),tot,tot))
        for o,l in r: print('    cart 0x%06X len 0x%X (%d KB)'%(0x200000+o,l,l//1024))
