"""search ROM for stage tiles / map rows / palettes (exact)"""
import os, sys, json
from dp import *
rom = open(ROMS[sys.argv[1] if len(sys.argv) > 1 else 'ko'], 'rb').read()
def find_all(b, sub, lim=8):
    out = []; i = b.find(sub)
    while i >= 0 and len(out) < lim: out.append(i + 0x200000); i = b.find(sub, i + 1)
    return out
for s in range(8):
    v = open(W + '/p1/st%d.vram' % s, 'rb').read()
    pb, sb, cb = v[:512], v[512:512 + 4096], v[4608:4608 + 8192]
    t2, p2 = plane_stats(sb, 1)
    tiles = sorted(t for t in t2 if any(cb[t * 16:(t + 1) * 16]))
    hit = 0; locs = []
    for t in tiles:
        f = find_all(rom, cb[t * 16:(t + 1) * 16], 2)
        if f: hit += 1; locs.append(f[0])
    lo = min(tiles); hi = max(tiles)
    # contiguous tile block
    blk = cb[0x100 * 16:0x200 * 16]
    fb = find_all(rom, cb[tiles[len(tiles)//2] * 16: tiles[len(tiles)//2] * 16 + 64], 2)
    # map rows
    mrow = 0; mloc = []
    for r in range(32):
        row = sb[0x800 + r * 64: 0x800 + r * 64 + 64]
        if len(set(row)) < 3: continue
        f = find_all(rom, row, 2)
        if f: mrow += 1; mloc.append((r, hex(f[0])))
        # also tile-index-only (low 9 bits) as u8? skip
    # palettes: whole plane2 block 16 pals
    pal_full = find_all(rom, pb[0x100:0x180], 4)
    pal8 = {}
    for k in sorted(p2):
        f = find_all(rom, pb[0x100 + k * 8:0x100 + k * 8 + 8], 4)
        pal8[k] = [hex(x) for x in f]
    print('stage %d: tiles used %d (nonzero %d, %03X-%03X) exact-in-ROM %d; first locs %s' % (s, len(t2), len(tiles), lo, hi, hit, [hex(x) for x in locs[:4]]))
    print('   map rows found %d %s' % (mrow, mloc[:4]))
    print('   pal block(16) %s ; per-pal %s' % ([hex(x) for x in pal_full], pal8))
