package com.dudu.pocketcore;

import android.content.Context;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;

/**
 * 한글패치(IPS)를 롬에 입힌다.
 *
 * 유저의 롬은 **건드리지 않는다.** 패치본은 PocketCore/.patched/ 에 따로 만들고 그걸 실행한다.
 * 숨김 폴더라 롬 목록에도 안 뜬다 — 같은 게임이 두 번 보이면 무엇을 고르는지 헷갈린다.
 *
 * 다시 만드는 조건은 도장(.stamp)으로 판단한다. 롬 크기·수정시각과 패치 크기를 적어 두고
 * 하나라도 다르면 다시 만든다. 매번 다시 만들면 2~4MB 를 실행할 때마다 쓰게 된다.
 *
 * 이미 한패가 입혀진 롬을 유저가 넣었을 수도 있다. 그때는 사본을 만들 이유가 없다.
 * 판단은 **입혀 보고 결과가 원본과 같은지**로 한다. 처음에는 첫 기록만 들여다보는
 * 싼 방법을 썼는데, 그 구간의 바이트가 원래와 같기만 하면 원본도 「이미 패치됨」으로
 * 오판했다 — 실측에서 SS2·월화 원본 셋 다 걸렸다. 그러면 한패가 영영 안 입혀진다.
 * 어차피 입힐 참이라 한 번 더 도는 비용도 없다.
 */
public final class Patcher {

    public static final String DIR = ".patched";

    /** 패치본 경로를 돌려준다. 패치가 없거나 실패하면 원본 경로를 그대로 돌려준다.
     *  lang 이 ja·en 이면 번역 패치는 필요 없지만, SvC 문턱 패치(fastRom)는 언어와
     *  무관하게 얹을 수 있다.
     *
     *  fastRom: SvC 강공격 문턱 패치(assets/patch/svc_faststrong.ips, 0x000D4E 04→02).
     *  강 기본기가 버튼 8프레임 → 4프레임에 선다. 한글패치와 같은 방식으로 사본에만
     *  입히므로 유저 롬은 안 건드린다. 코어(v3.28+)는 롬의 문턱을 읽어 즉발 주입값을
     *  문턱−1 로 맞추므로 병용해도 안전하다(실측).
     *
     *  withMods: 조작 패치 채널(mods.json) 중 켜진 것들을 얹는다. 예 — 빠른 기본기(FastCD): 서서 강펀·강킥의 애니
     *  대본 WAIT 를 줄여 「누름→히트」 총 길이를 원래 모션 길이에 맞춘 것(원본−문턱,
     *  대본 물리 바닥까지만 — 차등 보존, 전 항목 실측 검증). 문턱·판정 알고리즘은 안
     *  건드리므로 약/강 구분은 순정 그대로. 한글패치와 겹치는 바이트 없음(실측).
     *  현재 svc(20기술)·kofr2(14명) 에 자산이 있고, 다른 게임은 자산이 없어 자동 무시된다. */
    /** 사무쇼2 배경음악 결과 — resolve 가 채운다(사무쇼2·SS1 음악 켬일 때만, 아니면 null). 게임 시작 토스트가 보여 준다. */
    public static volatile String musicNote;
    public static final String MUSIC_OK = "배경음악: 사무쇼1 곡";
    public static final String MUSIC_NO_ROM = "배경음악: 사무쇼1 롬을 못 찾아 원래 곡 — 롬 폴더에 넣거나 「롬 › 저장소에서 롬 스캔」";
    public static final String MUSIC_FAIL = "배경음악: 이 사무쇼1 롬에선 곡을 못 꺼내 원래 곡";
    public static final String MUSIC_MUTE = "배경음악: 끔(효과음만)";
    public static final String MUSIC_MUTE_FAIL = "배경음악: 이 롬에선 끄지 못해 원래 곡";

    /** 가상 리그 랭크전 전용 사본 — 원본 롬 + 번역 패치(내려받은 판, 없으면 동봉 판)만 입힌다.
     *  수동 패치·조작 패치(mods)·사무쇼1 배경음악은 얹지 않는다: 판정 주소를 실측한 고정 판(League.ROMS 의 md5)으로만
     *  정산하기 위해서다(기획서 4장 «버전 고정»). 사본은 루트/league/rom/<원래 이름> — 세이브 이름도 원래 이름에서 나온다.
     *  번역이 필요 없는 언어(ja·en)면 원본 그대로. 실패하면 원본 경로(그러면 md5 검사가 정산을 멈춘다). */
    public static String resolveLeague(Context ctx, String romPath, Games.Game game, String lang) {
        musicNote = null;                                     /* 랭크전은 배경음악을 안 바꾼다 — 자유 플레이 때 알림이 남지 않게 */
        String name = (game != null) ? game.patchFor(lang) : null;
        if (name == null) return romPath;
        try {
            File rom = new File(romPath);
            /* 이미 한글패치가 든 롬(실측한 사본)이면 그대로 — 한 번 더 입히면 판정 주소를 모르는 롬이 된다 */
            String lab = League.romLabel(League.md5(rom));
            if (lab != null && lab.contains("한글패치")) return romPath;
            byte[] ips = readFile(new File(new File(MainActivity.root(), "patch"), name));
            if (ips == null) ips = readAsset(ctx, "patch/" + name);
            byte[] data = readFile(rom);
            if (ips == null || data == null) return romPath;
            byte[] done = apply(data, ips);
            if (done == null) return romPath;
            File out = new File(League.romDir(), rom.getName());
            byte[] old = readFile(out);
            if (old == null || !java.util.Arrays.equals(old, done)) {
                /* 임시 파일 → 이름 바꾸기 — 리그 화면의 롬 확인과 게임 창이 같은 사본을 동시에 써도 반쯤 쓴 롬이 안 남는다 */
                File tmp = new File(out.getPath() + ".tmp" + android.os.Process.myTid());
                try {
                    try (FileOutputStream fo = new FileOutputStream(tmp)) { fo.write(done); fo.getFD().sync(); }
                    if (!tmp.renameTo(out)) return romPath;
                } finally { tmp.delete(); }                  /* 쓰다 실패해도 임시 파일을 남기지 않는다(이름 바꾼 뒤면 이미 없다) */
            }
            return out.getPath();
        } catch (Exception e) {
            return romPath;
        }
    }

    public static String resolve(Context ctx, String romPath, Games.Game game, String lang,
                                 boolean fastRom, boolean withMods) {
        String name = (game != null) ? game.patchFor(lang) : null;
        byte[] extra = (fastRom && game != null && "svc".equals(game.id))
                     ? readAsset(ctx, "patch/svc_faststrong.ips") : null;
        /* 조작 패치(mods): mods.json 에 있고 옵션 pocketcore_<id>=enabled 인 것만, 색인 순서대로 얹는다.
           파일은 내려받은 mods/<id>.ips 우선, 없으면 동봉 assets/patch/<id>.ips(svc/kofr2 FastCD 는 동봉). */
        java.util.List<byte[]> mods = new java.util.ArrayList<>();
        StringBuilder modSig = new StringBuilder();
        StringBuilder saveTag = new StringBuilder();          /* 세이브 구역을 바꾸는 패치의 표식 모음 */
        if (withMods && game != null) {
            java.util.Map<String, String> opts = Settings.load();
            for (Settings.Mod md : Settings.mods()) {
                if (!game.id.equals(md.game)) continue;
                boolean on;
                if (md.grouped()) {
                    /* 배타 묶음 — 옵션 하나(pocketcore_<group>)가 어느 패치를 고를지 담는다.
                       같은 바이트를 덮는 것들이라 하나만 얹혀야 한다(전엔 둘 다 켜면 나중 것이 이겼다). */
                    String k = "pocketcore_" + md.group;
                    String v = opts.containsKey(k) ? opts.get(k)
                             : ("enabled".equals(md.def) ? md.id : "disabled");
                    on = md.id.equals(v);
                } else {
                    String v = opts.containsKey("pocketcore_" + md.id) ? opts.get("pocketcore_" + md.id) : md.def;
                    on = "enabled".equals(v);
                }
                if (!on) continue;
                byte[] b = readFile(new File(Settings.modsDir(), md.id + ".ips"));
                if (b == null) b = readAsset(ctx, "patch/" + md.id + ".ips");
                if (b == null) continue;
                mods.add(b);
                modSig.append(md.id).append('=').append(md.ver).append(':').append(b.length).append(';');
                /* 색인의 글자가 파일 이름이 되는 자리다 — 반드시 걸러 쓴다. */
                if (md.saveTag != null && md.saveTag.matches("[a-z0-9]+"))
                    saveTag.append('.').append(md.saveTag);
            }
        }
        /* 사무쇼2 배경음악 — 폰에 있는 사무쇼1 롬에서 곡을 꺼내 사본에 심는다(Ss1Music). 옵션 pocketcore_ss2_music:
           ss1 = SS1 음악(기본) · same = 같은 곡만 SS1 판 · off = 원래 · mute = 끔(효과음만, SS1 롬 필요 없음).
           SS1 롬이 없으면 원래 음악. */
        byte[] ss1rom = null;
        boolean musicAll = true, musicMute = false;
        String musicSig = "";
        musicNote = null;
        if (game != null && "ss2".equals(game.id)) {
            String mv = Settings.load().get("pocketcore_ss2_music");
            if (mv == null) mv = "ss1";
            if ("mute".equals(mv)) {                          /* 유저 2026-10-10 「BGM 끄는 옵션 추가하고」 */
                musicMute = true;
                musicSig = "mute,v" + Ss1Music.VER;
                musicNote = MUSIC_MUTE;
            } else if (!"off".equals(mv)) {
                File f1 = Ss1Music.findSs1Rom();
                if (f1 != null) {
                    ss1rom = readFile(f1);
                    musicAll = !"same".equals(mv);
                    if (ss1rom != null) musicSig = mv + "," + f1.length() + "," + f1.lastModified() + ",v" + Ss1Music.VER
                            + ",m" + Integer.toHexString(Ss1Music.mapSig(musicAll));
                }
                musicNote = ss1rom == null ? MUSIC_NO_ROM : MUSIC_OK;
            }
        }
        try {
            File rom = new File(romPath);
            File pdir = new File(MainActivity.root(), "patch");

            /* 패치 고르기 — 우선순위:
               ① 수동: patch/<롬파일명(확장자 뺌)>.ips — 게임 표에 없는 롬도 입힌다.
                  유저가 아무 IPS 나 직접 넣는 자리다. 언어 설정과 무관하게 항상.
               ② 내려받은 것: patch/<게임id>_ko.ips — 「업데이트 확인」이 받아 둔 최신판.
               ③ 동봉: assets/patch/<게임id>_ko.ips. */
            byte[] ips = null;
            String pver = "";                                 /* 도장용 패치판 표시 */
            String base = rom.getName();
            int dot = base.lastIndexOf('.');
            if (dot > 0) base = base.substring(0, dot);
            File manual = new File(pdir, base + ".ips");
            byte[] mb = readFile(manual);
            if (mb != null) {
                ips = mb;
                pver = "m" + manual.length() + "." + manual.lastModified();
            } else if (name != null) {
                File dl = new File(pdir, name);
                ips = readFile(dl);
                if (ips != null) {
                    String v = readText(new File(dl.getPath()
                            .substring(0, dl.getPath().length() - 4) + ".ver"));
                    pver = (v != null) ? v : "dl";
                } else {
                    ips = readAsset(ctx, "patch/" + name);
                }
            }
            if (ips == null && extra == null && mods.isEmpty() && ss1rom == null && !musicMute)
                return romPath;                               /* 쓸 패치가 하나도 없다 */

            /* 사본 이름은 원본과 같게 둔다 — 상태저장·세이브 파일 이름이 롬 이름에서 나오므로,
               이름이 바뀌면 언어를 바꿀 때마다 세이브가 갈라진다.
               대신 도장에 언어·문턱 여부를 적어 둔다. 어느 쪽이 바뀌어도 다시 만든다.

               ★예외 하나 — saveTag 가 붙은 패치(롬의 세이브 구역 자체를 바꾸는 것, 예: 올카드).
               그건 **반대 이유로 갈라야** 한다. 코어는 롬을 읽을 때마다 <롬이름>.flash 를 롬 위에
               되쓰므로(ngp/rom.c → flash.c), 이름이 같으면 기기에 있던 세이브가 그 바이트를 덮어
               「켜도 아무 일이 없는」 스위치가 된다. 이름을 가르면 그 판이 자기 세이브를 갖고,
               끄면 원래 이름으로 돌아가 원래 진행도가 그대로 기다린다. */
            String tag = saveTag.toString();
            String outName = rom.getName();
            if (!tag.isEmpty()) {
                int dotIdx = outName.lastIndexOf('.');
                outName = (dotIdx > 0)
                        ? outName.substring(0, dotIdx) + tag + outName.substring(dotIdx)
                        : outName + tag;
            }
            File out = new File(new File(MainActivity.root(), DIR), outName);
            File stamp = new File(out.getPath() + ".stamp");
            String want = lang + ":" + rom.length() + ":" + rom.lastModified() + ":"
                        + (ips != null ? ips.length : 0)
                        + ":F" + (extra != null ? extra.length : 0)
                        + ":M" + modSig
                        + ":P" + pver                         /* 새 판 받으면 다시 입힌다 */
                        + ":S" + musicSig;                     /* 사무쇼2 배경음악(SS1) */

            /* 배경음악을 심은 사본은 «심기 전» md5 기록(.base)이 있어야 한다 — 연습 대전이 판을 알아보는 근거. 없으면(옛 판이 구운 사본) 다시 굽는다 */
            boolean baseOk = (ss1rom == null && !musicMute) || new File(out.getPath() + ".base").exists();
            if (out.exists() && want.equals(readText(stamp)) && baseOk) {
                if (ss1rom != null || musicMute) {
                    String mres = readText(new File(out.getPath() + ".music"));
                    if ("fail".equals(mres)) musicNote = musicMute ? MUSIC_MUTE_FAIL : MUSIC_FAIL;
                    else if (mres != null && mres.startsWith("part ")) musicNote = MUSIC_OK + " (" + mres.substring(5) + "곡)";
                }
                return out.getPath();
            }

            byte[] data = readFile(rom);
            if (data == null) return romPath;

            byte[] done = data;
            if (ips != null) {
                done = apply(done, ips);
                if (done == null) return romPath;            /* 형식이 어긋남 — 원본으로 */
            }
            if (extra != null) {
                byte[] d2 = apply(done, extra);              /* 한패 위에 겹쳐 입힌다 */
                if (d2 != null) done = d2;                   /* 문턱 패치 실패는 치명 아님 */
            }
            for (byte[] modb : mods) {                       /* 조작 패치 — 한패·서로 간 겹침 없음이 원칙 */
                byte[] d3 = apply(done, modb);
                if (d3 != null) done = d3;
            }
            boolean musicFail = false;
            String musicRes = "ok";
            byte[] beforeMusic = done;                       /* 배경음악을 심기 전(원본 + 번역·문턱·조작 패치) — .base 기록용 */
            if (ss1rom != null || musicMute) {               /* 맨 마지막 — 한패·조작 패치가 쓰고 남은 빈칸에 심는다 */
                /* 빈칸 = 원래 롬의 끝 채움 중 어느 패치도 안 쓴 바이트. 패치가 0xFF 로 쓴 자리도 «쓴 것» —
                   한패 v1.01 은 줄인 대사 뒤를 0xFF 로 메우고 빈 줄로 가리킨다(거기 곡을 쓰면 그 장면에서 멈춘다). */
                boolean[] touched = new boolean[done.length];
                if (ips != null) markIps(ips, touched);
                if (extra != null) markIps(extra, touched);
                for (byte[] modb : mods) markIps(modb, touched);
                boolean[] sp = Ss1Music.spare(done, data, touched);
                byte[] d4 = musicMute ? Ss1Music.mute(done, sp) : Ss1Music.apply(done, ss1rom, musicAll, sp);
                if (d4 != null) {
                    done = d4;
                    if (Ss1Music.lastPlaced < Ss1Music.lastWanted) {   /* 빈칸이 모자라 일부 장면은 원래 곡 */
                        musicRes = "part " + Ss1Music.lastPlaced + "/" + Ss1Music.lastWanted;
                        musicNote = MUSIC_OK + " (" + Ss1Music.lastPlaced + "/" + Ss1Music.lastWanted + "곡)";
                    }
                }
                else { musicFail = true; musicNote = musicMute ? MUSIC_MUTE_FAIL : MUSIC_FAIL; }
            }
            if (java.util.Arrays.equals(done, data)) return romPath;  /* 아무 변화 없음 */

            out.getParentFile().mkdirs();
            try (FileOutputStream fo = new FileOutputStream(out)) { fo.write(done); }
            writeText(stamp, want);
            writeText(new File(out.getPath() + ".music"), musicFail ? "fail" : musicRes);
            /* .base = «심기 전 md5 심은 뒤 md5». 배경음악은 소리 자료(빈칸)와 그 주소를 가리키는 조립 코드 즉시값만 바꾸고 게임 램 배치는
               그대로라, 심기 전 판이 판정 주소를 실측한 판(League.romLabel)이면 연습 대전을 켤 수 있다(EmuActivity.practiceSetup). */
            writeText(new File(out.getPath() + ".base"), (ss1rom != null || musicMute) && !musicFail
                    ? md5(beforeMusic) + " " + md5(done) : "");
            return out.getPath();
        } catch (Exception e) {
            return romPath;
        }
    }

    /** IPS 적용. 형식이 어긋나면 null — 반쯤 입힌 롬을 내보내지 않는다.
     *  들어온 배열은 **건드리지 않는다.** 처음엔 제자리에서 고쳤는데, 그러면 돌려준 배열이
     *  입력과 같은 객체라 「입혀도 그대로인가」 비교가 항상 참이 되어 한패가 영영 안 입혀졌다.
     *  실측에서 네 롬 전부 「이미 한패 롬」으로 나온 것이 이 때문이었다. */
    private static byte[] apply(byte[] rom, byte[] ips) {
        if (ips.length < 8 || ips[0] != 'P' || ips[1] != 'A' || ips[2] != 'T'
                           || ips[3] != 'C' || ips[4] != 'H') return null;
        byte[] out = rom.clone();
        int p = 5;
        while (p + 3 <= ips.length) {
            if (ips[p] == 'E' && ips[p+1] == 'O' && ips[p+2] == 'F') {
                p += 3;
                if (p + 3 <= ips.length) {                  /* 잘라내기 기록 */
                    int cut = ((ips[p] & 0xff) << 16) | ((ips[p+1] & 0xff) << 8) | (ips[p+2] & 0xff);
                    if (cut > 0 && cut < out.length) {
                        byte[] t = new byte[cut];
                        System.arraycopy(out, 0, t, 0, cut);
                        out = t;
                    }
                }
                return out;
            }
            if (p + 5 > ips.length) return null;
            int off = ((ips[p] & 0xff) << 16) | ((ips[p+1] & 0xff) << 8) | (ips[p+2] & 0xff);
            int len = ((ips[p+3] & 0xff) << 8) | (ips[p+4] & 0xff);
            p += 5;
            if (len == 0) {                                 /* RLE */
                if (p + 3 > ips.length) return null;
                int run = ((ips[p] & 0xff) << 8) | (ips[p+1] & 0xff);
                byte v = ips[p+2];
                p += 3;
                out = grow(out, off + run);
                for (int i = 0; i < run; i++) out[off + i] = v;
            } else {
                if (p + len > ips.length) return null;
                out = grow(out, off + len);
                System.arraycopy(ips, p, out, off, len);
                p += len;
            }
        }
        return null;                                        /* EOF 를 못 만났다 */
    }

    /** IPS 가 쓰는 바이트를 mark 에 표시한다(데이터·RLE 모두). 형식이 어긋나면 거기서 멈춘다. */
    static void markIps(byte[] ips, boolean[] mark) {
        if (ips == null || ips.length < 8 || ips[0] != 'P' || ips[1] != 'A' || ips[2] != 'T'
                || ips[3] != 'C' || ips[4] != 'H') return;
        int p = 5;
        while (p + 3 <= ips.length) {
            if (ips[p] == 'E' && ips[p+1] == 'O' && ips[p+2] == 'F') return;
            if (p + 5 > ips.length) return;
            int off = ((ips[p] & 0xff) << 16) | ((ips[p+1] & 0xff) << 8) | (ips[p+2] & 0xff);
            int len = ((ips[p+3] & 0xff) << 8) | (ips[p+4] & 0xff);
            p += 5;
            if (len == 0) {
                if (p + 3 > ips.length) return;
                len = ((ips[p] & 0xff) << 8) | (ips[p+1] & 0xff);
                p += 3;
            } else {
                p += len;
            }
            for (int k = off; k < off + len && k < mark.length; k++) mark[k] = true;
        }
    }

    private static byte[] grow(byte[] a, int need) {
        if (need <= a.length) return a;
        byte[] b = new byte[need];
        System.arraycopy(a, 0, b, 0, a.length);
        return b;
    }

    private static byte[] readAsset(Context ctx, String name) {
        try (InputStream in = ctx.getAssets().open(name)) {
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] buf = new byte[16384];
            int n;
            while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
            return bo.toByteArray();
        } catch (Exception e) {
            return null;
        }
    }

    static String md5(byte[] b) {
        try {
            java.security.MessageDigest md = java.security.MessageDigest.getInstance("MD5");
            StringBuilder sb = new StringBuilder();
            for (byte x : md.digest(b)) sb.append(String.format("%02x", x & 0xff));
            return sb.toString();
        } catch (Exception e) { return ""; }
    }

    /** 배경음악을 심은 사본의 «심기 전» 판 이름(League.romLabel) — .base 기록이 지금 사본(md5)과 맞고 심기 전 판을 알 때만. 아니면 null */
    static String musicBaseLabel(String copyPath, String copyMd5) {
        String t = readText(new File(copyPath + ".base"));
        if (t == null) return null;
        String[] w = t.trim().split(" ");
        if (w.length != 2 || !w[1].equals(copyMd5)) return null;
        String lab = League.romLabel(w[0]);
        return lab == null ? null : lab + " + 배경음악";
    }

    static byte[] readFile(File f) {
        long len = f.length();
        if (len <= 0 || len > 64L * 1024 * 1024) return null;
        byte[] b = new byte[(int) len];
        try (FileInputStream in = new FileInputStream(f)) {
            int n = 0;
            while (n < b.length) {
                int r = in.read(b, n, b.length - n);
                if (r < 0) return null;
                n += r;
            }
            return b;
        } catch (Exception e) {
            return null;
        }
    }

    /** 도장을 읽는다. 예전에는 128 B 를 «한 번만» 읽어서, 도장이 그보다 길어지면 읽은 값이 잘려
     *  비교가 영원히 거짓이 됐다 — 게임을 열 때마다 2~4 MB 를 조용히 다시 굽는다(오류도 안 뜬다).
     *  mods 가 늘면 실제로 넘는 길이라 끝까지 읽는다. 짧은 도장은 읽는 값이 같아 기존 것을 안 버린다. */
    private static String readText(File f) {
        try (FileInputStream in = new FileInputStream(f)) {
            byte[] b = new byte[512];
            int n = 0;
            while (n < b.length) { int r = in.read(b, n, b.length - n); if (r < 0) break; n += r; }
            return n > 0 ? new String(b, 0, n, "UTF-8").trim() : null;
        } catch (Exception e) {
            return null;
        }
    }

    private static void writeText(File f, String s) {
        try (FileOutputStream fo = new FileOutputStream(f)) {
            fo.write(s.getBytes("UTF-8"));
        } catch (Exception ignored) { }
    }

    private Patcher() { }
}
