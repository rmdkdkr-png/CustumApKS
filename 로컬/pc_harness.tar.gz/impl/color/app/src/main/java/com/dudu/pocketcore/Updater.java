package com.dudu.pocketcore;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.provider.Settings;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

/** 앱 안 「업데이트 확인」 — PC(같은 와이파이)의 릴리즈 서버에서 새 판을 받아 설치창까지.
 *  채팅으로 zip 받아 파일앱을 뒤지는 흐름이 귀찮다는 제보로 만들었다.
 *  서버 주소는 options.txt 의 pocketcore_update_url (기본 http://192.168.1.68:8765).
 *  서버에는 version.json({"versionCode":..,"versionName":"..","apk":".."})과 APK 가 있다. */
public final class Updater {

    /* Legacito(com.dudu.legacito) 전용 색인 — 옛 PocketCore(1.x~4.04, dudu 키)는 version.json·cores.json 을 계속 본다.
       옛 서명 키를 잃어(2026-10-10) 새 앱으로 갈라섰다. 같은 릴리즈 태그 app 에 이름만 다른 색인을 둔다.
       legacito-cores.json 이 따로인 이유: 옛 cores.json 의 ss2 코어(3.71)는 프레임 생성이 없어, 받으면 동봉 코어를 덮어 기능이 사라진다. */
    static final String VERSION_INDEX = "legacito-version.json";
    static final String CORES_INDEX   = "legacito-cores.json";

    static String baseUrl() {
        String v = null;
        try { v = Settings2.readOpt("pocketcore_update_url"); } catch (Throwable ignored) { }
        /* 기본은 PocketCore 저장소의 고정 태그 app — 앱은 앱 레포에서 받는다
           (한패 IPS 는 KrPatch, 코어·음성팩은 ss2-sp-core 릴리즈를 색인이 가리킨다).
           v3.48 이하는 KrPatch 의 옛 태그를 보지만, 앱 확인이 먼저라 새 APK 로
           갈아탄 뒤 여기로 온다. 개발 중 집 와이파이가 더 빠르면 options.txt 에
           pocketcore_update_url=http://192.168.1.68:8765 를 적어 갈아탈 수 있다. */
        return (v != null && !v.isEmpty()) ? v
                : "https://github.com/rmdkdkr-png/PocketCore/releases/download/app";
    }

    /* Settings.load() 는 앱 Settings 클래스지만 이름이 android.provider.Settings 와 겹쳐
       여기서만 쓰는 얇은 우회를 둔다. */
    static final class Settings2 {
        static String readOpt(String key) {
            java.util.Map<String, String> m = com.dudu.pocketcore.Settings.load();
            return m.get(key);
        }
    }

    /** 배포 레벨 — options.txt 의 pocketcore_level. "test" 면 색인의 시험 항목(version.json "test" / cores[id]["test"])을
     *  받고, 아니면 정식(최상위 필드 — 옛 앱과 같은 자리)만 본다. 유저 2026-09-04 「릴리즈는 신나게, 배포 레벨만 정하자」. */
    static boolean testLevel() {
        String v = null;
        try { v = Settings2.readOpt("pocketcore_level"); } catch (Throwable ignored) { }
        return "test".equals(v);
    }
    static String levelTag() { return testLevel() ? " (시험)" : ""; }
    private static String myName(Activity a) {
        try { return a.getPackageManager().getPackageInfo(a.getPackageName(), 0).versionName; }
        catch (Exception e) { return "?"; }
    }

    public static void check(final Activity act) {
        toast(act, "업데이트 확인 중…");
        new Thread(new Runnable() { @Override public void run() {
            String base = baseUrl();
            boolean idle;                      /* 앱이 최신이라 설치 흐름으로 안 빠졌나 */
            try {
                idle = checkApk(act, base);
            } catch (Exception e) {
                toast(act, "업데이트 실패: " + e.getClass().getSimpleName()
                        + " — 인터넷 연결을 확인해 주세요");
                return;                        /* 릴리즈에 못 닿으면 한패도 못 받는다 */
            }
            /* 앱이 최신일 때만 컨텐츠 동기화 — 새 앱을 설치하러 떠나는 중이면 다음에 받는다.
               앱(APK)은 앱이 바뀔 때만 갈고, 코어·음성팩·한글패치는 여기서 따로 받는다. */
            /* 자료(한패 색인·IPS·조작패치·디자인)는 앱이 최신이 아니어도 받는다 — 전엔 새 앱 안내가 뜨면
               전부 건너뛰어, 설치를 미룬 기기는 색인을 영영 못 받아 롬 스캔이 순정 판별을 못 했다(2026-09-05).
               코어는 코드라 앱이 최신일 때만(옛 앱에 새 코어를 얹지 않는다). 소식 창은 설치 안내와 겹치지 않게. */
            if (idle) syncCores(act, base);
            syncPatches(act, base); syncMods(act); syncDesign(base);
            if (idle) showNews(act, base);
        }}).start();
    }

    /** 디자인 메타데이터(런처 정보줄 + 배포 썸네일) — 정보는 덮고, 썸은 판 비교로 받는다. */
    private static void syncDesign(String base) {
        try {
            byte[] jb = fetch(base + "/design.json", 10000);   /* 모바일 리다이렉트가 4초를 넘겨 SocketTimeout 나던 제보 */
            JSONObject j = new JSONObject(new String(jb, "UTF-8"));
            File dir = new File(MainActivity.root(), "design");
            dir.mkdirs();
            FileOutputStream fo = new FileOutputStream(new File(dir, "design.json"));
            fo.write(jb); fo.close();

            /* 게임표 — 앱 업데이트 없이 게임을 늘리는 자리. 내장표를 «덮지 않고» 뒤에 붙는다.
               못 받아도 그냥 지나간다(내장표만으로 돌아간다). */
            try {
                byte[] gb = fetch(base + "/games.json", 10000);
                FileOutputStream gf = new FileOutputStream(new File(dir, "games.json"));
                gf.write(gb); gf.close();
                Games.loadExtras(dir);
            } catch (Throwable ignored) { }

            /* 배포 지정 썸네일 — PC 지정툴(thumbtool)이 고른 장면. 런처 우선순위는
               내 지정 > 이것 > 자동 캡처. 판(ver=파일 md5)이 바뀐 것만 받는다. */
            JSONObject th = j.optJSONObject("thumbs");
            if (th == null) return;
            File td = new File(dir, "thumbs/byid");
            td.mkdirs();
            java.util.Iterator<String> it = th.keys();
            while (it.hasNext()) {
                String id = it.next();
                JSONObject e = th.getJSONObject(id);
                String ver = e.getString("ver");
                File png = new File(td, id + ".png");
                File verf = new File(td, id + ".ver");
                if (png.exists() && ver.equals(readSmall(verf))) continue;
                byte[] b = fetch(e.getString("url"), 15000);
                if (b.length < 8 || b[0] != (byte) 0x89 || b[1] != 'P'
                                 || b[2] != 'N' || b[3] != 'G') continue;
                FileOutputStream po = new FileOutputStream(png);
                po.write(b); po.close();
                writeSmall(verf, ver);
            }
        } catch (Exception ignored) { /* 장식 — 없어도 런처는 뜬다 */ }
    }

    /** 소식 창 — 릴리즈의 news.json(배포 때마다 자동으로 쌓인다)을 그대로 보여 준다.
     *  앱·코어·한패·음성팩이 각자 따로 갱신되니, 뭐가 언제 바뀌었는지 한 자리에. */
    private static void showNews(final Activity act, String base) {
        try {
            byte[] jb = fetch(base + "/news.json", 10000);   /* 모바일 리다이렉트가 4초를 넘겨 SocketTimeout 나던 제보 */
            org.json.JSONArray items = new JSONObject(new String(jb, "UTF-8"))
                    .getJSONArray("items");
            final StringBuilder sb = new StringBuilder();
            int n = Math.min(items.length(), 12);
            for (int i = 0; i < n; i++) {
                org.json.JSONObject e = items.getJSONObject(i);
                sb.append(e.optString("date", "")).append("  ")
                  .append(e.optString("text", "")).append('\n');
            }
            if (sb.length() == 0) return;
            act.runOnUiThread(new Runnable() { @Override public void run() {
                new android.app.AlertDialog.Builder(act)
                        .setTitle("최근 업데이트")
                        .setMessage(sb.toString())
                        .setPositiveButton("확인", null)
                        .show();
            }});
        } catch (Exception ignored) { /* 소식은 부가 정보 — 실패해도 조용히 */ }
    }

    /** 코어·음성팩 동기화 — cores.json 을 보고 기기 ABI 에 맞는 코어를 **앱 내부
     *  저장소**(files/cores/)에 받는다. sdcard 는 실행권이 없어(noexec) dlopen 이
     *  안 되는 기기가 많다 — 그래서 내부다. 음성팩은 데이터라 PocketCore/system/ 에 둔다.
     *  덕분에 코어만 바뀐 날은 APK 재설치(옆설치 경고) 없이 여기서 끝난다. */
    private static void syncCores(Activity act, String base) {
        try {
            byte[] jb = fetch(base + "/" + CORES_INDEX, 10000);   /* 모바일 리다이렉트가 4초를 넘겨 SocketTimeout 나던 제보 */
            JSONObject root = new JSONObject(new String(jb, "UTF-8"));
            StringBuilder got = new StringBuilder();

            JSONObject cores = root.optJSONObject("cores");
            if (cores != null) {
                String abi = android.os.Build.SUPPORTED_ABIS[0];
                File dir = new File(act.getFilesDir(), "cores");
                dir.mkdirs();
                java.util.Iterator<String> it = cores.keys();
                while (it.hasNext()) {
                    String id = it.next();
                    JSONObject e = cores.getJSONObject(id);
                    boolean useTest = testLevel() && e.optJSONObject("test") != null;
                    JSONObject use = useTest ? e.getJSONObject("test") : e;   /* 시험 레벨이면 시험 판 — 없으면 정식 */
                    String ver = use.getString("ver") + (useTest ? "-test" : "");   /* .ver 표식 — 레벨을 바꾸면 다시 받게 */
                    JSONObject abis = use.getJSONObject("abis");
                    if (!abis.has(abi)) continue;
                    File so = new File(dir, id + ".so");
                    File verf = new File(dir, id + ".ver");
                    if (so.exists() && ver.equals(readSmall(verf))) continue;
                    File tmp = new File(dir, id + ".part");
                    fetchToFile(abis.getString(abi), tmp, 60000);
                    if (!looksLike(tmp, 0x7f, 'E', 'L', 'F')) { tmp.delete(); continue; }
                    so.delete();
                    if (!tmp.renameTo(so)) continue;
                    writeSmall(verf, ver);
                    if (got.length() > 0) got.append(" · ");
                    got.append(e.optString("ko", id)).append(' ').append(use.getString("ver")).append(useTest ? " (시험)" : "");
                }
            }

            JSONObject packs = root.optJSONObject("packs");
            if (packs != null) {
                java.util.Iterator<String> it = packs.keys();
                while (it.hasNext()) syncPack(act, packs.getJSONObject(it.next()), got);
            }
            /* packs_ext — 110 이후 판만 읽는 팩(옛 판은 이 열쇠를 모른다). 항목마다 "min" = 받을 수 있는 가장 낮은 versionCode.
               사무쇼2 모션 캐시(코어 패치 97)는 그걸 쓰는 코어가 든 판에서만 받게 — 정식 0.9 가 수십 MB 를 헛받지 않게 */
            JSONObject ext = root.optJSONObject("packs_ext");
            if (ext != null) {
                long my = 0;
                try { my = act.getPackageManager().getPackageInfo(act.getPackageName(), 0).getLongVersionCode(); }
                catch (Throwable t) { try { my = act.getPackageManager().getPackageInfo(act.getPackageName(), 0).versionCode; } catch (Throwable ignored) { } }
                java.util.Iterator<String> it = ext.keys();
                while (it.hasNext()) {
                    JSONObject e = ext.getJSONObject(it.next());
                    if (my < e.optLong("min", Long.MAX_VALUE)) continue;
                    syncPack(act, e, got);
                }
            }

            if (got.length() > 0)
                toast(act, "새로 받음: " + got + " — 게임을 다시 열면 적용됩니다");
        } catch (Exception e) {
            toast(act, "코어 확인 실패: " + e.getClass().getSimpleName());
        }
    }

    /** 런처가 켜질 때(앱이 최신일 때) 팩만 조용히 — 와이파이 같은 무제한 연결일 때만. 받을 게 없으면 아무 말도 안 한다.
     *  113: 시험 판 사무쇼2 모션 캐시가 «업데이트 확인»을 한 번 더 눌러야 받혀, 받은 줄 모르고 «효과가 있는 거임?»(유저 2026-10-11) */
    static void autoPacks(Activity act) {
        try {
            android.net.ConnectivityManager cm = (android.net.ConnectivityManager) act.getSystemService(android.content.Context.CONNECTIVITY_SERVICE);
            if (cm == null || cm.isActiveNetworkMetered()) return;
            byte[] jb = fetch(baseUrl() + "/" + CORES_INDEX, 10000);
            JSONObject root = new JSONObject(new String(jb, "UTF-8"));
            StringBuilder got = new StringBuilder();
            long my = 0;
            try { my = act.getPackageManager().getPackageInfo(act.getPackageName(), 0).getLongVersionCode(); }
            catch (Throwable t) { try { my = act.getPackageManager().getPackageInfo(act.getPackageName(), 0).versionCode; } catch (Throwable ignored) { } }
            JSONObject ext = root.optJSONObject("packs_ext");
            if (ext != null) {
                java.util.Iterator<String> it = ext.keys();
                while (it.hasNext()) {
                    JSONObject e = ext.getJSONObject(it.next());
                    if (my < e.optLong("min", Long.MAX_VALUE)) continue;
                    syncPack(act, e, got);
                }
            }
            if (got.length() > 0)
                toast(act, "새로 받음: " + got + " — 게임을 다시 열면 적용됩니다");
        } catch (Throwable ignored) { /* 조용히 — 다음에 업데이트 확인 때 받는다 */ }
    }

    /** 팩 하나 — 시스템 폴더에 file 로 받는다(같은 ver 면 건너뜀, size 가 다르면 버림). */
    private static void syncPack(Activity act, JSONObject e, StringBuilder got) throws Exception {
        String ver = e.getString("ver");
        File dst = new File(MainActivity.sysDir(), e.getString("file"));
        File verf = new File(dst.getPath() + ".ver");
        if (dst.exists() && ver.equals(readSmall(verf))) return;
        long mb = e.optLong("size", 0) >> 20;
        toast(act, e.optString("ko", "팩") + " " + ver + " 내려받는 중…"
                + (mb > 0 ? " (" + mb + "MB)" : ""));
        File tmp = new File(dst.getPath() + ".part");
        fetchToFile(e.getString("url"), tmp, 600000);
        long want = e.optLong("size", 0);
        if (want > 0 && tmp.length() != want) { tmp.delete(); return; }
        dst.delete();
        if (!tmp.renameTo(dst)) return;
        writeSmall(verf, ver);
        if (got.length() > 0) got.append(" · ");
        got.append(e.optString("ko", "팩")).append(' ').append(ver);
    }

    /** 파일 머리 몇 바이트 대조 — 오류 페이지를 코어라고 저장하는 사고 방지. */
    private static boolean looksLike(File f, int... magic) {
        try (java.io.FileInputStream in = new java.io.FileInputStream(f)) {
            for (int m : magic) if (in.read() != (m & 0xff)) return false;
            return true;
        } catch (Exception e) { return false; }
    }

    /** 큰 파일용 스트리밍 다운로드 — 통째로 메모리에 안 올린다(음성팩은 수백 MB). 새 판 설치(SelfUpdate)도 쓴다. */
    static void fetchToFile(String url, File out, int timeoutMs) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setConnectTimeout(15000); c.setReadTimeout(timeoutMs);
        InputStream in = new BufferedInputStream(c.getInputStream());
        FileOutputStream fo = new FileOutputStream(out);
        byte[] buf = new byte[262144];
        int n;
        while ((n = in.read(buf)) > 0) fo.write(buf, 0, n);
        fo.close(); in.close(); c.disconnect();
    }

    /** 앱 새 판 확인. 설치·설정 화면으로 넘어가면 false, 이미 최신이면 true. */
    private static boolean checkApk(Activity act, String base) throws Exception {
        byte[] jb = fetch(base + "/" + VERSION_INDEX, 10000);   /* 모바일 리다이렉트가 4초를 넘겨 SocketTimeout 나던 제보 */
        JSONObject j = new JSONObject(new String(jb, "UTF-8"));
        boolean useTest = testLevel() && j.optJSONObject("test") != null;
        if (useTest) j = j.getJSONObject("test");            /* 시험 레벨이면 시험 항목 — 없으면 정식 */
        int rc = j.getInt("versionCode");
        String rn = j.optString("versionName", "?") + (useTest ? " (시험)" : "");
        String apk = j.getString("apk");
        int my;
        try { my = (int) act.getPackageManager()
                .getPackageInfo(act.getPackageName(), 0).getLongVersionCode(); }
        catch (Throwable t) { my = act.getPackageManager()
                .getPackageInfo(act.getPackageName(), 0).versionCode; }
        if (rc <= my) {
            /* 시험 판을 쓰다 정식으로 되돌린 경우 — 안드로이드는 판번호를 낮추는 설치를 막는다.
               조용히 「최신입니다」라고만 하면 되돌린 줄 알고 계속 시험 판을 쓰게 된다. */
            if (!testLevel() && rc < my)
                toast(act, "지금 깔린 것은 시험 판(v" + myName(act) + ")입니다 — 정식 v" + rn
                        + " 으로 되돌리려면 앱을 지우고 다시 설치하세요 (저장 파일은 남습니다)");
            else
                toast(act, "앱은 최신 " + (testLevel() ? "시험 판" : "정식 판") + "입니다 (v" + rn + " · 내부 " + my + ")");
            return true;
        }
        toast(act, "v" + rn + " 다운로드 중… (내부 " + my + " → " + rc + ")");   /* 보이는 판은 0.9 그대로라 내부 번호로 구분 */
        /* 120~: 앱 안쪽에 받아(패키지·판 확인) PackageInstaller 세션으로(SelfUpdate). 132 부터는 확인 없이 업데이트 권한을 빼서
           (유저 「유해한 앱이라고 아직도 떠」 → 「빼줘」) 늘 시스템 확인 창 한 번 → 깔리면 앱이 닫힌다(다시 열면 새 판).
           세션이 안 되면 예전처럼 설치창(ACTION_VIEW). 유저가 누를 때만 깐다(뒤에서 저절로 깔지 않음). */
        File staged = SelfUpdate.stage(act, base + "/" + Uri.encode(apk), rc);
        if (staged == null) throw new java.io.IOException("받은 파일이 내부 " + rc + " 판이 아님");
        if (!act.getPackageManager().canRequestPackageInstalls()) {
            toast(act, "「이 출처 허용」을 켠 뒤 다시 눌러 주세요 (최초 1회)");
            Intent p = new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                    Uri.parse("package:" + act.getPackageName()));
            p.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            act.startActivity(p);
            return false;
        }
        try {
            if (SelfUpdate.supported())
                toast(act, "확인 창에서 「업데이트」를 누르세요 — 다 깔리면 앱이 닫히니 다시 열어 주세요");
            SelfUpdate.install(act, staged, rc);
            return false;
        } catch (Throwable t) {
            android.util.Log.w(SelfUpdate.TAG, "session install failed — fallback", t);
        }
        File out = new File(act.getCacheDir(), "update.apk");
        try (java.io.FileInputStream in = new java.io.FileInputStream(staged); FileOutputStream fo = new FileOutputStream(out)) {
            byte[] buf = new byte[262144]; int n;
            while ((n = in.read(buf)) > 0) fo.write(buf, 0, n);
        }
        Intent i = new Intent(Intent.ACTION_VIEW);
        i.setDataAndType(Uri.parse("content://" + act.getPackageName() + ".apk/update.apk"),
                "application/vnd.android.package-archive");
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
        act.startActivity(i);
        return false;
    }

    /** 조용한 확인 — 지금 배포 레벨의 새 판이 있으면 그 내부 번호, 없거나 못 닿으면 0. 아무것도 안 띄운다(런처 버튼 표시용). */
    static int peekNewer(Activity act) {
        try {
            byte[] jb = fetch(baseUrl() + "/" + VERSION_INDEX, 8000);
            JSONObject j = new JSONObject(new String(jb, "UTF-8"));
            if (testLevel() && j.optJSONObject("test") != null) j = j.getJSONObject("test");
            int rc = j.getInt("versionCode"), my;
            try { my = (int) act.getPackageManager().getPackageInfo(act.getPackageName(), 0).getLongVersionCode(); }
            catch (Throwable t) { my = act.getPackageManager().getPackageInfo(act.getPackageName(), 0).versionCode; }
            return rc > my ? rc : 0;
        } catch (Throwable e) {
            return 0;
        }
    }

    /** 색인만 받아 둔다 — 롬 스캔이 순정 판별(rom_md5)에 쓴다. 색인이 없는 기기에서 스캔이 직접 부른다.
     *  오류 페이지를 색인으로 남기지 않게 JSON 으로 열리는지 본 뒤 쓴다. 실패는 조용히 false. */
    static boolean fetchIndex() {
        try {
            byte[] jb = fetch(baseUrl() + "/patches.json", 10000);
            new JSONObject(new String(jb, "UTF-8")).getJSONObject("patches");
            File dir = new File(MainActivity.root(), "patch");
            dir.mkdirs();
            try (FileOutputStream pj = new FileOutputStream(new File(dir, "patches.json"))) { pj.write(jb); }
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    /** 한글패치 동기화 — 릴리즈의 patches.json(게임 id → 최신 IPS 주소·판)을 보고
     *  PocketCore/patch/ 에 내려받는다. Patcher 는 이 폴더를 동봉 assets 보다 먼저 본다.
     *  판 비교는 .ver 파일 내용으로 한다 — 크기 비교는 「번역만 바뀐 같은 크기 판」을
     *  건너뛴 전력이 있어(배포처 관례) 판 문자열로만 가른다. */
    private static void syncPatches(Activity act, String base) {
        try {
            byte[] jb = fetch(base + "/patches.json", 10000);   /* 모바일 리다이렉트가 4초를 넘겨 SocketTimeout 나던 제보 */
            JSONObject j = new JSONObject(new String(jb, "UTF-8")).getJSONObject("patches");
            File dir = new File(MainActivity.root(), "patch");
            dir.mkdirs();
            /* 색인을 그대로 남긴다 — 롬 스캔이 rom_md5(우리가 아는 원본) 를 여기서 읽는다.
               앱에 표를 박지 않으므로 덤프를 늘려도 APK 를 다시 안 구워도 된다. */
            try (FileOutputStream pj = new FileOutputStream(new File(dir, "patches.json"))) {
                pj.write(jb);
            } catch (Exception ignored) { }
            StringBuilder got = new StringBuilder();
            java.util.Iterator<String> it = j.keys();
            while (it.hasNext()) {
                String id = it.next();
                JSONObject e = j.getJSONObject(id);
                /* 시험 갈래 — 코어·앱과 같은 방식(options.txt 의 pocketcore_level=test).
                   그 항목이 없으면 정식 그대로다. .ver 에 "-test" 를 붙여, 레벨을 되돌리면
                   판 문자열이 달라져 정식 판을 다시 받는다. */
                boolean useTest = testLevel() && e.optJSONObject("test") != null;
                JSONObject use = useTest ? e.getJSONObject("test") : e;
                String ver = use.getString("ver") + (useTest ? "-test" : "");
                File ips = new File(dir, id + "_ko.ips");
                File verf = new File(dir, id + "_ko.ver");
                if (ips.exists() && ver.equals(readSmall(verf))) continue;
                byte[] b = fetch(use.getString("url"), 30000);
                /* IPS 서명 확인 — 오류 페이지를 패치로 저장하는 사고 방지 */
                if (b.length < 8 || b[0] != 'P' || b[1] != 'A' || b[2] != 'T'
                                 || b[3] != 'C' || b[4] != 'H') continue;
                FileOutputStream fo = new FileOutputStream(ips);
                fo.write(b); fo.close();
                writeSmall(verf, ver);
                if (got.length() > 0) got.append(" · ");
                got.append(use.optString("ko", e.optString("ko", id))).append(' ').append(ver);
            }
            toast(act, got.length() > 0
                    ? "한글패치 새 판: " + got + " — 게임을 다시 열면 적용됩니다"
                    : "한글패치도 모두 최신입니다");
        } catch (Exception e) {
            toast(act, "한글패치 확인 실패: " + e.getClass().getSimpleName());
        }
    }

    /** 조작 패치 채널 — PocketCore 레포 고정 태그 `mods` 의 mods.json 을 받아 PocketCore/mods/ 에 색인과
     *  IPS 를 둔다(판 비교는 .ver). 설정 화면이 색인으로 게임별 토글을 만들고, Patcher 가 켜진 것만 얹는다.
     *  한패(patches.json)와 다른 채널인 이유: 번역이 아닌 게임플레이 개조라 섞으면 「한패가 게임을 바꿨다」로 읽힌다. */
    static final String MODS = "https://github.com/rmdkdkr-png/InputPatch/releases/download/mods";   /* 인풋패치의 집 */
    private static void syncMods(Activity act) {
        try {
            byte[] jb = fetch(MODS + "/mods.json", 10000);
            org.json.JSONArray arr = new JSONObject(new String(jb, "UTF-8")).getJSONArray("mods");   /* JSON 으로 안 열리면 여기서 예외 → 옛 색인 유지 */
            File dir = com.dudu.pocketcore.Settings.modsDir();
            dir.mkdirs();
            /* ★ 색인부터 쓴다 — 전엔 IPS 를 다 받은 뒤에 썼는데, 하나라도 못 받으면 예외로 빠져 색인이 옛 것으로 남았다.
               그래서 기기에 「FastCD v1.1 켬/끔」이 다이얼로 안 바뀌고 남아 있었다(제보 2026-09-05). Patcher 는 IPS 없는 항목을 건너뛴다. */
            try (FileOutputStream fo = new FileOutputStream(new File(dir, "mods.json"))) { fo.write(jb); }
            StringBuilder got = new StringBuilder(); int failed = 0;
            for (int i = 0; i < arr.length(); i++) {
                JSONObject e = arr.getJSONObject(i);
                String id = e.getString("id"), ver = e.optString("ver", "");
                if (!id.matches("[A-Za-z0-9_]+")) continue;
                File ips = new File(dir, id + ".ips");
                File verf = new File(dir, id + ".ver");
                if (ips.exists() && ver.equals(readSmall(verf))) continue;
                try {                                                 /* 하나 실패해도 나머지는 받는다 */
                    byte[] b = fetch(e.getString("url"), 30000);
                    if (b.length < 8 || b[0] != 'P' || b[1] != 'A' || b[2] != 'T' || b[3] != 'C' || b[4] != 'H') { failed++; continue; }
                    try (FileOutputStream fo = new FileOutputStream(ips)) { fo.write(b); }
                    writeSmall(verf, ver);
                    if (got.length() > 0) got.append(" · ");
                    got.append(e.optString("ko", id)).append(' ').append(ver);
                } catch (Exception ex) { failed++; }
            }
            if (got.length() > 0)
                toast(act, "조작 패치 새 판: " + got + " — 설정에서 켜고 게임을 다시 열면 적용됩니다");
            if (failed > 0) toast(act, "조작 패치 " + failed + "개는 못 받았습니다 — 다음 확인 때 다시 받습니다");
        } catch (Exception e) {
            toast(act, "조작 패치 확인 실패: " + e.getClass().getSimpleName());
        }
    }

    private static String readSmall(File f) {
        try (java.io.FileInputStream in = new java.io.FileInputStream(f)) {
            byte[] b = new byte[128];
            int n = in.read(b);
            return n > 0 ? new String(b, 0, n, "UTF-8").trim() : null;
        } catch (Exception e) { return null; }
    }

    private static void writeSmall(File f, String s) {
        try (FileOutputStream fo = new FileOutputStream(f)) {
            fo.write(s.getBytes("UTF-8"));
        } catch (Exception ignored) { }
    }

    private static byte[] fetch(String url, int timeoutMs) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setConnectTimeout(timeoutMs); c.setReadTimeout(timeoutMs);
        InputStream in = new BufferedInputStream(c.getInputStream());
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        byte[] buf = new byte[65536]; int n;
        while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
        in.close(); c.disconnect();
        return bo.toByteArray();
    }

    private static void toast(final Activity a, final String s) {
        a.runOnUiThread(new Runnable() { @Override public void run() {
            Toast.makeText(a, s, Toast.LENGTH_LONG).show(); }});
    }
}
