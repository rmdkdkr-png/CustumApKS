"""App-faithful headless harness for build 148 natives (league.c look.c vpanel.c practice.c cheat.c from w148/int @ c3de475).
Reproduces native.c nativeFrame order (native.c:917-952) and the input callback (native.c:375-382):
   mask = ovr_on ? ovr_mask : (user & ~(league_in_block|practice_in_block|look_in_block [| practice_opt_mask if START])) | league_in_or|practice_in_or|look_in_or
   c_fg_state -> synth? ; retro_run ; if !synth: league_vram, league_palremap_fn, league_tick_hub, look_tick(ctx=owns_select), practice_vram, practice_tick, cheat_tick, practice_take_exit
"""
import os, sys, ctypes as C
sys.path.insert(0, '/home/user/CustumApKS/handoff/ss2_league')
import ss2probe
S = '/tmp/claude-0/-home-user-CustumApKS/e6c46352-6bb9-5a9d-8b3a-f2da7447674e/scratchpad'
D = os.path.dirname(os.path.abspath(__file__))
CORE = os.environ.get('CORE', S + '/cicore/ci_pal.so')
HOST = os.environ.get('HOST', D + '/host148.so')
ROM = os.environ.get('ROM', S + '/prac1/mute/roms/ss2_ko_bundled_mute.ngc')
lg = C.CDLL(HOST)
VP = C.c_void_p
for n, a in {'league_tick_hub': [VP, C.c_size_t, C.c_int], 'league_vram': [VP, VP, VP], 'league_palremap_fn': [VP],
             'look_tick': [VP, C.c_size_t, C.c_int, C.c_int], 'practice_vram': [VP, VP, VP, VP], 'practice_tick': [VP, C.c_size_t, C.c_int],
             'cheat_tick': [VP, C.c_size_t, C.c_int], 'look_set_mem': [C.c_char_p, C.c_int], 'look_get_mem': [C.c_char_p, C.c_int],
             'look_set_custom': [C.c_int] * 5, 'look_triples': [C.c_int, C.c_int, VP], 'look_blob': [VP, C.c_size_t],
             'look_resume': [VP, C.c_size_t], 'league_hub': [VP, VP, VP], 'league_hub_look': [VP, C.c_int, C.c_int],
             'league_practice_resume': [VP, C.c_size_t]}.items():
    getattr(lg, n).argtypes = a
lg.league_hub.argtypes = [C.c_int, VP, VP]
lg.look_blob.restype = C.c_size_t
def gi(name): return C.c_int.in_dll(lg, name).value
BIT = {'A': 1 << 0, 'O': 1 << 3, 'U': 1 << 4, 'D': 1 << 5, 'L': 1 << 6, 'R': 1 << 7, 'B': 1 << 8}
def bits(s): return sum(BIT[c] for c in s)
def lst():
    v = (C.c_int * 14)(); lg.look_status(v); return list(v)
def hub():
    v = (C.c_int * 15)(); lg.league_hub_status(v); return list(v)
def lgs():
    v = (C.c_int * 22)(); lg.league_status(v); return list(v)
def triples(ch, sty):
    v = (C.c_int * 54)(); lg.look_triples(ch, sty, v); return [tuple(v[i * 3:i * 3 + 3]) for i in range(18)]
def set_mem(m): lg.look_set_mem(bytes((x & 0xFF) for x in m), len(m))
def mem():
    b = C.create_string_buffer(16); lg.look_get_mem(b, 16); return [x if x < 128 else x - 256 for x in b.raw]
GRID = [[3, 13, 8, 10, 2], [7, 4, 15, 5, 6], [12, 1, 9, 0, 11]]
def cell_of(cid):
    for r in range(3):
        for c in range(5):
            if GRID[r][c] == cid: return r, c
def move_seq(cur, target):
    r0, c0 = cell_of(cur); r1, c1 = cell_of(target)
    return ('D' if r1 > r0 else 'U') * abs(r1 - r0) + ('R' if c1 > c0 else 'L') * abs(c1 - c0)

class App:
    def __init__(self, wd, rom=ROM, runahead=os.environ.get('RA', '2').encode(), framegen=os.environ.get('FG', 'on').encode()):
        ss2probe.OPTIONS[b'ngp_runahead'] = runahead; ss2probe.OPTIONS[b'ngp_framegen'] = framegen
        self.p = ss2probe.Probe(CORE, rom, wd)
        L = self.p.lib
        for f in ('retro_ngp_charram', 'retro_ngp_scrollram', 'retro_ngp_palram', 'retro_ngp_spriteram'): getattr(L, f).restype = VP
        self.prf = C.cast(L.retro_ngp_palremap, VP).value
        self.chr = L.retro_ngp_charram(); self.scr = L.retro_ngp_scrollram(); self.pal = L.retro_ngp_palram(); self.spr = L.retro_ngp_spriteram()
        L.retro_ngp_fg_state.argtypes = [VP, VP, VP]
        self.user = 0; self.frames = 0; self.hooks = []; self.pre = []; self.synth = 0; self.look = True
    def run(self, n=1):
        L = self.p.lib
        for _ in range(n):
            on = gi('league_ovr_on')
            blk = gi('league_in_block') | gi('practice_in_block') | gi('look_in_block')
            if self.user & BIT['O']: blk |= gi('practice_opt_mask')
            orr = gi('league_in_or') | gi('practice_in_or') | gi('look_in_or')
            self.p.mask = gi('league_ovr_mask') if on else ((self.user & ~blk) | orr)
            fa, fp, ff = C.c_int(0), C.c_int(0), C.c_uint(0)
            L.retro_ngp_fg_state(C.byref(fa), C.byref(fp), C.byref(ff))
            synth = fa.value and fp.value == 1
            L.retro_run()
            self.frames += 1
            if synth: self.synth += 1; continue
            for h in self.pre: h(self)
            u = self.user
            ram, rs = self.p._ramp, self.p._rams
            lg.league_vram(self.chr, self.scr, self.pal); lg.league_palremap_fn(self.prf)
            lg.league_tick_hub(ram, rs, u)
            if self.look: lg.look_tick(ram, rs, u, 1 if lg.league_hub_owns_select() else 0)
            lg.practice_vram(self.chr, self.scr, self.pal, self.spr); lg.practice_tick(ram, rs, u)
            lg.cheat_tick(ram, rs, u)
            ex = lg.practice_take_exit()
            if ex:
                L.retro_reset(); lg.league_practice_return(1 if ex == 2 else 0); lg.practice_forget(); lg.look_forget(); lg.cheat_forget()
            for h in self.hooks: h(self)
    def press(self, s, frames=4, after=0):
        self.user = bits(s); self.run(frames); self.user = 0; self.run(after)
    def hold(self, s): self.user = bits(s)
    def peek(self, a): return self.p.peek(a)
    def pal3(self, k):
        b = C.string_at(self.pal + k * 8, 8); return tuple((b[2 + 2 * j] | (b[3 + 2 * j] << 8)) & 0xFFF for j in range(3))
    # Java-side emulation
    def java_load_session(self):
        """native.c load_locked (778) side effects at nativeLoad — everything off"""
        lg.league_disarm(); lg.league_hub(0, None, None); lg.practice_forget(); lg.league_practice_resume(None, 0)
        lg.look_enable(0); lg.look_forget(); lg.cheat_reset_all()
    def java_look_setup(self, m):
        """EmuActivity.lookSetup (2949): nativeLookEnable(ok) then Look.push (nativeLookSetMem + 28x nativeLookSetCustom)"""
        lg.look_enable(1); set_mem(m)
        for ch in range(14):
            for k in range(2): lg.look_set_custom(ch, k, -1, 0, 0)
    # state save/load like native.c nativeSaveState/nativeLoadState (1140-1190)
    def save_state(self):
        lg.league_hub_before_save(); lg.practice_before_save(); lg.look_before_save()
        L = self.p.lib; n = L.retro_serialize_size(); b = C.create_string_buffer(n); assert L.retro_serialize(b, n)
        side = C.create_string_buffer(64); ln = lg.look_blob(side, 64)
        return (b.raw, side.raw[:ln])
    def load_state(self, st):
        raw, side = st
        L = self.p.lib; b = C.create_string_buffer(raw, len(raw)); assert L.retro_unserialize(b, len(raw))
        return side

def boot_to_menu(a):
    a.run(420); a.press('A', 4, 150); a.run(10)
