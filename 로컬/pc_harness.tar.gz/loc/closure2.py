import os, re
S = '/tmp/claude-0/-home-user-CustumApKS/e6c46352-6bb9-5a9d-8b3a-f2da7447674e/scratchpad'
DIRS = ['u187', 'u182', 'u182r', 'u153/impl-nat', 'u153/nav/reg/nh', 'u149/quote/inc', 'u178/h/reg/u160x/h/nh', 'u181/h/reg/u160x/h/nh']
SKIPD = {'out', 'logs', 'build', 'reg_out', 'work', 'simbuild', 'ndkcore', 'ci_core', 'bin', 'base_src', '__pycache__', 'ndk', 'hb', 'ssimbuild', 'ndkapp', '.git', 'app', 'src'}
EXT = {'.sh', '.py', '.java', '.c', '.h', '.txt', '.md', '.json', '.patch', '.mk', '.csv', '.tsv', '.cfg', '.ini', '.inc', '.kt', ''}
NOEXP = re.compile(r'^(w\d+|refcore|core-|clkwrap)')
ref = re.compile(r'(?:\$S|\$\{S\}|' + re.escape(S) + r')/([A-Za-z0-9_.\-/]+)')
seen, files, extra = set(), [], set()
def scan(d):
    adds = set()
    for root, ds, fs in os.walk(os.path.join(S, d), followlinks=False):
        ds[:] = [x for x in ds if x not in SKIPD and not x.startswith(('state', 'out'))]
        for f in fs:
            p = os.path.join(root, f); rp = os.path.relpath(p, S)
            if rp in seen or os.path.islink(p) or os.path.splitext(f)[1] not in EXT or os.path.getsize(p) > 1_000_000: continue
            seen.add(rp)
            try: t = open(p, encoding='utf-8').read()
            except Exception: continue
            files.append(rp)
            for m in ref.findall(t):
                r = m.rstrip('/.'); q = os.path.join(S, r)
                if os.path.isfile(q) and not r.split('/')[-1].endswith(('.ngc', '.wav', '.png')): extra.add(r)
                parts = r.split('/')
                for k in range(min(len(parts), 3), 0, -1):
                    c = '/'.join(parts[:k])
                    if os.path.isdir(os.path.join(S, c)) and not NOEXP.match(parts[0]) and not any(x in SKIPD for x in parts[:k]):
                        adds.add(c); break
    return adds
todo, done = list(DIRS), set()
while todo:
    d = todo.pop()
    if d in done or any(d.startswith(x + '/') for x in done): continue
    done.add(d)
    for a in scan(d):
        if a not in done and not any(a.startswith(x + '/') for x in done): todo.append(a)
allf = sorted(set(files) | {e for e in extra if not os.path.islink(os.path.join(S, e))})
open(S + '/loc/files2.txt', 'w').write('\n'.join(allf) + '\n')
print('dirs', len(done), 'files', len(allf), 'MB', round(sum(os.path.getsize(os.path.join(S, f)) for f in allf) / 1e6, 1))
big = sorted(((os.path.getsize(os.path.join(S, f)), f) for f in allf if not f.endswith(('.py','.sh','.java','.c','.h','.txt','.md','.json','.patch'))), reverse=True)[:12]
for s, f in big: print(s, f)
print(' '.join(sorted(done))[:3000])
