package com.dudu.pocketcore;

import java.nio.ByteBuffer;

/** Thin JNI surface. Everything real happens in native.c. */
public final class Emu {
    static { System.loadLibrary("pocketcore"); }

    // libretro joypad bit positions
    public static final int B = 0, Y = 1, SELECT = 2, START = 3,
            UP = 4, DOWN = 5, LEFT = 6, RIGHT = 7, A = 8, X = 9, L = 10, R = 11;

    public static native int  nativeLoad(String corePath, String romPath,
                                         String sysDir, String saveDir, String optionsFile);
    public static native void nativeUnload();
    public static native void nativeSurfaceCreated();
    public static native void nativeResize(int w, int h);
    public static native void nativeFrame();
    public static native void nativeSetInput(int mask);
    public static native void nativeReset();
    public static native void nativeSetOption(String key, String value);
    public static native void nativeSetIntegerScale(boolean on);
    public static native void nativeSetTurbo(boolean on);
    /** 화면 표시 — up: 0 끔 · 1 샤프 · 2 Scale2x · 3 xBR · 4 OmniScale (Settings.UPSCALERS 순서), 나머지 세기 0..100.
     *  GL 스레드에서 부를 것(queueEvent). */
    public static native void nativeSetDisplay(int up, int mix, int grid, int scan, int ghost, int color, int soft, boolean integer);
    public static native int  nativeSaveState(String path);
    public static native int  nativeLoadState(String path);
    public static native int  nativeFrameWidth();
    public static native int  nativeFrameHeight();
    public static native ByteBuffer nativeFrameBuffer();
    public static native void nativeSaveSram();
    public static native void nativeAudioPause();   /* 백그라운드 — 오디오 장치를 놓는다 */
    public static native void nativeAudioResume();  /* 복귀 — 새 스트림으로 다시 연다 */
    public static native void nativeRunFrames(int n); /* GL 없이 n프레임 — 썸네일 캡처용 */
    /* 프레임 생성(중간 프레임 보간) — 0=끔 1=섞기 2=움직임 보정. 120Hz 같은 빠른 화면에서만 실제로 끼운다 */
    public static native void nativeSetFrameGen(int mode);
    /** 실측 전 대용 패널 주사율(Display.getRefreshRate) — 코어의 GET_TARGET_REFRESH_RATE 답에 쓴다. */
    public static native void nativeSetPanelHz(float hz);
    /** 코어 멈춤 — 게임 안 「설정」 창이 떠 있는 동안. 그림은 마지막 것을 계속 그린다. */
    public static native void nativeSetPaused(boolean on);
    /** 지금 끼우고 있으면 화면 Hz, 화면이 느려 못 끼우면 0, 아직 모르면 -1. */
    public static native int  nativeFrameGenActive();
    /** 실측 패널 주사율(60/90/120…) — 상태 토스트용. */
    public static native float  nativePanelHz();
    /** 코어가 지금 선언한 fps — 사무쇼2 코어가 프레임 생성을 켜면 120.5. */
    public static native double nativeCoreFps();

    /* 가상 리그 랭크전(league.c) — 진짜 프레임마다 대진 덮어쓰기·결판 감지.
       arm: 상대 캐릭터 id(0~14)·유파(0/1)·난도(0~2, 음수=그대로)·포인트·시간(0=그대로)·LEAGUE_* 플래그 */
    public static final int LEAGUE_CARDS_OFF = 1, LEAGUE_ALLCARDS = 2, LEAGUE_AUTONAV = 4, LEAGUE_FROM_CKPT = 8;
    public static native void  nativeLeagueArm(int opp, int style, int diff, int points, int time, int flags);
    public static native void  nativeLeagueDisarm();
    /** [무장, 프레임, bit7 0 봄, 경기 시작 봄, 결과 잡음, 결과 비트, 승수1, 승수2, KO, 실효 포인트,
     *   P1 블록, P2 블록(결판), P2 블록(경기 시작), 경기 시작 프레임, 결판 프레임, 사용자 카드 1, 2, 실효 시간,
     *   CPU 단계(0x5814), CPU 공격 배율, CPU 받는 피해 배율] */
    public static native int[] nativeLeagueStatus();
    /* 게임 속 리그(허브): 타이틀 «2인 대전» 자리 = «리그 대전». sty/dif = 캐릭터 id(0~14)별 리그 상대의 검질(없으면 −1)·난도 */
    public static native void  nativeLeagueHub(boolean on, byte[] sty, byte[] dif);
    public static native void  nativeLeagueHubCancel();
    /** 게임 속 리그 배경·컬러 — home[캐릭터] = 그 상대 기본 배경(0~7·−1), stageSel −1 상대 기본·−2 무작위·0~7, color 0~3 */
    public static native void nativeLeagueHubLook(byte[] home, int stageSel, int color);
    /** 다음 nativeLeagueArm 의 배경(0~7, −1 게임 그대로)·내 컬러(0~3) */
    public static native void nativeLeagueLook(int stage, int color);
    /** [상태 0 꺼짐·1 타이틀·2 상대 고르기·3 내 캐릭터·4 경기·5 타이틀로, 커서 캐릭터(−1 무작위), 고른 상대 캐릭터, 프레임, 메뉴 글자, 머리말 글자, 재대결, 대신 누르기] */
    public static native int[] nativeLeagueHubStatus();
    /** 결판 뒤: 리셋하고 타이틀 «리그 대전»까지(rematch = 바로 다시 붙을 상대 캐릭터, −1 없음) */
    public static native void  nativeLeagueHubReturn(int rematch);
}
