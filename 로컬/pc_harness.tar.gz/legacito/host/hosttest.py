"""league.c 를 실제 코어 옆에서 돌리는 호스트 하네스 — 앱의 nativeFrame 과 같은 자리(retro_run 뒤)에서 league_tick 을 부른다."""
import sys, ctypes as C, ss2probe
H='/tmp/claude-0/-home-user-CustumApKS/e6c46352-6bb9-5a9d-8b3a-f2da7447674e/scratchpad/legacito/host'
CORE='/home/user/ss2-sp-core/cores/mednafen_ngp_libretro.linux-x86_64.so'
lg=C.CDLL(H+'/libleague_host.so')
lg.league_tick.argtypes=[C.c_void_p, C.c_size_t]
def status():
    v=(C.c_int*21)(); lg.league_status(v); return list(v)
class Harness:
    def __init__(self, rom, wd, runahead=True):
        if runahead:
            ss2probe.OPTIONS[b'ngp_runahead']=b'2'; ss2probe.OPTIONS[b'ngp_framegen']=b'on'
        self.p=ss2probe.Probe(CORE, rom, wd)
        self.user = 0
    def run(self, n=1):
        for _ in range(n):
            on = C.c_int.in_dll(lg, 'league_ovr_on').value
            self.p.mask = C.c_int.in_dll(lg, 'league_ovr_mask').value if on else self.user
            self.p.run(1); lg.league_tick(self.p._ramp, self.p._rams)
    def press(self, b, frames=6, after=0):
        self.p.mask = 0; self.p.hold(*b); self.user = self.p.mask; self.run(frames); self.user = 0; self.run(after)
