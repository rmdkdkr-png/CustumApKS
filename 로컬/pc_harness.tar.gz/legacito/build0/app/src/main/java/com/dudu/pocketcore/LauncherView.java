package com.dudu.pocketcore;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.View;

import java.io.File;
import java.util.List;

/**
 * 레트로 런처 v2.
 *
 * v1 사고 둘의 수리(제보):
 *  · 「글자 크기 말같지도 않게」 — 크기 계산 실수(h 의 20%짜리 글자). 전부 제정신
 *    비율로 다시 (제목 3.0%, 배지 2.0%, 힌트 1.6%).
 *  · 「오버레이 해상도 원래 저 정도냐」 — 썸네일을 중간 캔버스(66px 칸)로 **줄였다가**
 *    다시 튀겨서 지글거렸다. 중간 캔버스를 없애고 원본(160x152)을 **정수배(3~4배)로
 *    직행** blit — 무필터라 픽셀은 그대로, 해상도는 원본 그대로.
 *
 * 부팅 연출: 스마일 볼(자작 도트)이 굴러 들어와 로고 자리에 안착하면 목록이 떠오른다 —
 * 실기 네오지오 포켓 부트 오마주. 부팅음(0.57초)과 박자를 맞췄다.
 */
public final class LauncherView extends View {

    public static final class Item {
        public final File rom;
        public String title;
        public String sub = "";
        public Bitmap thumb;
        public boolean pat, sp, dub;
        public String opt = "";           /* 실행 옵션 한 줄(LaunchSheet.summary) — 카드 아래 칩 */
        public boolean resume;            /* 오토세이브가 있다 — A 아래 글이 「이어하기」 */
        public Item(File rom, String title) { this.rom = rom; this.title = title; }
    }

    public interface Listener {
        void onLaunch(File rom);
        void onOptions(File rom);         /* 카드 아래 옵션 칩 — 실행 전 선택창 */
        void onSettings();
        void onUpdate();
    }

    private final Paint px = new Paint();   /* 픽셀 그림 — 필터·AA 끔 */
    private final Paint tp = new Paint();   /* 글자 — AA 켬 */
    private final Rect srcR = new Rect(), dstR = new Rect();

    private List<Item> items;
    private int sel = 0;
    private Listener listener;
    private float downX = -1;
    /* 배포 레벨 배지 — 시험 판을 쓰는 동안 늘 보이게(유저 2026-09-04 「구분 잘 될지 모르겠다」).
       정식이면 null 이라 아무것도 안 그린다 — 보통 사람 화면은 그대로. */
    private String channel;
    public void setChannel(String s) { channel = s; invalidate(); }
    private long introAt = 0;               /* 부팅 연출 시작 시각 (0 = 안 함) */
    private static final long INTRO_MS = 950;

    /* ── 첨화면 아트: 「포켓 진열장」 ──
       위쪽 하늘엔 도트 별밭(정적 — 좌표는 해시로 고정), 화면 전체엔 진열 조명 비네트,
       포커스 카드 밑엔 선반 잔광 두 줄. 실기 부트 화면의 「밤하늘에 기기 하나」 감성. */
    private Paint vigP; private int vigW, vigH;   /* 비네트는 크기 바뀔 때만 다시 만든다 */

    private Paint vignette(float w, float h) {
        if (vigP == null || vigW != (int) w || vigH != (int) h) {
            vigP = new Paint();
            vigP.setShader(new android.graphics.RadialGradient(
                    w * 0.5f, h * 0.34f, Math.max(w, h) * 0.72f,
                    new int[]{ 0xff15151d, 0xff0e0e12, 0xff09090c },
                    new float[]{ 0f, 0.55f, 1f },
                    android.graphics.Shader.TileMode.CLAMP));
            vigW = (int) w; vigH = (int) h;
        }
        return vigP;
    }

    private void drawBackdrop(Canvas c, float w, float h, float introT) {
        c.drawRect(0, 0, w, h, vignette(w, h));
        /* 도트 별 — 의사난수(정수 해시)로 좌표·크기·밝기를 고정. 매 프레임 같은 하늘. */
        float d = Math.max(1f, w / 360f);             /* 도트 한 알의 화면 크기 */
        int fade = (int) (255 * Math.min(1f, introT * 1.6f));
        for (int i = 0; i < 34; i++) {
            int hsh = i * 0x9E3779B1;
            float sx2 = ((hsh >>> 8) % 1000) / 1000f * w;
            float sy2 = ((hsh >>> 18) % 560) / 1000f * h;   /* 위 56% 에만 */
            int tier = (hsh >>> 4) & 3;                      /* 0~3 밝기 층 */
            int a = (18 + tier * 14) * fade / 255;
            px.setColor((a << 24) | (tier == 3 ? 0xd9cba4 : 0x9aa0b8));
            float s2 = d * (tier == 3 ? 2f : 1f);
            c.drawRect(sx2, sy2, sx2 + s2, sy2 + s2, px);
        }
    }

    /* 런처 버튼도 게임 안 터치 패드와 같은 아트(PadSkin)로 — 설정 「버튼 모양」을 따른다(유저 2026-10-10 「버튼이나 전반적 인터페이스 좀 손봐 줘」) */
    private final PadSkin skin = new PadSkin();
    private boolean art = true;

    public LauncherView(Context c) {
        super(c);
        px.setAntiAlias(false);
        px.setFilterBitmap(false);
        tp.setAntiAlias(true);
        setBackgroundColor(0xff0b0b0e);
        try { art = !"flat".equals(Settings.load().get("pocketcore_padskin")); } catch (Exception ignored) { }
        if (art) skin.reloadUser();
    }
    @Override protected void onSizeChanged(int w, int h, int ow, int oh) { skin.clear(); }

    public void setItems(List<Item> it) { items = it; sel = 0; invalidate(); }
    /** 처음 보여 줄 카드(마지막에 한 게임) — 넘기는 손맛(진동)은 없이 */
    public void select(int i) { if (items != null && i >= 0 && i < items.size()) { sel = i; invalidate(); } }
    public void setListener(Listener l) { listener = l; }
    public void startIntro() { introAt = System.currentTimeMillis(); invalidate(); }
    public void thumbReady() { postInvalidate(); }
    /** 물리 패드용 — 카드 이동 / 지금 고른 카드 (없으면 null). */
    public void moveSel(int d) { if (items != null) move(d); }
    public Item selected() { return (items == null || items.isEmpty()) ? null : items.get(sel); }

    /* ── 그리기 ─────────────────────────────────────────────────── */

    @Override protected void onDraw(Canvas cv) {
        float w = getWidth(), h = getHeight();
        float t = 1f;
        if (introAt > 0) {
            t = (System.currentTimeMillis() - introAt) / (float) INTRO_MS;
            if (t >= 1f) { t = 1f; introAt = 0; }
            else postInvalidateOnAnimation();
        }
        drawBackdrop(cv, w, h, introAt > 0 ? t : 1f);

        /* 로고 — 좌상단. 인트로 중에는 스마일 볼이 굴러와 심볼 자리에 안착한다 */
        Bitmap logo = Logo.get(getContext());
        float lx = w * 0.06f, ly = h * 0.025f;
        int ls = Math.max(2, (int) (w / 160f));           /* 로고 배율 */
        float logoH = (logo != null ? logo.getHeight() : 12) * ls;
        if (logo != null && t >= 1f) {
            srcR.set(0, 0, logo.getWidth(), logo.getHeight());
            dstR.set((int) lx, (int) ly, (int) (lx + logo.getWidth() * ls), (int) (ly + logoH));
            cv.drawBitmap(logo, srcR, dstR, px);
        } else if (logo != null) {
            /* 워드마크는 심볼 자리(왼쪽 12px)를 비우고 먼저 — 볼이 거기로 들어간다 */
            int cut = 14 * ls;
            srcR.set(14, 0, logo.getWidth(), logo.getHeight());
            dstR.set((int) lx + cut, (int) ly,
                     (int) (lx + logo.getWidth() * ls), (int) (ly + logoH));
            int a = (int) (255 * Math.min(1f, t * 2f));
            px.setAlpha(a);
            cv.drawBitmap(logo, srcR, dstR, px);
            px.setAlpha(255);
        }
        if (introAt > 0) {                                 /* 스마일 볼 굴리기 */
            float r = logoH * 0.55f;
            /* 잔상 — 조금 전 위치에 흐린 볼을 겹쳐 「구른다」가 눈에 남게 */
            for (int k = 3; k >= 1; k--) {
                float tk = t - k * 0.055f;
                if (tk <= 0) continue;
                float pk = Math.min(1f, tk / 0.75f);
                float ek = 1 - (1 - pk) * (1 - pk);
                float sxk = -2 * r + (lx + 6 * ls + 2 * r) * ek;
                float syk = ly + logoH * 0.5f
                          + (tk > 0.75f ? 0 : (h * 0.015f) * (float) Math.abs(Math.sin(tk * 18)));
                tp.setColor(((36 - k * 9) << 24) | 0x00d9a441);
                cv.drawCircle(sxk, syk, r * (1 - k * 0.10f), tp);
            }
            float p2 = Math.min(1f, t / 0.75f);
            float e = 1 - (1 - p2) * (1 - p2);             /* ease-out */
            float sx = -2 * r + (lx + 6 * ls + 2 * r) * e; /* 왼쪽 밖 → 심볼 자리 */
            float sy = ly + logoH * 0.5f
                     + (t > 0.75f ? 0 : (h * 0.015f) * (float) Math.abs(Math.sin(t * 18)));
            drawSmile(cv, sx, sy, r, t * 720f);
            /* 안착 — 링 파동 + 스파클 넷. 부팅음 마지막 박에 맞춘 「철컥」 */
            if (t > 0.78f) {
                float q = (t - 0.78f) / 0.22f;
                float cx2 = lx + 6 * ls, cy3 = ly + logoH * 0.5f;
                tp.setStyle(Paint.Style.STROKE);
                tp.setStrokeWidth(Math.max(2f, r * 0.10f * (1 - q)));
                tp.setColor(((int) (150 * (1 - q)) << 24) | 0x00d9a441);
                cv.drawCircle(cx2, cy3, r * (1.05f + q * 2.4f), tp);
                tp.setStyle(Paint.Style.FILL);
                int sa = (int) (220 * (1 - q));
                tp.setColor((sa << 24) | 0x00ffe9b0);
                float sd = r * (1.25f + q * 1.6f), ss = Math.max(2f, r * 0.10f);
                cv.drawRect(cx2 - sd - ss, cy3 - ss, cx2 - sd + ss, cy3 + ss, tp);
                cv.drawRect(cx2 + sd - ss, cy3 - ss, cx2 + sd + ss, cy3 + ss, tp);
                cv.drawRect(cx2 - ss, cy3 - sd - ss, cx2 + ss, cy3 - sd + ss, tp);
                cv.drawRect(cx2 - ss, cy3 + sd - ss, cx2 + ss, cy3 + sd + ss, tp);
            }
        }

        if (channel != null) {          /* 로고 오른쪽 — 「시험 v3.77」 호박색 테두리 알약 */
            tp.setTextAlign(Paint.Align.LEFT);
            tp.setTextSize(h * 0.016f);
            float tw3 = tp.measureText(channel), padx = h * 0.008f, bh3 = h * 0.026f;
            float bx3 = lx + h * 0.001f, by3 = ly + logoH + h * 0.008f;
            RectF pill = new RectF(bx3, by3, bx3 + tw3 + padx * 2, by3 + bh3);
            tp.setStyle(Paint.Style.FILL);
            tp.setColor(0x33d9a441);
            cv.drawRoundRect(pill, bh3 * 0.5f, bh3 * 0.5f, tp);
            tp.setStyle(Paint.Style.STROKE);
            tp.setStrokeWidth(Math.max(1f, h * 0.0012f));
            tp.setColor(0xccd9a441);
            cv.drawRoundRect(pill, bh3 * 0.5f, bh3 * 0.5f, tp);
            tp.setStyle(Paint.Style.FILL);
            tp.setColor(0xffe8c477);
            cv.drawText(channel, bx3 + padx, by3 + bh3 * 0.72f, tp);
        }

        int n = (items == null) ? 0 : items.size();
        float listA = introAt > 0 ? Math.max(0f, (t - 0.55f) / 0.45f) : 1f;
        int la = (int) (255 * listA);

        /* ── 카드 — 원본을 정수배로 직행. 중앙 3~4배, 양옆은 그 절반 ── */
        float top = ly + logoH + h * 0.02f;
        float availH = h * 0.40f;
        int cs = Math.max(2, Math.min((int) (w * 0.52f) / 160, (int) availH / 152));
        int ss2 = Math.max(1, cs / 2);
        float cy2 = top + (availH - 152 * cs) / 2f + 152 * cs / 2f;   /* 중앙 카드 세로중심 */

        if (n == 0) {
            tp.setColor(0xffbbbbbb);
            tp.setTextSize(h * 0.022f);
            tp.setTextAlign(Paint.Align.CENTER);
            cv.drawText("PocketCore/roms 에 롬을 넣으세요", w / 2, top + availH / 2, tp);
        } else {
            if (n > 1) {
                drawCard(cv, items.get((sel + n - 1) % n), w * 0.13f, cy2, ss2, false, la);
                drawCard(cv, items.get((sel + 1) % n),      w * 0.87f, cy2, ss2, false, la);
            }
            drawCard(cv, items.get(sel), w * 0.5f, cy2, cs, true, la);

            /* ── 글자 — 제정신 크기(뷰 높이 비율) ── */
            Item cur = items.get(sel);
            tp.setTextAlign(Paint.Align.CENTER);
            tp.setColor(withA(0xffffffff, la));
            tp.setTextSize(h * 0.030f);
            tp.setFakeBoldText(true);
            float ty = top + availH + h * 0.045f;
            cv.drawText(cur.title, w / 2, ty, tp);
            tp.setFakeBoldText(false);

            /* 배지 */
            tp.setTextSize(h * 0.018f);
            String[] lb = new String[3];
            int[] bc = new int[3];
            int bn = 0;
            if (cur.pat) { lb[bn] = "한패"; bc[bn++] = 0xff2e7d32; }
            if (cur.sp)  { lb[bn] = "SP";   bc[bn++] = 0xffb26500; }
            float padX = h * 0.010f, gap = h * 0.008f, bh = h * 0.028f;
            float bw = 0;
            for (int i = 0; i < bn; i++) bw += tp.measureText(lb[i]) + padX * 2 + (i > 0 ? gap : 0);
            float bx2 = (w - bw) / 2;
            float byTop = ty + h * 0.015f;
            for (int i = 0; i < bn; i++) {
                float tw2 = tp.measureText(lb[i]);
                tp.setColor(withA(bc[i], la));
                cv.drawRoundRect(new RectF(bx2, byTop, bx2 + tw2 + padX * 2, byTop + bh),
                        bh * 0.3f, bh * 0.3f, tp);
                tp.setColor(withA(0xffffffff, la));
                cv.drawText(lb[i], bx2 + padX + tw2 / 2, byTop + bh * 0.72f, tp);
                bx2 += tw2 + padX * 2 + gap;
            }
            float ly2 = byTop + bh + h * 0.028f;
            if (!cur.sub.isEmpty()) {
                tp.setColor(withA(0xff9999aa, la));
                tp.setTextSize(h * 0.017f);
                cv.drawText(cur.sub, w / 2, ly2, tp);
                ly2 += h * 0.022f;
            }
            {   /* 롬 파일명 — 같은 게임 롬이 여럿(J/UE/[h1]/패치본)이면 이름만으론 못 가른다(유저 2026-09-05) */
                String fn = cur.rom.getName(); int dot = fn.lastIndexOf('.'); if (dot > 0) fn = fn.substring(0, dot);
                tp.setColor(withA(0xff6b7388, la));
                tp.setTextSize(h * 0.015f);
                while (fn.length() > 8 && tp.measureText(fn) > w * 0.9f) fn = fn.substring(0, fn.length() - 2);   /* 너무 길면 자른다 */
                cv.drawText(fn, w / 2, ly2, tp);
            }
            {   /* 실행 옵션 칩 — 무엇으로 켜질지 늘 보이고, 누르면 바꾸는 창(실행 전 선택창). 카드·A 는 바로 시작(2026-10-11) */
                String ot = (cur.opt == null || cur.opt.isEmpty()) ? "실행 옵션" : cur.opt;
                String tail = "  옵션 \u203a";
                float ts = h * 0.017f;
                tp.setTextSize(ts);
                float lim = w * 0.86f;
                while (ot.length() > 4 && tp.measureText(ot + tail) > lim) {          /* 넘치면 뒤 항목부터 줄임 */
                    int cut = ot.lastIndexOf(" · ");
                    ot = cut > 0 ? ot.substring(0, cut) + " …" : ot.substring(0, ot.length() - 2);
                    if (ot.endsWith(" … …")) ot = ot.substring(0, ot.length() - 2);
                }
                float cw = tp.measureText(ot + tail) + ts * 1.6f, ch = ts * 2.1f;
                float cyTop = ly2 + h * 0.020f;
                optChip.set(w / 2 - cw / 2, cyTop, w / 2 + cw / 2, cyTop + ch);
                tp.setColor(withA(0xff191b22, la));
                cv.drawRoundRect(optChip, ch / 2, ch / 2, tp);
                tp.setStyle(Paint.Style.STROKE); tp.setStrokeWidth(Math.max(1.5f, h * 0.0015f));
                tp.setColor(withA(0xff4a3d22, la));
                cv.drawRoundRect(optChip, ch / 2, ch / 2, tp);
                tp.setStyle(Paint.Style.FILL);
                float tx0 = optChip.centerX() - tp.measureText(ot + tail) / 2, by = optChip.centerY() + ts * 0.36f;
                tp.setTextAlign(Paint.Align.LEFT);
                tp.setColor(withA(0xffc9cfdb, la));
                cv.drawText(ot, tx0, by, tp);
                tp.setColor(withA(0xffd9a441, la));
                cv.drawText(tail, tx0 + tp.measureText(ot), by, tp);
                tp.setTextAlign(Paint.Align.CENTER);
                String log = optChip.toShortString();
                if (!log.equals(lastChipLog)) { lastChipLog = log; android.util.Log.i("PocketUi", "optchip " + Math.round(optChip.centerX()) + " " + Math.round(optChip.centerY())); }
            }
            tp.setColor(withA(0xff777788, la));
            tp.setTextSize(h * 0.015f);
            cv.drawText((sel + 1) + " / " + n, w * 0.5f, top - h * 0.006f, tp);
        }
        drawPad(cv);
    }

    private static int withA(int col, int a) {
        return (col & 0x00ffffff) | (Math.min(255, a) << 24);
    }

    /** 스마일 볼 — 자작 도트 감성(원 + 눈 2 + 웃는 입), 굴러가는 회전. */
    private void drawSmile(Canvas c, float x, float y, float r, float rot) {
        c.save();
        c.rotate(rot, x, y);
        tp.setColor(0xffd9a441);
        c.drawCircle(x, y, r, tp);
        tp.setColor(0xff1a1a20);
        float er = r * 0.13f;
        c.drawCircle(x - r * 0.32f, y - r * 0.22f, er, tp);
        c.drawCircle(x + r * 0.32f, y - r * 0.22f, er, tp);
        RectF m = new RectF(x - r * 0.45f, y - r * 0.15f, x + r * 0.45f, y + r * 0.55f);
        tp.setStyle(Paint.Style.STROKE);
        tp.setStrokeWidth(r * 0.14f);
        c.drawArc(m, 20, 140, false, tp);
        tp.setStyle(Paint.Style.FILL);
        c.restore();
    }

    /** 카드 — 원본 비트맵을 정수배 blit. cx=가로중심, cy=세로중심. */
    private void drawCard(Canvas c, Item it, float cx, float cy, int scale,
                          boolean focus, int alpha) {
        int bw = 160, bh = 152;
        if (it.thumb != null) { bw = it.thumb.getWidth(); bh = it.thumb.getHeight(); }
        int dw = bw * scale, dh = bh * scale;
        int l = (int) (cx - dw / 2f), t2 = (int) (cy - dh / 2f);
        px.setStyle(Paint.Style.FILL);
        px.setColor(withA(focus ? 0xff000000 : 0xff0a0a0d, alpha));
        c.drawRect(l - 4, t2 - 4, l + dw + 4, t2 + dh + 4, px);
        if (it.thumb != null) {
            srcR.set(0, 0, bw, bh);
            dstR.set(l, t2, l + dw, t2 + dh);
            px.setAlpha(focus ? alpha : alpha * 120 / 255);
            c.drawBitmap(it.thumb, srcR, dstR, px);
            px.setAlpha(255);
        } else {
            tp.setColor(withA(focus ? 0xffcccccc : 0xff555566, alpha));
            tp.setTextSize(getHeight() * 0.018f);
            tp.setTextAlign(Paint.Align.CENTER);
            c.drawText(it.title, cx, cy, tp);
        }
        px.setStyle(Paint.Style.STROKE);
        px.setStrokeWidth(Math.max(2, scale));
        px.setColor(withA(focus ? 0xffd9a441 : 0xff33333d, alpha));
        c.drawRect(l - 4, t2 - 4, l + dw + 4, t2 + dh + 4, px);
        px.setStyle(Paint.Style.FILL);
        px.setStrokeWidth(1);
        if (focus) {                       /* 선반 잔광 — 진열장 유리에 비친 골드 */
            px.setColor(withA(0xffd9a441, alpha * 0x2e / 255));
            c.drawRect(l - 4, t2 + dh + 9, l + dw + 4, t2 + dh + 11, px);
            px.setColor(withA(0xffd9a441, alpha * 0x14 / 255));
            c.drawRect(l + dw / 6f, t2 + dh + 14, l + dw - dw / 6f, t2 + dh + 15, px);
        }
    }

    /* ── 패드식 컨트롤 — A(실행)=안쪽 아래 · B(업뎃)=바깥 위 ── */
    private float dcx, dcy, dR, aX, aY, aR, bX, bY, bR;
    private final RectF optR = new RectF();
    private final RectF optChip = new RectF();      /* 카드 아래 실행 옵션 칩 */
    private String lastChipLog = "";

    /* 런처 패드 — 십자(카드 넘기기) + A(실행)만. B(업뎃)·OPTION(설정)은 아래 줄 「설정 · 업데이트 확인」과 같은 일을 해서
       뺐다(유저 2026-10-10 「뺄 거 빼고」). 버튼 모양은 게임 안 터치 패드와 같은 아트(설정 「버튼 모양」). */
    private void drawPad(Canvas c) {
        float w = getWidth(), h = getHeight(), mn = Math.min(w, h);
        dcx = w * 0.22f; dcy = h * 0.80f; dR = mn * 0.13f;
        aX = w * 0.78f; aY = h * 0.80f; aR = mn * 0.075f;
        bR = 0; optR.setEmpty();
        if (art) {
            skin.dpad(c, dcx, dcy, dR, 0);
            skin.button(c, "a", aX, aY, aR, 0xff3f6fd1, false, false, "A");
        } else {
            float arm = dR * 0.42f;
            tp.setStyle(Paint.Style.FILL);
            tp.setColor(0x22ffffff);
            c.drawRect(dcx - arm, dcy - dR, dcx + arm, dcy - arm, tp);
            c.drawRect(dcx - arm, dcy + arm, dcx + arm, dcy + dR, tp);
            tp.setColor(0x3cffffff);
            c.drawRect(dcx - dR, dcy - arm, dcx - arm, dcy + arm, tp);
            c.drawRect(dcx + arm, dcy - arm, dcx + dR, dcy + arm, tp);
            tp.setColor(0x22ffffff);
            c.drawRect(dcx - arm, dcy - arm, dcx + arm, dcy + arm, tp);
            tp.setColor(0x38ffffff);
            c.drawCircle(aX, aY, aR, tp);
            tp.setColor(0xffdddddd);
            tp.setTextAlign(Paint.Align.CENTER);
            tp.setTextSize(aR * 0.7f);
            c.drawText("A", aX, aY + aR * 0.25f, tp);
        }
        tp.setStyle(Paint.Style.FILL);
        tp.setTextAlign(Paint.Align.CENTER);
        tp.setTextSize(mn * 0.026f);
        tp.setColor(0x99ffffff);
        Item cur = (items == null || items.isEmpty()) ? null : items.get(sel);
        c.drawText(cur != null && cur.resume ? "이어하기" : "시작", aX, aY + aR + aR * 0.62f, tp);
        tp.setTextAlign(Paint.Align.LEFT);
    }

    private static float dist(float x, float y, float cx2, float cy2) {
        float dx = x - cx2, dy = y - cy2;
        return (float) Math.sqrt(dx * dx + dy * dy);
    }

    /* ── 입력 ───────────────────────────────────────────────────── */

    @Override public boolean onTouchEvent(MotionEvent e) {
        if (items == null) return true;
        float x = e.getX(), y = e.getY(), h = getHeight();
        switch (e.getActionMasked()) {
        case MotionEvent.ACTION_DOWN:
            if (dist(x, y, dcx, dcy) < dR * 1.35f) {
                if (x < dcx - dR * 0.2f) move(-1);
                else if (x > dcx + dR * 0.2f) move(1);
                downX = -1;
                return true;
            }
            if (!items.isEmpty() && dist(x, y, aX, aY) < aR * 1.35f) {
                if (listener != null) listener.onLaunch(items.get(sel).rom);
                downX = -1;
                return true;
            }
            if (bR > 0 && dist(x, y, bX, bY) < bR * 1.35f) {
                if (listener != null) listener.onUpdate();
                downX = -1;
                return true;
            }
            if (optR.contains(x, y)) {
                if (listener != null) listener.onSettings();
                downX = -1;
                return true;
            }
            if (!items.isEmpty() && !optChip.isEmpty() && optChip.contains(x, y)) {
                if (listener != null) listener.onOptions(items.get(sel).rom);
                downX = -1;
                return true;
            }
            downX = x;
            return true;
        case MotionEvent.ACTION_UP:
            if (downX < 0 || items.isEmpty()) return true;
            float dx = x - downX;
            if (Math.abs(dx) > getWidth() / 8f) {
                move(dx < 0 ? 1 : -1);
            } else if (y < h * 0.55f) {
                float fx2 = x / getWidth();
                if (fx2 < 0.33f) move(-1);
                else if (fx2 > 0.67f) move(1);
                else if (listener != null) listener.onLaunch(items.get(sel).rom);
            }
            return true;
        }
        return true;
    }

    private void move(int d) {
        int n = items.size();
        if (n == 0) return;
        sel = (sel + d % n + n) % n;
        android.util.Log.i("PocketUi", "sel " + (sel + 1) + " / " + n);     /* ui_shots 가 카드가 넘어갔는지 본다(캔버스라 노드가 없다) */
        performHapticFeedback(android.view.HapticFeedbackConstants.KEYBOARD_TAP);
        invalidate();
    }
}
