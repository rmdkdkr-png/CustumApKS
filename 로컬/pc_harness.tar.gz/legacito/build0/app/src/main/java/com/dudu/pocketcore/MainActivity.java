package com.dudu.pocketcore;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.Settings;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * No settings screen, no core downloader, no menu tree.
 * Boot -> last ROM resumes immediately. Only when there is no last ROM
 * does a flat file list appear.
 */
public class MainActivity extends Activity {

    public static final String ROOT = "PocketCore";
    private static final String PREFS = "pc";
    private static final String KEY_LAST = "lastRom";
    /* 마지막에 한 게임 — 목록(런처)을 열 때 그 카드를 먼저 보여 준다(유저 2026-10-11 「처음에 게임 선택창 이전에 한 게임 기억했다가 뜨도록」).
       KEY_LAST 는 「목록」·「종료」 때 지워지므로(다음 실행 때 게임으로 바로 들어가지 않게) 따로 둔다. */
    private static final String KEY_PLAYED = "lastPlayed";

    public static File root()    { return new File(Environment.getExternalStorageDirectory(), ROOT); }
    public static File romsDir() { return new File(root(), "roms"); }
    public static File saveDir() { return new File(root(), "saves"); }
    public static File sysDir()  { return new File(root(), "system"); }
    public static File optsFile(){ return new File(root(), "options.txt"); }

    private boolean started = false;
    private LauncherView curLv;            /* 지금 떠 있는 런처(패드 키용). 빈 화면이면 null */
    private LaunchSheet curSheet;          /* 떠 있는 실행 전 선택창 — 패드 키를 이쪽으로 넘긴다 */
    private KeyMap padMap;                 /* 런처 패드 매핑 — 키마다 파일을 다시 읽지 않게(리뷰). 매핑 화면에서 돌아오면 onResume 이 다시 읽는다 */

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        /* 볼륨 키 = 미디어(게임 소리) 음량 — 안 정하면 삼성은 «재생 중»을 못 알아챌 때 벨소리 음량을 바꾼다(유저 2026-10-10 「볼륨 조절이 앱에서 안 되던데」) */
        setVolumeControlStream(android.media.AudioManager.STREAM_MUSIC);
        /* 내려받은 게임표를 먼저 읽는다 — 롬을 알아보기 «전»이어야 한다.
           파일이 없거나 깨져 있으면 아무 일도 안 일어난다(내장표로 돈다). */
        Games.loadExtras(new java.io.File(root(), "design"));
        /* ⚠ 이 파일은 android.provider.Settings 를 import 한다 — 우리 Settings 가 가려진다.
           이름을 다 적어야 우리 것이 잡힌다(짧게 쓰면 조용히 안드로이드 클래스로 간다). */
        com.dudu.pocketcore.Settings.migrate();   /* 옛 옵션 값 → 새 이름. 설정이 꺼지지 않게 */
        Orient.apply(this);
        if (!hasStorage()) { askStorage(); return; }
        setup();
    }

    @Override protected void onResume() {
        super.onResume();
        Orient.apply(this);   /* 런처는 재생성이 안 되니 설정 변경을 여기서도(리뷰 F18) */
        try { padMap = KeyMap.load(); } catch (Exception ignored) { }
        fg = true;
        if (!started && hasStorage()) setup();
        else if (RomImport.changed) {           /* 설정 화면에서 롬을 가져왔다 — 다시 그린다 */
            RomImport.changed = false;
            showList(listRoms());
        }
        if (bgm != null) {
            try { bgm.start(); } catch (Exception ignored) { }
        } else if (bootMp != null) {
            try { bootMp.start(); } catch (Exception ignored) { }
        }
    }

    private boolean hasStorage() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R)
            return Environment.isExternalStorageManager();
        return checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE)
                == PackageManager.PERMISSION_GRANTED;
    }

    private void askStorage() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            Intent i = new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
            startActivity(i);
            Toast.makeText(this, "파일 접근을 허용한 뒤 앱으로 돌아오세요", Toast.LENGTH_LONG).show();
        } else {
            requestPermissions(new String[]{ Manifest.permission.READ_EXTERNAL_STORAGE }, 1);
        }
    }

    @Override public void onRequestPermissionsResult(int rc, String[] p, int[] r) {
        super.onRequestPermissionsResult(rc, p, r);
        if (hasStorage()) setup();
    }

    private void setup() {
        if (started) return;
        started = true;
        romsDir().mkdirs(); saveDir().mkdirs(); sysDir().mkdirs();
        seedOptions();
        seedMods();
        com.dudu.pocketcore.Settings.migrateMotion();   /* 보간 묶음(120Hz·60Hz) 열쇠가 없으면 한 번 정한다 */

        /* 게임에서 「롬 바꾸기」로 온 경우엔 목록을 **반드시** 보여 준다.
           안 그러면 롬이 하나뿐일 때 그 롬으로 바로 되돌아가서 목록도 설정도 영영 못 본다. */
        if (getIntent() != null && getIntent().getBooleanExtra("menu", false)) {
            if (!bootedOnce) playBoot(); else playTheme();   /* 부팅송 → 테마 체이닝 */
            showList(listRoms());
            return;
        }

        SharedPreferences sp = getSharedPreferences(PREFS, MODE_PRIVATE);
        String last = sp.getString(KEY_LAST, null);
        if (last != null && new File(last).exists()) { launch(last); return; }

        List<File> roms = listRoms();
        if (roms.size() == 1) { launch(roms.get(0).getAbsolutePath()); return; }
        if (!bootedOnce) playBoot(); else playTheme();       /* 부팅송 → 테마 체이닝 */
        showList(roms);
    }

    /** 조작 패치 색인 시드 — 「업데이트 확인」 전에도 동봉 FastCD 토글이 보이게 동봉 스냅샷을 놓아 둔다.
     *  업데이트가 받은 최신 색인이 있으면 건드리지 않는다. */
    private void seedMods() {
        try {
            File f = new File(com.dudu.pocketcore.Settings.modsDir(), "mods.json");
            if (f.exists()) return;
            com.dudu.pocketcore.Settings.modsDir().mkdirs();
            java.io.InputStream in = getAssets().open("mods.json");
            java.io.FileOutputStream out = new java.io.FileOutputStream(f);
            byte[] buf = new byte[8192]; int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            out.close(); in.close();
        } catch (Exception ignored) { }
    }

    private List<File> listRoms() {
        File[] f = romsDir().listFiles();
        List<File> out = new ArrayList<>();
        if (f == null) return out;
        Arrays.sort(f);
        for (File x : f) {
            if (!x.isFile() || x.getName().startsWith(".")) continue;
            String n = x.getName().toLowerCase();
            /* 롬만 — 아무 파일이나 목록에 들어가 흰 카드가 생기던 제보(「roms」) */
            if (n.endsWith(".ngc") || n.endsWith(".ngp") || n.endsWith(".npc"))
                out.add(x);
        }
        return out;
    }

    /* ── 런처 소리 — 부팅음·인트로는 **프로세스당 1회**, 테마는 끊기지 않게:
       홈 왕복은 일시정지/재개, 게임 왕복은 재생 위치를 승계한다 (제보: 「끊기는 게 싫다」) ── */
    private android.media.MediaPlayer bgm;
    private android.media.MediaPlayer bootMp; /* 부팅송 — 게임 진입 시 반드시 죽인다 */
    private boolean fg = false;               /* 화면에 떠 있는가 (onResume~onPause) */
    private static int themePos = 0;          /* 액티비티가 죽어도 위치는 남는다 */
    static boolean bootedOnce = false;        /* 부팅 연출·부팅음 1회 게이트 */

    private boolean sndOn() {
        /* android.provider.Settings 와 이름이 겹쳐 FQN — askStorage 가 그쪽을 쓴다 */
        java.util.Map<String, String> m = com.dudu.pocketcore.Settings.load();
        String v = m.get("pocketcore_launcher_snd");
        return v == null || !v.equals("disabled");
    }

    /** 부팅송(내장 boot.mp3, ~7초) — 끝나면 테마곡으로 이어진다.
     *  ★ 플레이어를 필드로 들고 있는다 — 로컬로 두면 부팅송이 도는 7초 안에
     *  게임을 켰을 때 멈출 방법이 없고, 완료 리스너가 **게임 중에** 테마를
     *  틀어 버린다(제보: 「게임 중에 테마송이 나와」). */
    private void playBoot() {
        if (!sndOn()) { playTheme(); return; }
        try {
            android.content.res.AssetFileDescriptor fd = getAssets().openFd("boot.mp3");
            final android.media.MediaPlayer mp = new android.media.MediaPlayer();
            mp.setDataSource(fd.getFileDescriptor(), fd.getStartOffset(), fd.getLength());
            fd.close();
            mp.setVolume(0.8f, 0.8f);
            mp.setOnCompletionListener(new android.media.MediaPlayer.OnCompletionListener() {
                @Override public void onCompletion(android.media.MediaPlayer m2) {
                    m2.release();
                    if (bootMp == m2) bootMp = null;
                    /* 그 사이 게임으로 떠났거나 화면 밖이면 테마를 시작하지 않는다 */
                    if (fg && !isFinishing()) playTheme();
                }
            });
            mp.prepare();
            mp.start();
            bootMp = mp;
        } catch (Exception e) {
            playTheme();                    /* 부팅송이 없거나 실패해도 테마는 흐른다 */
        }
    }

    private void stopBoot() {
        if (bootMp != null) {
            try { bootMp.stop(); bootMp.release(); } catch (Exception ignored) { }
            bootMp = null;
        }
    }

    private void playTheme() {
        if (!sndOn() || bgm != null) return;
        try {
            /* 유저 교체 경로 우선 — system/theme.{wav,mp3,ogg} 를 넣으면 그 곡이 흐른다
               (Suno 등에서 받은 mp3 그대로 됨) */
            File user = null;
            for (String ext : new String[]{ "wav", "mp3", "ogg" }) {
                File f = new File(sysDir(), "theme." + ext);
                if (f.exists()) { user = f; break; }
            }
            android.media.MediaPlayer mp = new android.media.MediaPlayer();
            if (user != null) {
                mp.setDataSource(user.getPath());
            } else {
                android.content.res.AssetFileDescriptor fd = getAssets().openFd("theme.wav");
                mp.setDataSource(fd.getFileDescriptor(), fd.getStartOffset(), fd.getLength());
                fd.close();
            }
            mp.setLooping(true);
            mp.setVolume(0.55f, 0.55f);
            mp.prepare();
            if (themePos > 0) {
                try { mp.seekTo(themePos); } catch (Exception ignored) { }
            }
            mp.start();
            bgm = mp;
        } catch (Exception ignored) { }
    }

    private void stopTheme() {
        if (bgm != null) {
            try { themePos = bgm.getCurrentPosition(); } catch (Exception ignored) { }
            try { bgm.stop(); bgm.release(); } catch (Exception ignored) { }
            bgm = null;
        }
    }

    @Override protected void onPause() {
        super.onPause();
        fg = false;
        /* 홈으로 잠깐 나간 것 — 죽이지 말고 멈췄다가 돌아오면 그 자리부터 */
        if (bgm != null) {
            try { themePos = bgm.getCurrentPosition(); bgm.pause(); }
            catch (Exception ignored) { }
        }
        if (bootMp != null) {
            try { bootMp.pause(); } catch (Exception ignored) { }
        }
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        stopBoot();
        stopTheme();
    }

    private void showList(final List<File> roms) {
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setBackgroundColor(0xff101014);

        if (roms.isEmpty()) {
            /* 첫 손님 화면 — 경로를 알려주는 것으로 끝내지 않는다: 복사·선택·스캔 세 길
               (제보: 「하나는 해라 전부 다 하던지」) */
            LinearLayout empty = new LinearLayout(this);
            empty.setOrientation(LinearLayout.VERTICAL);
            empty.setPadding(48, 70, 48, 30);

            TextView t = new TextView(this);
            t.setTextColor(0xffdddddd);
            t.setTextSize(16);
            t.setText("롬이 없습니다. 세 가지 중 편한 길로:");
            empty.addView(t);

            TextView path = new TextView(this);
            path.setTypeface(android.graphics.Typeface.MONOSPACE);
            path.setTextColor(0xffd9a441);
            path.setTextSize(13);
            path.setPadding(0, 24, 0, 24);
            path.setText(romsDir().getAbsolutePath());
            empty.addView(path);

            empty.addView(emptyBtn("① 폴더 주소 복사 — PC·파일 앱에서 붙여넣기",
                    0xff23262f, new View.OnClickListener() {
                @Override public void onClick(View v) { RomImport.copyPath(MainActivity.this); }
            }));
            empty.addView(emptyBtn("② 파일 골라 가져오기 — 다운로드 폴더 등에서 선택",
                    0xff1f2b22, new View.OnClickListener() {
                @Override public void onClick(View v) { RomImport.pick(MainActivity.this); }
            }));
            empty.addView(emptyBtn("③ 저장소 스캔 — 기기 안의 롬을 찾아 모아오기",
                    0xff2b2418, new View.OnClickListener() {
                @Override public void onClick(View v) { RomImport.scan(MainActivity.this); }
            }));

            TextView hint = new TextView(this);
            hint.setTextColor(0xff8b93a6);
            hint.setTextSize(12);
            hint.setPadding(0, 24, 0, 0);
            hint.setText("넣는 롬은 한글패치 전 순정 롬(.ngc/.ngp, zip·7z 안도 꺼냄)이면 됩니다 —\n"
                    + "실행할 때 최신 한글패치를 받아 사본에 입힙니다.");
            empty.addView(hint);

            android.widget.ScrollView sv = new android.widget.ScrollView(this);
            sv.addView(empty);
            col.addView(sv, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        } else {
            /* 레트로 런처 — NGPC 해상도 캔버스에 카트리지 캐러셀.
               썸네일은 롬당 1회 몰래 부팅해 캡처(Thumbs), 그다음부터는 캐시. */
            final LauncherView lv = new LauncherView(this);
            curLv = lv;
            final List<LauncherView.Item> items = new ArrayList<>();
            java.util.Map<String, String> meta = designMeta();
            for (File r : roms) {
                Games.Game g = Games.identify(r.getPath());
                String nm = (g != null) ? g.ko : stripExt(r.getName());
                LauncherView.Item it = new LauncherView.Item(r, nm);
                if (g != null) {
                    it.sp  = g.has(Games.F_SP_SVC);   /* 게임 표의 features 가 단일 출처 */
                    it.dub = false;   /* 해설·더빙 폐기(2026-09-07) */
                    it.pat = new File(new File(root(), "patch"), g.id + "_ko.ips").exists()
                          || assetExists("patch/" + g.id + "_ko.ips");
                    String sub = meta.get(g.id);
                    if (sub != null) it.sub = sub;
                    /* 한패가 못 붙는 판본은 그 사실을 카드에 바로 적는다 —
                       「왜 한글이 안 나오지」가 앱 고장으로 읽히지 않게 */
                    if ("lbj".equals(g.id)) it.sub = "일본판 롬 — 한글패치는 UE(영문)판 전용";
                }
                File tf = thumbFor(r, g);
                if (tf != null)
                    it.thumb = android.graphics.BitmapFactory.decodeFile(tf.getPath());
                try { it.opt = LaunchSheet.summary(this, g); } catch (Exception ignored) { }
                it.resume = new File(saveDir(), r.getName() + ".state.auto").exists();
                items.add(it);
            }
            lv.setItems(items);
            String played = getSharedPreferences(PREFS, MODE_PRIVATE).getString(KEY_PLAYED, null);
            if (played != null)
                for (int k = 0; k < roms.size(); k++)
                    if (roms.get(k).getAbsolutePath().equals(played)) { lv.select(k); break; }
            if (Updater.testLevel()) {          /* 시험 레벨이면 런처에 배지 — 정식이면 아무것도 안 붙는다 */
                String vn = "";
                try { vn = " v" + getPackageManager().getPackageInfo(getPackageName(), 0).versionName; }
                catch (Exception ignored) { }
                lv.setChannel("시험" + vn);
            }
            if (!bootedOnce) {             /* 스마일 볼 연출은 프로세스당 1회 — 복귀 땐 조용히 */
                lv.startIntro();
                bootedOnce = true;
            }
            lv.setListener(new LauncherView.Listener() {
                /* 카드·A = 바로 시작(하던 자리부터). 옵션은 카드 아래 칩으로 — 매번 창을 거치면 실행이 두 번 눌러야 됐다(2026-10-11) */
                @Override public void onLaunch(File rom) { launch(rom.getAbsolutePath()); }
                @Override public void onOptions(File rom) { openSheet(rom); }   /* 실행 전 패치 선택창 */
                @Override public void onSettings() {
                    startActivity(new Intent(MainActivity.this, SettingsActivity.class));
                }
                @Override public void onUpdate() { Updater.check(MainActivity.this); }
            });
            col.addView(lv, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

            /* 빠진 썸네일을 뒤에서 하나씩 굽는다 — 다 되는 대로 즉시 반영.
               실행(launch)이 stop 을 세우면 현재 것만 마치고 그만둔다. */
            Thumbs.stop = false;
            new Thread(new Runnable() { @Override public void run() {
                for (LauncherView.Item it : items) {
                    if (Thumbs.stop) break;
                    if (it.thumb != null) continue;
                    if (Thumbs.ensure(MainActivity.this, it.rom)) {
                        it.thumb = android.graphics.BitmapFactory
                                .decodeFile(Thumbs.of(it.rom).getPath());
                        lv.thumbReady();
                    }
                }
            }}).start();
        }

        /* 하단 바: 설정 + 업데이트. 오버레이(아래+옵션)는 게임 안에서만 열리고 코어가 정한
           항목만 나오므로, 언어처럼 앱이 다루는 설정은 여기 아니면 갈 데가 없다.
           업데이트는 PC 릴리즈 서버(같은 와이파이)에서 새 판을 받아 설치창까지 간다. */
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setBackgroundColor(0xff0b0b0e);
        int gp = (int) (12 * getResources().getDisplayMetrics().density);
        bar.setPadding(gp, gp / 2, gp, gp);
        /* 런처 바탕과 같은 먹색 위에 둥근 버튼 두 개 — 예전 납작한 색 덩어리 대신(유저 2026-10-10 「인터페이스 좀 손봐 줘」) */
        TextView cfg = barButton("설정", 0xffd9a441, 0xff191b22, 0xff4a3d22);
        cfg.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, SettingsActivity.class));
            }
        });
        final TextView upd = barButton("업데이트 확인", 0xffbfc6d4, 0xff191b22, 0xff2f3442);
        upd.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { Updater.check(MainActivity.this); }
        });
        /* 새 판이 있는지 조용히 본다(색인 한 번, 실패는 무시) — 있으면 버튼이 「새 판 받기」로 바뀐다.
           직접 눌러 봐야 알던 것을 런처가 알려 준다(2026-10-11). 앱이 켜질 때 한 번만. */
        if (newerCode == 0) {
            new Thread(new Runnable() { @Override public void run() {
                final int nc = Updater.peekNewer(MainActivity.this);
                newerCode = nc > 0 ? nc : -1;
                if (nc > 0) runOnUiThread(new Runnable() { @Override public void run() { markUpdate(upd); } });
                else Updater.autoPacks(MainActivity.this);      /* 앱이 최신이면 팩(모션 캐시 등)은 알아서 — 와이파이일 때만 */
            }}).start();
        } else if (newerCode > 0) markUpdate(upd);
        LinearLayout.LayoutParams lp1 = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        lp1.rightMargin = gp / 2;
        LinearLayout.LayoutParams lp2 = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        lp2.leftMargin = gp / 2;
        bar.addView(cfg, lp1);
        bar.addView(upd, lp2);
        col.addView(bar);
        setContentView(col);
    }

    /** 새 판 번호(내부) — 0 = 아직 안 봄, -1 = 없음/못 봄. 프로세스당 한 번. */
    private static volatile int newerCode = 0;
    private void markUpdate(TextView upd) {
        upd.setText("새 판 받기 · 내부 " + newerCode);
        upd.setTextColor(0xff101014);
        android.graphics.drawable.GradientDrawable d = new android.graphics.drawable.GradientDrawable();
        d.setColor(0xffd9a441);
        d.setCornerRadius(14 * getResources().getDisplayMetrics().density);
        upd.setBackground(d);
    }

    /** 런처 아래 줄 버튼 — 둥근 판 + 가는 테. */
    private TextView barButton(String label, int fg, int bg, int stroke) {
        TextView t = new TextView(this);
        t.setText(label);
        t.setTextColor(fg);
        t.setTextSize(16);
        t.setGravity(android.view.Gravity.CENTER);
        float d = getResources().getDisplayMetrics().density;
        t.setPadding(0, (int) (14 * d), 0, (int) (14 * d));
        android.graphics.drawable.GradientDrawable g = new android.graphics.drawable.GradientDrawable();
        g.setColor(bg);
        g.setCornerRadius(14 * d);
        g.setStroke(Math.max(1, (int) d), stroke);
        t.setBackground(g);
        t.setClickable(true);
        /* 패드 십자·A 는 런처가 직접 받는다(dispatchKeyEvent). 버튼이 포커스를 가질 수 있으면 화면을 만진 뒤 첫 십자 입력을
           안드로이드가 «터치 모드 빠져나가기»로 먹어서 카드는 안 넘어가고 「설정」에 테두리만 생겼다(108 ui_shots 에서 확인). */
        t.setFocusable(false);
        return t;
    }

    /** 실행 전 패치 선택창 — 카드를 누르면 바로 실행하지 않고 그 게임에 적용할 것을 고른 뒤 「시작」. */
    private void openSheet(final File rom) {
        Games.Game g = Games.identify(rom.getPath());
        String title = (g != null) ? g.ko : stripExt(rom.getName());
        android.graphics.Bitmap thumb = null;
        if (curLv != null) {
            LauncherView.Item it = curLv.selected();
            if (it != null && it.rom.equals(rom)) thumb = it.thumb;
        }
        if (curSheet != null && curSheet.isShowing()) return;   /* 이미 떠 있으면 또 안 연다(확인 연타) */
        curSheet = LaunchSheet.show(this, rom, g, thumb, title, new Runnable() {
            @Override public void run() { launch(rom.getAbsolutePath()); }
        });
    }

    /** 런처 패드 키 — 좌우 = 카드, A(펀치 자리)·DPAD_CENTER·ENTER·START = 선택창. 선택창이 떠 있으면 그쪽 창이 받는다. */
    @Override public boolean dispatchKeyEvent(android.view.KeyEvent e) {
        if (curLv == null || KeyMap.isVolume(e.getKeyCode())) return super.dispatchKeyEvent(e);   /* 음량은 늘 시스템으로 */
        if (curSheet != null && curSheet.isShowing()) {          /* 선택창이 떠 있으면 키는 창의 몫 */
            if (curSheet.handleKey(e)) return true;
            if (KeyMap.isPadButton(e.getKeyCode())) return true;   /* 배정 없는 패드 버튼은 삼킨다 */
            return super.dispatchKeyEvent(e);
        }
        int code = e.getKeyCode();
        String f = null;
        if (padMap == null) { try { padMap = KeyMap.load(); } catch (Exception ignored) { } }
        if (padMap != null && KeyMap.isGamepad(e)) f = padMap.funcOf(code);
        boolean padBtn = KeyMap.isPadButton(code);                /* 패드 버튼은 기능(b=확인)으로만 — LaunchSheet 와 같은 규칙 */
        boolean left  = "left".equals(f)  || (!padBtn && code == android.view.KeyEvent.KEYCODE_DPAD_LEFT);
        boolean right = "right".equals(f) || (!padBtn && code == android.view.KeyEvent.KEYCODE_DPAD_RIGHT);
        boolean ok    = "b".equals(f) || "start".equals(f)
                     || (!padBtn && (code == android.view.KeyEvent.KEYCODE_DPAD_CENTER || code == android.view.KeyEvent.KEYCODE_ENTER))
                     || (f == null && code == android.view.KeyEvent.KEYCODE_BUTTON_START);
        boolean opt   = "select".equals(f) || (f == null && code == android.view.KeyEvent.KEYCODE_BUTTON_SELECT);   /* SELECT = 실행 옵션 창 */
        if (!(left || right || ok || opt)) {
            /* 배정 없는 패드 버튼은 삼킨다 — 안 그러면 시스템 폴백이 Y 를 BACK 으로 바꿔 앱이 꺼진다(리뷰) */
            if (padBtn) return true;
            return super.dispatchKeyEvent(e);
        }
        if (e.getAction() == android.view.KeyEvent.ACTION_DOWN && e.getRepeatCount() == 0) {
            if (left) curLv.moveSel(-1);
            else if (right) curLv.moveSel(1);
            else {
                LauncherView.Item it = curLv.selected();
                if (it != null) { if (opt) openSheet(it.rom); else launch(it.rom.getAbsolutePath()); }
            }
        }
        return true;
    }

    /** 스틱·HAT 십자 — **많은 패드가 십자를 축으로 보내서 KeyEvent 가 아예 안 온다.**
     *  에뮬 화면·키 배정 화면엔 이 처리가 있었는데 런처에만 없어서 「패드로 게임이 안 골라진다」가
     *  됐다(유저 제보 2026-09-05). 좌우 = 카드 넘기기, 선택창이 떠 있으면 위아래 = 항목. */
    private int axisPrev = 0;

    @Override public boolean onGenericMotionEvent(android.view.MotionEvent e) {
        int m = KeyMap.axisMask(e);
        if (m < 0) return super.onGenericMotionEvent(e);
        int went = m & ~axisPrev;      /* 새로 «기울인» 방향만 — 쥐고 있어도 한 칸만 간다 */
        axisPrev = m;
        if (went == 0) return true;
        if (curSheet != null && curSheet.isShowing()) {
            if ((went & (1 << Emu.UP)) != 0)    curSheet.moveFocus(-1);
            if ((went & (1 << Emu.DOWN)) != 0)  curSheet.moveFocus(+1);
            return true;
        }
        if (curLv == null) return true;
        if ((went & (1 << Emu.LEFT)) != 0)  curLv.moveSel(-1);
        if ((went & (1 << Emu.RIGHT)) != 0) curLv.moveSel(1);
        return true;
    }

    private void launch(String romPath) {
        stopBoot();      /* 부팅송이 도는 7초 안에 게임을 켜도 확실히 끊는다 */
        stopTheme();
        /* 백그라운드 썸네일 캡처와 코어 전역 상태가 겹치면 안 된다 —
           멈추라고 표시하고, 진행 중인 한 개가 끝나기를 잠깐 기다린다. */
        Thumbs.stop = true;
        synchronized (Thumbs.LOCK) { }
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(KEY_LAST, romPath).putString(KEY_PLAYED, romPath).apply();
        Intent i = new Intent(this, EmuActivity.class);
        i.putExtra("rom", romPath);
        startActivity(i);
        finish();
    }

    /** 코어 기본 옵션 — 메뉴가 없으므로 첫 실행 때 한 번 써 둔다. 수정은 파일에서. */
    private void seedOptions() {
        File f = optsFile();
        if (f.exists()) return;
        String def = "# PocketCore 옵션 (key=value). 수정 후 앱 재시작.\n"
                + "#\n"
                + "# 게임 언어: ko / ja / en   (옛 ko-ja·ko-en 도 읽힌다)\n"
                + "#   네오지오 포켓 롬은 일어와 영어를 **함께** 담고 BIOS 설정으로 고른다.\n"
                + "#   한글 패치는 그중 한쪽 표만 덮으므로, 덮인 쪽으로 맞춰야 한글이 보인다.\n"
                + "#   어느 쪽을 덮었는지는 게임마다 달라서 바탕을 고르게 뒀다:\n"
                + "#     ko = 한글 (바탕 언어는 게임마다 앱이 맞춘다)\n"
                + "#   패치는 롬 **사본**에 입힌다 — 원본 롬은 안 건드린다.\n"
                + "#   ngp_language 는 앱이 이 값에 맞춰 알아서 쓴다.\n"
                + "pocketcore_lang=ko\n"
                + "#\n"
                + "# 기술명 띠 — 화면 밖 띠에 기술 이름을 띄운다(게임 그림을 안 가린다).\n"
                + "ngp_svcsp_band=enabled\n"
                + "#\n"
                + "# 재생 키가 문장 해시라서 표와 팩의 판이 어긋나면 그냥 조용해진다.\n"
                + "ngp_language=japanese\n"
                + "ngp_svcsp_engine=enabled\n"
                + "# KOF R-2 원버튼(R=SP, 탭 약/꾹 강). 기본 꺼짐 — 켜면 R 이 A+B 대신 SP.\n"
                + "ngp_kofsp_engine=disabled\n"
                + "ngp_kofsp_toast=enabled\n"
                + "ngp_svcsp_toast=enabled\n"
                + "ngp_ss2sp=enabled\n"
                + "# 화면 방향(auto/portrait/landscape)·터치 패드(auto/on/off) — 게임기(가로·물리 패드)용.\n"
                + "# 배포 레벨: stable=정식(검증된 판만) / test=시험(나오는 대로). 앱·코어 공통.\n"
                + "pocketcore_level=stable\n"
                + "pocketcore_orientation=auto\n"
                + "pocketcore_touchpad=auto\n"
                + "# 캐릭터 챗은 기본 끔, 심판(쿠로코)은 켬 — 둘은 따로 논다(유저 지시 2026-09-03).\n"
                + "ngp_ss2sp_chat=disabled\n"
                + "ngp_ss2sp_ref=disabled\n"
                + "ngp_ss2sp=enabled\n";
        try (java.io.FileOutputStream fo = new java.io.FileOutputStream(f)) {
            fo.write(def.getBytes("UTF-8"));
        } catch (Exception ignored) { }
    }

    /** EmuActivity calls this when the user asks for a different ROM. */
    public static void forgetLast(Activity a) {
        a.getSharedPreferences(PREFS, MODE_PRIVATE).edit().remove(KEY_LAST).apply();
    }

    /** 빈 화면 버튼 — 하단바와 같은 톤의 큼직한 줄 버튼. */
    private TextView emptyBtn(String label, int bgCol, View.OnClickListener l) {
        TextView b = new TextView(this);
        b.setText(label);
        b.setTextColor(0xffe6e8ee);
        b.setTextSize(15);
        b.setPadding(36, 40, 36, 40);
        b.setBackgroundColor(bgCol);
        b.setClickable(true);
        b.setOnClickListener(l);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        p.setMargins(0, 0, 0, 18);
        b.setLayoutParams(p);
        return b;
    }

    @Override protected void onActivityResult(int rc, int res, Intent data) {
        super.onActivityResult(rc, res, data);
        if (rc == RomImport.REQ_PICK && res == RESULT_OK) {
            RomImport.onPicked(this, data);     /* 복사는 작업 스레드 — 끝나면 romsChanged() */
        }
    }

    /** 롬 가져오기(골라 오기·스캔)가 끝났을 때 RomImport.report 가 부른다(UI 스레드). */
    void romsChanged() {
        if (RomImport.changed && started) { RomImport.changed = false; showList(listRoms()); }
    }

    /* ── 런처 보조 ──────────────────────────────────────────────── */

    /** 썸네일 우선순위: 내 지정(게임 중 샷→지정) > 배포 지정(업데이트로 받은 것) >
     *  자동 캡처. 없으면 null — 백그라운드 캡처가 채운다. */
    private static File thumbFor(File rom, Games.Game g) {
        File base = new File(root(), "design/thumbs");
        File f = new File(new File(base, "pick"), rom.getName() + ".png");
        if (f.exists()) return f;
        if (g != null) {
            f = new File(new File(base, "byid"), g.id + ".png");
            if (f.exists()) return f;
        }
        f = new File(base, rom.getName() + ".png");
        return f.exists() ? f : null;
    }

    private static String stripExt(String n) {
        int d = n.lastIndexOf('.');
        return d > 0 ? n.substring(0, d) : n;
    }

    private boolean assetExists(String path) {
        try (java.io.InputStream in = getAssets().open(path)) { return true; }
        catch (Exception e) { return false; }
    }

    /** 디자인 메타데이터 — 릴리즈의 design.json 을 「업데이트 확인」이 받아 둔다.
     *  게임 id → 정보줄(연도·장르). 없으면 그냥 배지만 나온다. */
    private java.util.Map<String, String> designMeta() {
        java.util.Map<String, String> m = new java.util.HashMap<>();
        try {
            File f = new File(new File(root(), "design"), "design.json");
            byte[] b = new byte[(int) f.length()];
            try (java.io.FileInputStream in = new java.io.FileInputStream(f)) {
                int n = 0;
                while (n < b.length) {
                    int r = in.read(b, n, b.length - n);
                    if (r < 0) break;
                    n += r;
                }
            }
            org.json.JSONObject g = new org.json.JSONObject(new String(b, "UTF-8"))
                    .getJSONObject("games");
            java.util.Iterator<String> it = g.keys();
            while (it.hasNext()) {
                String id = it.next();
                m.put(id, g.getJSONObject(id).optString("sub", ""));
            }
        } catch (Exception ignored) { }
        return m;
    }
}
