/* 가상 리그 — 사무쇼2 랭크전 한 판의 «대진 덮어쓰기»와 «최종 결과 감지».

   기획서(NGP 사무라이 쇼다운 2 가상 리그 v1) 4장의 두 검증 항목을 실행부에서 한다.
   주소는 CustumApKS handoff/ss2_league/0단계_주소탐색_결과.md 에서 확정한 것만 쓴다
   (순정 ss2.ngc·ss2_h1.ngc 와 한글패치 v1.01·동봉판 사본에서 같게 동작함을 실측).
   지원하지 않는 롬에서는 Java 가 아예 무장(arm)하지 않는다 — 여기서는 롬을 가리지 않는다.

   매 «진짜» 프레임(retro_run 한 번 뒤, 코어 잠금 안)에 league_tick 이 불린다.
   런어헤드·프레임 생성의 숨은 프레임은 코어 안에서 되돌려지므로 여기 오지 않는다.

     대진: 결판 전까지 매 프레임 0x57DF(상대 id)·0x57E0(유파)를 쓴다. 게임은 상대를 뽑는 프레임에
           한 번 써 넣으므로 그 뒤 첫 프레임에 다시 덮이고, 전투 로드(0x5D51) 때는 이미 우리 값이다.
     결과: 0x5824 의 bit7(경기 결판)이 0 인 것을 한 번 본 뒤 1 로 서는 첫 프레임 = 경기 최종 결과.
           승자는 같은 바이트의 0x40(P1)/0x20(P2), 둘 다 없으면 무승부. 승수는 0x5821/0x5822.
           «승수 == 2» 는 쓰지 않는다 — 무승부 라운드(양쪽 +1)·3:3 무승부·포인트 3·1 라운드 경기에서 틀린다.
     한 번만: 잡은 뒤에는 done 이 서고 다시 잡지 않는다. Java 가 가져가면(take) 비운다. */

#include <jni.h>
#include <pthread.h>
#include <stdint.h>
#include <string.h>
#include "league.h"

#define RAM_BASE 0x4000
#define A(x) ((x) - RAM_BASE)

#define R_OPP    A(0x57DF)   /* 다음/지금 상대 캐릭터 id (0~14) */
#define R_STY    A(0x57E0)   /* 상대 유파 0 修羅 · 1 羅刹 */
#define R_CARD1  A(0x57DC)   /* P1 능력 카드 1 · 2 — 0xFF 없음 */
#define R_CARD2  A(0x57DD)
#define R_W1     A(0x5821)   /* 라운드 승수 P1 · P2 */
#define R_W2     A(0x5822)
#define R_KO     A(0x5823)
#define R_RES    A(0x5824)   /* 라운드 결과 0x40 P1 · 0x20 P2 · 0x10 무승부 라운드, +0x80 경기 결판 */
#define R_NEED   A(0x5813)   /* 이번 경기 실효 포인트(필요 승수) */
#define R_TIME   A(0x5812)   /* 이번 경기 실효 시간 */
#define R_HP1    A(0x5A46)
#define R_HP2    A(0x5C46)
#define R_P1BLK  A(0x5B51)   /* (캐릭터<<4)|(유파<<3)|(카드 미러 0x04) */
#define R_P2BLK  A(0x5D51)
#define R_MODE   A(0x40A7)   /* 240 메뉴·연출 / 241 전투측 */
#define R_OPT    A(0x636A)   /* GAME OPTION: 난도·포인트·시간·대전 포인트·대전 시간 */

static pthread_mutex_t L_mu = PTHREAD_MUTEX_INITIALIZER;
static struct {
   int armed;
   int opp, sty;            /* 대진 목표 */
   int diff, points, timev; /* 옵션 — 음수면 안 건드린다 */
   int cards_off;           /* 1 = 사용자 카드 없음(0xFF) */
   int seen_open;           /* 무장 뒤 bit7 이 0 인 걸 봤나 */
   int fight_seen;          /* 우리 상대로 전투가 로드된 걸 봤나(P2 블록 == 목표) */
   int done;                /* 최종 결과를 잡았나 */
   int bits, w1, w2, ko, need, p1blk, p2blk, p2blk_first;
   unsigned frames, fight_frame, done_frame;
} L;

void league_tick(uint8_t *ram, size_t n)
{
   if (!ram || n < 0x4000) return;
   pthread_mutex_lock(&L_mu);
   if (!L.armed || L.done) { pthread_mutex_unlock(&L_mu); return; }
   L.frames++;

   ram[R_OPP] = (uint8_t)L.opp;
   ram[R_STY] = (uint8_t)L.sty;
   if (L.cards_off) { ram[R_CARD1] = 0xFF; ram[R_CARD2] = 0xFF; }
   if (L.diff   >= 0) ram[R_OPT + 0] = (uint8_t)L.diff;
   if (L.points >  0) ram[R_OPT + 1] = (uint8_t)L.points;
   if (L.timev  >  0) ram[R_OPT + 2] = (uint8_t)L.timev;

   /* 전투가 우리 상대로 로드됐는지 — 대진 준비 실패를 점수에 넣지 않기 위한 증거 */
   if (ram[R_MODE] == 241 && ram[R_HP2] > 0) {
      uint8_t want = (uint8_t)((L.opp << 4) | (L.sty << 3));
      if ((ram[R_P2BLK] & 0xF8) == want && !L.fight_seen) {
         L.fight_seen = 1; L.fight_frame = L.frames; L.p2blk_first = ram[R_P2BLK];
      }
   }

   uint8_t r = ram[R_RES];
   if (!(r & 0x80)) L.seen_open = 1;
   else if (L.seen_open) {
      L.done = 1; L.done_frame = L.frames;
      L.bits = r; L.w1 = ram[R_W1]; L.w2 = ram[R_W2]; L.ko = ram[R_KO];
      L.need = ram[R_NEED]; L.p1blk = ram[R_P1BLK]; L.p2blk = ram[R_P2BLK];
   }
   pthread_mutex_unlock(&L_mu);
}

#define JNI(ret, name) JNIEXPORT ret JNICALL Java_com_dudu_pocketcore_Emu_##name

JNI(void, nativeLeagueArm)(JNIEnv *env, jclass cls, jint opp, jint sty, jint diff, jint points,
                           jint timev, jboolean cardsOff)
{
   (void)env; (void)cls;
   pthread_mutex_lock(&L_mu);
   memset(&L, 0, sizeof L);
   L.opp = opp & 0x0F; L.sty = sty & 1;
   L.diff = diff; L.points = points; L.timev = timev; L.cards_off = cardsOff ? 1 : 0;
   L.armed = 1;
   pthread_mutex_unlock(&L_mu);
}

JNI(void, nativeLeagueDisarm)(JNIEnv *env, jclass cls)
{
   (void)env; (void)cls;
   pthread_mutex_lock(&L_mu); L.armed = 0; pthread_mutex_unlock(&L_mu);
}

/* [무장, 프레임, bit7 0 봄, 우리 상대 전투 봄, 결과 잡음, 결과 비트, 승수1, 승수2, KO, 실효 포인트,
    P1 블록, P2 블록(결판), P2 블록(첫 전투), 전투 프레임, 결판 프레임] */
JNI(jintArray, nativeLeagueStatus)(JNIEnv *env, jclass cls)
{
   (void)cls;
   jint v[15];
   pthread_mutex_lock(&L_mu);
   v[0] = L.armed; v[1] = (jint)L.frames; v[2] = L.seen_open; v[3] = L.fight_seen; v[4] = L.done;
   v[5] = L.bits; v[6] = L.w1; v[7] = L.w2; v[8] = L.ko; v[9] = L.need;
   v[10] = L.p1blk; v[11] = L.p2blk; v[12] = L.p2blk_first;
   v[13] = (jint)L.fight_frame; v[14] = (jint)L.done_frame;
   pthread_mutex_unlock(&L_mu);
   jintArray a = (*env)->NewIntArray(env, 15);
   if (a) (*env)->SetIntArrayRegion(env, a, 0, 15, v);
   return a;
}
