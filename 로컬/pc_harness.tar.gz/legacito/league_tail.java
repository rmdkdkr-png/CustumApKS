    /* ── 경기 ─────────────────────────────────────────────────────────── */

    /** 끝난 상태 — 여기서는 다른 상태로 못 바꾼다(정산 완료·기권·오류 보류·무효). */
    static boolean terminal(String s) {
        return "settled".equals(s) || "forfeit".equals(s) || "hold".equals(s) || "cancelled".equals(s);
    }

    /** 시작 전에 경기 id·설정·시작 점수를 영속 저장한다(기획서 «중단과 복원»·«시작 시점 두 점수로 구간 고정»).
     *  이미 열린 경기가 있거나 저장에 실패하면 null — 시작하지 않는다. */
    static synchronized JSONObject newMatch(String oppId) {
        try {
            if (openMatch() != null) return null;
            JSONObject o = oppById(oppId);
            if (o == null) return null;
            JSONObject m = new JSONObject();
            m.put("id", java.util.UUID.randomUUID().toString());
            m.put("opp", oppId);
            m.put("created", System.currentTimeMillis());
            m.put("status", "ready");
            m.put("side", "P1");                        /* 1P PLAY 에서 사람은 늘 P1 블록 */
            JSONObject rule = new JSONObject();
            rule.put("char", o.optInt("char")); rule.put("style", o.optInt("style")); rule.put("diff", o.optInt("diff"));
            rule.put("points", POINTS); rule.put("time", TIME);
            rule.put("cards", "all");                   /* 초기안: 전원 올카드 해금(기획서 2장) — CPU 는 카드 없음 */
            m.put("rule", rule);
            m.put("start_score", new JSONObject().put("me", me().optInt("score")).put("opp", o.optInt("score")));
            m.put("rank_before", rankOf("me"));
            matches().put(m);
            if (!save()) { matches().remove(matches().length() - 1); return null; }
            return m;
        } catch (Exception e) { return null; }
    }

    /** 상태 바꾸기 — 경기 id 로 찾는다(메모리를 되돌린 뒤에도 옛 객체에 쓰지 않게). 끝난 경기는 안 바꾼다. */
    static synchronized boolean setStatus(String id, String status, String why) {
        JSONObject m = matchById(id);
        if (m == null || terminal(m.optString("status"))) return false;
        try {
            m.put("status", status);
            if (why != null) m.put("why", why);
            m.put("updated", System.currentTimeMillis());
            return save();
        } catch (Exception e) { return false; }
    }

    static synchronized boolean note(String id, String key, Object val) {
        JSONObject m = matchById(id);
        if (m == null) return false;
        try { m.put(key, val); return save(); } catch (Exception e) { return false; }
    }

    /** 오류 보류 — 원인과 복구 방법을 같이 남긴다(기획서 «판정 오류는 보류하고 원인과 복구 방법을 기록»). 점수는 안 움직인다. */
    static synchronized boolean hold(String id, String why, String fix) {
        JSONObject m = matchById(id);
        if (m == null || terminal(m.optString("status"))) return false;
        try {
            m.put("status", "hold"); m.put("why", why); m.put("fix", fix);
            m.put("updated", System.currentTimeMillis());
            ckpt(id).delete();
            return save();
        } catch (Exception e) { return false; }
    }

    /** 무효 — 아직 대진 전(준비)에 멈춘 경기. 대진 준비 실패는 점수에 넣지 않는다. */
    static synchronized boolean cancel(String id, String why) {
        JSONObject m = matchById(id);
        if (m == null || !"ready".equals(m.optString("status"))) return false;
        try {
            m.put("status", "cancelled"); m.put("why", why); m.put("updated", System.currentTimeMillis());
            if (!save()) return false;
            ckpt(id).delete();
            return true;
        } catch (Exception e) { return false; }
    }

    /** 점수 구간 — 경기 시작 시점 두 점수로 고정(기획서 3장 표). 내 변화량의 반대를 상대에게. */
    static int delta(int myScore, int oppScore, String outcome) {
        int gap = oppScore - myScore;
        if ("D".equals(outcome)) return 0;
        boolean win = "W".equals(outcome);
        if (gap >= 101)  return win ? 18 : -6;
        if (gap <= -101) return win ? 6 : -18;
        return win ? 12 : -12;
    }

    /* ── 순위 ─────────────────────────────────────────────────────────── */

    /** 지금 순위(id 목록, 1위부터). 점수 내림차순, 동점이면 **직전 순위 그대로**, 처음엔 고정 id 순(나 먼저). */
    static synchronized java.util.List<String> order() {
        JSONObject d = db();
        java.util.List<String> prev = new java.util.ArrayList<>();
        JSONArray po = d.optJSONArray("order");
        if (po != null) for (int i = 0; i < po.length(); i++) prev.add(po.optString(i));
        final java.util.List<String> ids = new java.util.ArrayList<>();
        ids.add("me");
        JSONArray a = opps();
        for (int i = 0; i < a.length(); i++) ids.add(a.optJSONObject(i).optString("id"));
        final java.util.Map<String, Integer> pos = new java.util.HashMap<>();
        for (int i = 0; i < ids.size(); i++) {                 /* 직전 순위에 없던 사람(새로 든 상대)은 고정 id 순으로 뒤에 */
            int k = prev.indexOf(ids.get(i));
            pos.put(ids.get(i), k >= 0 ? k : 1000 + i);
        }
        java.util.Collections.sort(ids, (x, y) -> {
            int sx = scoreOf(x), sy = scoreOf(y);
            return sx != sy ? sy - sx : pos.get(x) - pos.get(y);
        });
        return ids;
    }

    static int scoreOf(String id) {
        if ("me".equals(id)) return me().optInt("score");
        JSONObject o = oppById(id);
        return o != null ? o.optInt("score") : 0;
    }

    static int rankOf(String id) { return order().indexOf(id) + 1; }

    /** 점수가 바뀐 뒤 지금 순위를 직전 순위로 굳힌다(다음 동점 판정의 기준). save 는 호출자가. */
    private static void commitOrder() throws Exception {
        db.put("order", new JSONArray(order()));
    }

    /* ── 정산 ─────────────────────────────────────────────────────────── */

    /**
     * 정산 — 같은 경기는 한 번만. 이미 끝난 경기면 그대로 돌려준다(결과 화면 재진입·앱 재시작 중복 방지).
     * st = Emu.nativeLeagueStatus() 결판 줄. 다음이면 점수에 넣지 않고 보류한다:
     *   대진 불일치(결판 때 P2 블록 ≠ 표시한 상대) · 규칙 불일치(실효 포인트·시간 ≠ 랭크전 규칙 — 예: 무한 대전 1라운드 결판).
     * 저장에 실패하면 메모리를 되돌리고 null — 호출자가 다시 시도한다(결과는 코어 쪽에 그대로 있다).
     */
    static synchronized JSONObject settle(String matchId, int[] st) {
        JSONObject m = matchById(matchId);
        if (m == null) return null;
        if (terminal(m.optString("status"))) return m;
        String backup = db.toString();
        try {
            JSONObject rule = m.optJSONObject("rule");
            JSONObject o = oppById(m.optString("opp"));
            JSONObject me = me();
            int bits = st[5], w1 = st[6], w2 = st[7], p1 = st[10], p2 = st[11];
            int need = st[9], time = st.length > 17 ? st[17] : rule.optInt("time");
            JSONObject res = new JSONObject();
            res.put("bits", bits); res.put("w1", w1); res.put("w2", w2); res.put("ko", st[8]); res.put("need", need); res.put("time", time);
            res.put("p1blk", p1); res.put("p2blk", p2); res.put("frame", st[14]);
            res.put("start_seen", st[3] == 1); res.put("p2blk_start", st[12]); res.put("start_frame", st[13]);
            res.put("cards", String.format("%02X %02X", st.length > 15 ? st[15] : 0xFF, st.length > 16 ? st[16] : 0xFF));
            res.put("my_char", (p1 >> 4) & 0x0F); res.put("my_style", (p1 >> 3) & 1);
            res.put("at", System.currentTimeMillis());
            m.put("result", res);
            int want = (rule.optInt("char") << 4) | (rule.optInt("style") << 3);
            String why = null;
            if ((p2 & 0xF8) != want)
                why = String.format("대진 불일치: 요청 %s·%s, 실제 P2 블록 0x%02X", CHAR[rule.optInt("char")], STYLE[rule.optInt("style")], p2);
            else if (need != rule.optInt("points") || time != rule.optInt("time"))
                why = "규칙 불일치: 실효 포인트 " + need + "·시간 " + time + " (랭크전 " + rule.optInt("points") + "·" + rule.optInt("time")
                    + ") — 1인 대전 첫 경기가 아닌 곳(무한 대전 등)에서 결판이 났습니다";
            if (why != null) {
                m.put("status", "hold"); m.put("why", why);
                m.put("fix", "점수는 그대로입니다. 새로 도전하면 1인 대전 캐릭터 고르기로 자동으로 들어갑니다.");
                if (!save()) throw new IOException("save");
                ckpt(matchId).delete();
                return m;
            }
            String out = (bits & 0x40) != 0 ? "W" : (bits & 0x20) != 0 ? "L" : "D";
            apply(m, me, o, out);
            m.put("status", "settled");
            m.put("settled", System.currentTimeMillis());
            if (!save()) throw new IOException("save");
            ckpt(matchId).delete();
            return m;
        } catch (Exception e) {
            try { db = new JSONObject(backup); } catch (Exception ignored) { }
            return null;
        }
    }

    /** 결과를 점수·전적·연승·순위에 반영한다(메모리만 — 저장은 호출자). 구간은 시작 때 저장한 두 점수로. */
    private static void apply(JSONObject m, JSONObject me, JSONObject o, String out) throws Exception {
        JSONObject ss = m.optJSONObject("start_score");
        int my0 = me.optInt("score"), op0 = o.optInt("score");
        int d = (ss != null) ? delta(ss.optInt("me"), ss.optInt("opp"), out) : delta(my0, op0, out);
        m.put("outcome", out);
        m.put("score_before", new JSONObject().put("me", my0).put("opp", op0));
        m.put("delta", d);
        if (!m.has("rank_before")) m.put("rank_before", rankOf("me"));
        me.put("score", my0 + d);
        o.put("score", op0 - d);
        if ("W".equals(out)) {
            me.put("w", me.optInt("w") + 1); o.put("l", o.optInt("l") + 1);
            me.put("streak", me.optInt("streak") + 1);
            me.put("best", Math.max(me.optInt("best"), me.optInt("streak")));
        } else if ("L".equals(out)) {
            me.put("l", me.optInt("l") + 1); o.put("w", o.optInt("w") + 1);
            if (me.optInt("streak") > 0) m.put("broke_streak", me.optInt("streak"));
            me.put("streak", 0);
        } else {
            me.put("d", me.optInt("d") + 1); o.put("d", o.optInt("d") + 1);
        }
        commitOrder();
        m.put("rank_after", rankOf("me"));
    }

    /** 기권패 — 시작한 경기를 사용자가 포기했을 때. 점수는 패배와 같게 움직인다. 아직 대진 전(준비)이면 cancel 을 쓴다. */
    static synchronized JSONObject forfeit(String matchId) {
        JSONObject m = matchById(matchId);
        if (m == null) return null;
        if (terminal(m.optString("status"))) return m;
        String backup = db.toString();
        try {
            m.put("forfeit", true);
            apply(m, me(), oppById(m.optString("opp")), "L");
            m.put("status", "forfeit");
            m.put("settled", System.currentTimeMillis());
            if (!save()) throw new IOException("save");
            ckpt(matchId).delete();
            return m;
        } catch (Exception e) {
            try { db = new JSONObject(backup); } catch (Exception ignored) { }
            return null;
        }
    }

    /** 이 상대와의 최근 경기들(정산·기권만, 새것부터). */
    static java.util.List<JSONObject> history(String oppId, int max) {
        java.util.List<JSONObject> out = new java.util.ArrayList<>();
        JSONArray a = matches();
        for (int i = a.length() - 1; i >= 0 && out.size() < max; i--) {
            JSONObject m = a.optJSONObject(i);
            String s = m.optString("status");
            if (oppId.equals(m.optString("opp")) && ("settled".equals(s) || "forfeit".equals(s))) out.add(m);
        }
        return out;
    }

    /** 보류·무효 경기(새것부터) — 원인과 복구 방법을 리그 화면에서 볼 수 있게. */
    static java.util.List<JSONObject> holds(int max) {
        java.util.List<JSONObject> out = new java.util.ArrayList<>();
        JSONArray a = matches();
        for (int i = a.length() - 1; i >= 0 && out.size() < max; i--) {
            JSONObject m = a.optJSONObject(i);
            String s = m.optString("status");
            if ("hold".equals(s) || "cancelled".equals(s)) out.add(m);
        }
        return out;
    }

    static String statusKo(String s) {
        switch (s) {
            case "ready": return "준비";
            case "playing": return "진행 중";
            case "resume": return "복귀 대기";
            case "settled": return "정산 완료";
            case "forfeit": return "기권";
            case "hold": return "오류 보류";
            case "cancelled": return "무효";
            default: return s;
        }
    }

    static String outcomeKo(JSONObject m) {
        String o = m.optString("outcome");
        if (m.optBoolean("forfeit")) return "기권패";
        return "W".equals(o) ? "승" : "L".equals(o) ? "패" : "D".equals(o) ? "무" : "?";
    }

    /** 결과 줄 — 「승 2:1 · +12」 */
    static String resultLine(JSONObject m) {
        JSONObject r = m.optJSONObject("result");
        String sc = (r != null && !m.optBoolean("forfeit")) ? " " + r.optInt("w1") + ":" + r.optInt("w2") : "";
        int d = m.optInt("delta");
        return outcomeKo(m) + sc + " · " + (d > 0 ? "+" + d : String.valueOf(d));
    }
}
