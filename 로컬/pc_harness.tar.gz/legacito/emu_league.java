    /* ── 가상 리그 랭크전 ─────────────────────────────────────────────── */

    private TextView leagueTag;
    private String corePathCache;
    private boolean resumedNow = false;        /* 화면에 떠 있나 — 백그라운드에서는 리그 화면을 띄우지 않고 복귀 때 띄운다 */
    private boolean leagueChoosing = false;    /* 나가기 창에서 「나중에」·「기권」을 골랐다 — 창이 닫혀도 멈춤을 풀지 않는다 */

    private org.json.JSONObject lm() { return League.matchById(leagueId); }

    /** 게임 화면 밖 이름표 — 위쪽 메뉴 알약 줄의 왼쪽(게임 화면·버튼을 덮지 않는다). 게임 안 이름(우쿄)과 닉네임(칼끝노인)을 갈라 보인다. */
    private void addLeagueTag() {
        org.json.JSONObject m = lm();
        org.json.JSONObject o = (m != null) ? League.oppById(m.optString("opp")) : null;
        leagueTag = new TextView(this);
        leagueTag.setText("랭크전 · " + (o != null ? o.optString("nick") + " (" + League.CHAR[o.optInt("char")] + " · "
                + League.STYLE[o.optInt("style")] + ")" : "?"));
        leagueTag.setTextColor(0xffd9a441);
        leagueTag.setTextSize(11);
        float dp = getResources().getDisplayMetrics().density;
        leagueTag.setPadding(Math.round(8 * dp), Math.round(2 * dp), 0, 0);
        root.addView(leagueTag, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT, android.view.Gravity.TOP | android.view.Gravity.LEFT));
    }

    /** 자동 정산 가능한 판인가 — 롬 사본 md5 와 코어(앱 동봉)를 고정 목록과 맞추고, 재개면 시작 때 기록한 판과도 맞춘다. 아니면 이유. */
    private String leagueVersionProblem(org.json.JSONObject m) {
        String md5 = League.md5(new File(romPath));
        String label = League.romLabel(md5);
        if (label == null) return "판정 주소를 확인하지 않은 롬입니다 (md5 " + md5 + ")";
        String core = corePathCache;
        if (core == null || !core.startsWith(getApplicationInfo().nativeLibraryDir))
            return "앱 동봉 코어가 아닌 코어로 실행 중입니다 (" + core + ")";
        String was = m.optString("rom_md5", "");
        if (!was.isEmpty() && !was.equals(md5))
            return "경기를 시작한 롬과 지금 롬이 다릅니다 (" + m.optString("rom") + " → " + label + ")";
        if (!was.equals(md5)) {
            League.note(leagueId, "rom_md5", md5);
            League.note(leagueId, "rom", label);
            League.note(leagueId, "core", coreLabel);
            try { League.note(leagueId, "app", getPackageManager().getPackageInfo(getPackageName(), 0).versionCode); } catch (Exception ignored) { }
        }
        return null;
    }

    /**
     * 랭크전 시작 — 인텐트 표시가 아니라 **경기 상태**로 가른다(액티비티가 다시 만들어지면 처음 인텐트가 그대로 온다).
     *   준비(ready)      → 새로 켠 판 + 메뉴 자동 진입. 남은 체크포인트는 있을 수 없으니 지운다.
     *   진행·복귀 대기    → 체크포인트로만 이어간다. 없거나 못 불러오면 새 판을 열지 않고 리그 화면으로(재개 불가 → 기권).
     *   끝난 경기         → 무장하지 않고 결과 창으로.
     * 롬·코어가 안 맞으면: 준비면 보류(대진 전 실패 — 점수 없음), 이미 시작한 경기면 상태·체크포인트를 그대로 두고 리그 화면으로
     * (원래 판으로 되돌리면 재개, 아니면 기권 — 판을 바꿔 지는 경기를 무효로 만들 수 없다).
     * 체크포인트 불러오기·무장은 UI 스레드에서 바로 한다(loadCore 의 자동 이어하기와 같은 자리) — onResume 이 체크포인트를 지우기 전에.
     */
    private void leagueStart() {
        org.json.JSONObject m = lm();
        String st = m.optString("status");
        if (League.terminal(st)) { leagueDone = true; leagueExit(leagueId); return; }
        boolean fresh = "ready".equals(st);
        String why = !loaded ? "코어/롬 로드 실패" : leagueVersionProblem(m);
        if (why != null) {
            if (fresh) leagueHoldExit("자동 정산 중지 — " + why,
                    "앱 동봉 코어와 지원 롬(순정 ss2.ngc·ss2_h1.ngc + 한글패치 v1.01/동봉판, 또는 순정)으로 되돌린 뒤 새로 도전하세요.");
            else leagueBlocked(why + "\n\n경기는 그대로 남겨 둡니다. 원래 판으로 되돌리면 이어할 수 있고, 아니면 기권만 할 수 있습니다.");
            return;
        }
        File ck = League.ckpt(leagueId);
        boolean fromCk = false;
        if (fresh) ck.delete();
        else {
            boolean had = ck.exists();
            if (had) fromCk = Emu.nativeLoadState(ck.getAbsolutePath()) == 0;
            if (!fromCk) {
                League.setStatus(leagueId, "resume", had ? "체크포인트를 불러오지 못함" : "체크포인트 없음");
                leagueBlocked(had ? "체크포인트를 불러오지 못했습니다(파일은 남겨 둡니다)." : "이어할 자리가 없습니다(체크포인트 없음) — 기권만 할 수 있습니다.");
                return;
            }
            ck.delete();                                      /* 한 번 쓰면 끝 */
        }
        org.json.JSONObject rule = m.optJSONObject("rule");
        /* 올카드(랭크전 전용 세이브라 원작 세이브엔 안 남는다) + 새 판이면 메뉴 자동 진입, 재개면 이미 선 결판도 잡기 */
        Emu.nativeLeagueArm(rule.optInt("char"), rule.optInt("style"), rule.optInt("diff"),
                rule.optInt("points"), rule.optInt("time"),
                Emu.LEAGUE_ALLCARDS | (fromCk ? Emu.LEAGUE_FROM_CKPT : Emu.LEAGUE_AUTONAV));
        leagueArmed = true;
        League.setStatus(leagueId, "playing", null);
        toast(fromCk ? "랭크전 — 내려간 자리에서 이어합니다" : "랭크전 — 캐릭터 고르기로 들어갑니다. 캐릭터·검질·카드를 고르세요");
        h.postDelayed(leaguePoll, 250);
    }

    private boolean nativeDone() {
        int[] st = Emu.nativeLeagueStatus();
        return st != null && st.length >= 18 && st[4] == 1;
    }

    /** 결판이 잡혀 있으면 바로 정산한다. 잡혀 있으면 true — 정산 저장이 실패했어도(그때는 체크포인트를 쓰지 않고, 결과는 코어 쪽에 둔 채 poll 이 다시 시도). */
    private boolean leagueSettleNow() {
        if (leagueDone) return true;
        if (!leagueArmed) return false;
        int[] st = Emu.nativeLeagueStatus();
        if (st == null || st.length < 18 || st[4] != 1) return false;
        Emu.nativeSetPaused(true);                            /* 결과 화면은 최종 승패가 확정된 뒤에만 — 게임은 그 자리에서 멈춘다 */
        if (League.settle(leagueId, st) == null) return true;
        leagueDone = true;
        Emu.nativeLeagueDisarm();
        return true;
    }

    /** 체크포인트 — 임시 파일에 쓰고 이름을 바꿔 넣는다(쓰다 죽어도 반쪽 파일이 안 남는다). 실패하면 옛 것을 그대로 둔다. */
    private boolean leagueSaveCkpt() {
        File ck = League.ckpt(leagueId), tmp = new File(ck.getPath() + ".tmp");
        if (Emu.nativeSaveState(tmp.getAbsolutePath()) != 0) { tmp.delete(); return false; }
        if (!tmp.renameTo(ck)) { tmp.delete(); return false; }
        return true;
    }

    /** 결판 감시 — 진짜 프레임에서 league.c 가 잡은 결과를 가져와 한 번만 정산한다. 화면에 떠 있을 때만 리그 화면으로 넘어간다. */
    private final Runnable leaguePoll = new Runnable() { @Override public void run() {
        if (leagueId == null) return;
        if (leagueDone) { if (resumedNow && !leaving) leagueExit(leagueId); return; }
        if (!loaded) return;
        if (nativeDone()) {
            if (leagueDlg != null && leagueDlg.isShowing()) leagueDlg.dismiss();
            if (!leagueSettleNow() || !leagueDone) {           /* 저장 실패 — 결과는 코어 쪽에 그대로 있으니 다시 */
                if (++leagueRetry % 8 == 1) toast("기록 저장 실패 — 다시 시도 중");
                h.postDelayed(this, 1000);
                return;
            }
            if (resumedNow) leagueExit(leagueId);
            return;
        }
        h.postDelayed(this, 250);
    }};

    /** 아직 대진 전(준비)에 롬·코어가 안 맞으면 — 보류(점수 없음), 원인과 복구 방법을 남기고 결과 창으로. */
    private void leagueHoldExit(final String why, String fix) {
        League.hold(leagueId, why, fix);
        leagueDone = true;
        h.post(new Runnable() { @Override public void run() {
            new android.app.AlertDialog.Builder(EmuActivity.this).setTitle("가상 리그")
                    .setMessage(why + "\n\n이 경기는 점수에 넣지 않습니다(보류).")
                    .setCancelable(false)
                    .setPositiveButton("확인", new android.content.DialogInterface.OnClickListener() {
                        @Override public void onClick(android.content.DialogInterface d, int w) { leagueExit(leagueId); } })
                    .show();
        }});
    }

    /** 시작한 경기를 지금 이어갈 수 없을 때 — 무장하지 않고 상태를 그대로 둔 채 리그 화면으로(재개 또는 기권). */
    private void leagueBlocked(final String msg) {
        leagueDone = true;
        h.post(new Runnable() { @Override public void run() {
            new android.app.AlertDialog.Builder(EmuActivity.this).setTitle("가상 리그 — 이어할 수 없음")
                    .setMessage(msg)
                    .setCancelable(false)
                    .setPositiveButton("리그 화면으로", new android.content.DialogInterface.OnClickListener() {
                        @Override public void onClick(android.content.DialogInterface d, int w) { leagueExit(null); } })
                    .show();
        }});
    }

    /** 뒤로 가기 — 계속 / 나중에 이어하기(체크포인트) / 기권. 결판이 이미 잡혀 있으면 창 없이 정산으로. */
    private void leagueLeave() {
        if (leagueDone || !leagueArmed) { leagueExit(null); return; }
        if (leagueSettleNow()) { if (leagueDone && resumedNow) leagueExit(leagueId); return; }
        if (leagueDlg != null && leagueDlg.isShowing()) return;
        leagueChoosing = false;
        Emu.nativeSetPaused(true);
        leagueDlg = new android.app.AlertDialog.Builder(this).setTitle("랭크전 중")
                .setMessage("나중에 이어하면 지금 자리에서 한 번만 다시 열 수 있습니다. 기권하면 패배로 기록됩니다.")
                .setPositiveButton("계속하기", null)
                .setNeutralButton("나중에 이어하기", new android.content.DialogInterface.OnClickListener() {
                    @Override public void onClick(android.content.DialogInterface d, int w) {
                        leagueChoosing = true;
                        if (leagueSettleNow()) { leagueChoosing = false; return; }   /* poll 이 결과 화면으로 */
                        gl.queueEvent(new Runnable() { @Override public void run() {
                            final boolean ok = leagueSaveCkpt();
                            h.post(new Runnable() { @Override public void run() {
                                if (leagueDone) return;
                                if (!ok) {
                                    leagueChoosing = false;
                                    toast("체크포인트를 저장하지 못했어요 — 경기를 계속합니다");
                                    Emu.nativeSetPaused(pad.isBarOpen());
                                    return;
                                }
                                League.setStatus(leagueId, "resume", "사용자가 나중에 이어하기");
                                leagueDone = true; Emu.nativeLeagueDisarm(); leagueExit(null);
                            }});
                        }});
                    } })
                .setNegativeButton("기권", new android.content.DialogInterface.OnClickListener() {
                    @Override public void onClick(android.content.DialogInterface d, int w) {
                        leagueChoosing = true;
                        if (leagueSettleNow()) { leagueChoosing = false; return; }
                        if (League.forfeit(leagueId) == null) {
                            leagueChoosing = false;
                            toast("저장 실패 — 다시 시도하세요");
                            Emu.nativeSetPaused(pad.isBarOpen());
                            return;
                        }
                        leagueDone = true; Emu.nativeLeagueDisarm(); leagueExit(leagueId);
                    } })
                .setOnDismissListener(new android.content.DialogInterface.OnDismissListener() {
                    @Override public void onDismiss(android.content.DialogInterface d) {
                        if (!leagueDone && !leagueChoosing && !nativeDone()) Emu.nativeSetPaused(pad.isBarOpen());
                    } })
                .show();
    }

    /** 리그 화면으로 — 결과가 있으면 그 결과 창을 띄운다. 코어는 GL 스레드에서 내린다(goList 와 같은 이유, 내릴 때 native 가 무장도 푼다). */
    private void leagueExit(final String resultId) {
        if (leaving) return;
        leaving = true;
        MainActivity.forgetLast(this);
        gl.queueEvent(new Runnable() { @Override public void run() {
            Emu.nativeLeagueDisarm();
            if (loaded) { Emu.nativeSaveSram(); Emu.nativeUnload(); loaded = false; }
            runOnUiThread(new Runnable() { @Override public void run() {
                Intent i = new Intent(EmuActivity.this, LeagueActivity.class);
                i.putExtra(LeagueActivity.EXTRA_ROM, getIntent().getStringExtra("rom"));
                if (resultId != null) i.putExtra(LeagueActivity.EXTRA_RESULT, resultId);
                startActivity(i);
                finish();
            }});
        }});
    }
}
