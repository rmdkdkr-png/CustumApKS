package com.dudu.pocketcore;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * 가상 리그 화면(사무쇼2) — 랭킹 · 상대 상세 · 경기 결과 · 진행 중 경기(기획서 2장 표).
 * 상대는 게임의 CPU 이고, 온라인 사람처럼 보이게 하지 않는다(화면에 그렇게 적는다).
 * 1단계: 사용자 1명 + 가상 상대 1명. 실제 경기는 EmuActivity 의 랭크전 모드에서 한다.
 */
public class LeagueActivity extends Activity {
    static final String EXTRA_ROM = "rom", EXTRA_RESULT = "league_result";

    private static final int BG = 0xff101218, CARD = 0xff191b22, LINE = 0xff2a2f3b, TXT = 0xffe6e8ee,
                             DIM = 0xff8b93a6, GOLD = 0xffd9a441, INK = 0xff101014, BTN2 = 0xff23262f,
                             WIN = 0xff6fcf8f, LOSE = 0xffe5737a;
    private String rom;
    private LinearLayout col;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        rom = getIntent().getStringExtra(EXTRA_ROM);
        League.markInterrupted();
        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(BG);
        col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(16), dp(20), dp(16), dp(28));
        sv.addView(col);
        setContentView(sv);
        render();
        String res = getIntent().getStringExtra(EXTRA_RESULT);
        if (res != null) showResult(res);
    }

    @Override protected void onNewIntent(Intent i) {
        super.onNewIntent(i);
        setIntent(i);
        if (i.getStringExtra(EXTRA_ROM) != null) rom = i.getStringExtra(EXTRA_ROM);
        render();
        String res = i.getStringExtra(EXTRA_RESULT);
        if (res != null) showResult(res);
    }

    @Override public void onBackPressed() {
        Intent i = new Intent(this, MainActivity.class);
        i.putExtra("menu", true);
        startActivity(i);
        finish();
    }

    /* ── 랭킹 ─────────────────────────────────────────────────────────── */

    private static final class Row { String id, nick, sub; int score, order; boolean me; JSONObject o; }

    /** League.order() 순서(점수 내림차순, 동점이면 직전 순위 그대로, 처음엔 고정 id 순). */
    private List<Row> table() {
        List<Row> rows = new ArrayList<>();
        int k = 0;
        for (String id : League.order()) {
            Row r = new Row(); r.id = id; r.order = k++;
            if ("me".equals(id)) {
                JSONObject me = League.me();
                r.nick = me.optString("name", "나"); r.me = true; r.score = me.optInt("score");
                r.sub = me.optInt("w") + "승 " + me.optInt("l") + "패" + (me.optInt("d") > 0 ? " " + me.optInt("d") + "무" : "")
                      + (me.optInt("streak") > 0 ? " · " + me.optInt("streak") + "연승" : "");
            } else {
                JSONObject o = League.oppById(id);
                if (o == null) continue;
                r.nick = o.optString("nick"); r.o = o; r.score = o.optInt("score");
                r.sub = League.oppLine(o);
            }
            rows.add(r);
        }
        return rows;
    }

    private void render() {
        col.removeAllViews();
        TextView h = text("가상 리그", 24, TXT, true);
        col.addView(h);
        TextView sub = text("사무라이 쇼다운! 2 · 1단계 시험 — 상대는 게임 CPU 입니다(실제 사람이 아닙니다).", 12, DIM, false);
        sub.setPadding(0, dp(4), 0, dp(14));
        col.addView(sub);

        final JSONObject open = League.openMatch();
        if (open != null) col.addView(openCard(open));

        List<Row> rows = table();
        LinearLayout card = card();
        for (int i = 0; i < rows.size(); i++) {
            if (i > 0) card.addView(line());
            card.addView(rankRow(i + 1, rows.get(i), open == null));
        }
        col.addView(card);

        TextView rules = text("규칙 · " + League.POINTS + "선승(3판 2승) · 라운드 " + League.TIME
                + "초 · 카드 전원 올카드 해금(CPU 는 카드 없음) · 도전하면 1인 대전 캐릭터 고르기까지 자동으로 들어갑니다."
                + " 내 캐릭터·검질·카드를 고르면 첫 상대가 가상 상대로 나옵니다. 경기 전체 결판만 기록하고,"
                + " 랭크전 중에는 불러오기·되돌리기·리셋을 쓸 수 없습니다. 랭크전 세이브는 원작 세이브와 따로입니다.", 12, DIM, false);
        rules.setPadding(0, dp(12), 0, 0);
        col.addView(rules);
        List<JSONObject> hs = League.holds(5);
        if (!hs.isEmpty()) {
            TextView hh = text("보류·무효 경기 — 점수에 넣지 않았습니다", 13, GOLD, true);
            hh.setPadding(0, dp(16), 0, dp(4));
            col.addView(hh);
            LinearLayout hc = card();
            for (int i = 0; i < hs.size(); i++) {
                final JSONObject m = hs.get(i);
                if (i > 0) hc.addView(line());
                JSONObject o = League.oppById(m.optString("opp"));
                TextView t = text(League.statusKo(m.optString("status")) + " · " + (o != null ? o.optString("nick") : "?") + "\n" + m.optString("why"), 12, DIM, false);
                t.setPadding(0, dp(6), 0, dp(6));
                t.setClickable(true);
                t.setOnClickListener(v -> showResult(m.optString("id")));
                hc.addView(t);
            }
            col.addView(hc);
        }
        if (rom == null) {
            TextView w = text("롬 경로가 없어 도전할 수 없습니다 — 런처에서 사무쇼2 카드를 눌러 「가상 리그」로 들어오세요.", 12, LOSE, false);
            w.setPadding(0, dp(10), 0, 0);
            col.addView(w);
        }
    }

    private View rankRow(int rank, final Row r, boolean canChallenge) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(0, dp(10), 0, dp(10));
        TextView n = text(String.valueOf(rank), 18, r.me ? GOLD : DIM, true);
        n.setGravity(Gravity.CENTER);
        row.addView(n, new LinearLayout.LayoutParams(dp(32), ViewGroup.LayoutParams.WRAP_CONTENT));
        LinearLayout tt = new LinearLayout(this);
        tt.setOrientation(LinearLayout.VERTICAL);
        tt.addView(text(r.nick + (r.me ? "  (나)" : ""), 16, TXT, true));
        String extra = r.sub;
        if (!r.me) {
            int myW = r.o.optInt("l"), myL = r.o.optInt("w");
            extra += "\n나와의 전적 " + myW + "승 " + myL + "패" + (r.o.optInt("d") > 0 ? " " + r.o.optInt("d") + "무" : "")
                   + (myW == 0 && myL > 0 ? " · 아직 못 이긴 상대" : "");
        }
        tt.addView(text(extra, 12, DIM, false));
        row.addView(tt, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        row.addView(text(String.valueOf(r.score), 16, r.me ? GOLD : TXT, true));
        if (!r.me) {
            row.setClickable(true);
            row.setOnClickListener(v -> detail(r.o, canChallenge));
        }
        return row;
    }

    /* ── 상대 상세 ────────────────────────────────────────────────────── */

    private void detail(final JSONObject o, boolean canChallenge) {
        StringBuilder sb = new StringBuilder();
        sb.append("캐릭터 ").append(League.CHAR[o.optInt("char")]).append(" · 검질 ").append(League.STYLE[o.optInt("style")])
          .append("\nCPU 난도 ").append(League.DIFF[o.optInt("diff")])
          .append("\n점수 ").append(o.optInt("score"))
          .append("\n나와의 전적 ").append(o.optInt("l")).append("승 ").append(o.optInt("w")).append("패");
        if (o.optInt("d") > 0) sb.append(" ").append(o.optInt("d")).append("무");
        sb.append("\n\n경기 규칙: ").append(League.POINTS).append("선승 · 라운드 ").append(League.TIME).append("초 · 카드 올카드 해금(CPU 카드 없음)");
        List<JSONObject> hist = League.history(o.optString("id"), 5);
        if (!hist.isEmpty()) {
            sb.append("\n\n최근 경기");
            for (JSONObject m : hist) sb.append("\n · ").append(League.resultLine(m));
        }
        AlertDialog.Builder d = new AlertDialog.Builder(this)
                .setTitle(o.optString("nick"))
                .setMessage(sb.toString())
                .setNegativeButton("닫기", null);
        if (canChallenge && rom != null)
            d.setPositiveButton("도전", (x, y) -> challenge(o.optString("id")));
        d.show();
    }

    private boolean launching = false;          /* 두 번 눌러 게임 창이 둘 뜨지 않게 */

    private void challenge(String oppId) {
        if (launching) return;
        if (rom == null || !new File(rom).exists()) { toast("롬을 찾을 수 없습니다"); return; }
        if (League.openMatch() != null) { toast("끝나지 않은 경기가 있습니다 — 먼저 재개하거나 정리하세요"); render(); return; }
        JSONObject m = League.newMatch(oppId);
        if (m == null) { toast("경기 기록을 저장하지 못해 시작하지 않았습니다"); return; }
        launch(m.optString("id"), false);
    }

    private void launch(String matchId, boolean resume) {
        if (launching) return;
        if (rom == null || !new File(rom).exists()) { toast("롬을 찾을 수 없습니다 — 원래 자리에 롬을 두면 재개할 수 있습니다"); return; }
        launching = true;
        Intent i = new Intent(this, EmuActivity.class);
        i.putExtra("rom", rom);
        i.putExtra(EmuActivity.EXTRA_LEAGUE, matchId);
        i.putExtra(EmuActivity.EXTRA_LEAGUE_RESUME, resume);
        startActivity(i);
        finish();
    }

    /* ── 진행 중 경기 ──────────────────────────────────────────────────── */

    private View openCard(final JSONObject m) {
        LinearLayout c = card();
        JSONObject o = League.oppById(m.optString("opp"));
        final String st = m.optString("status");
        final boolean hasCk = League.ckpt(m.optString("id")).exists();
        final boolean ready = "ready".equals(st);
        c.addView(text("진행 중 경기 · " + League.statusKo(st), 13, GOLD, true));
        String note = ready ? "첫 라운드 전에 멈춘 경기입니다 — 다시 시작하거나, 무효로 닫으면 점수는 그대로입니다."
                : hasCk ? "앱이 내려간 그 자리에서 한 번 이어할 수 있습니다."
                : "이어할 자리가 없습니다(체크포인트 없음) — 기권만 할 수 있습니다.";
        if (!ready && m.has("why") && !m.optString("why").isEmpty()) note += "\n(" + m.optString("why") + ")";
        if (!ready && m.has("fix")) note += "\n복구: " + m.optString("fix");
        c.addView(text((o != null ? o.optString("nick") + " · " + League.oppLine(o) : "?") + "\n" + note, 13, TXT, false));
        LinearLayout btns = new LinearLayout(this);
        btns.setOrientation(LinearLayout.HORIZONTAL);
        TextView ff = pill(ready ? "무효로 닫기" : "기권", BTN2, LOSE);
        ff.setOnClickListener(v -> {
            if (ready) {
                if (!League.cancel(m.optString("id"), "대진 전에 멈춤 — 사용자가 무효로 닫음")) toast("저장 실패 — 다시 시도하세요");
                render();
                return;
            }
            new AlertDialog.Builder(this).setTitle("기권")
                .setMessage("이 경기를 기권패로 기록합니다.")
                .setPositiveButton("기권", (x, y) -> {
                    JSONObject r = League.forfeit(m.optString("id"));
                    if (r == null) toast("저장 실패 — 다시 시도하세요"); else { render(); showResult(m.optString("id")); }
                })
                .setNegativeButton("취소", null).show();
        });
        btns.addView(ff, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        if ((ready || hasCk) && rom != null) {               /* 준비면 새 판으로 다시 시작, 진행 중이면 체크포인트로 재개 */
            TextView go = pill(ready ? "다시 시작" : "재개", GOLD, INK);
            go.setOnClickListener(v -> launch(m.optString("id"), !ready));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 2f);
            lp.leftMargin = dp(10);
            btns.addView(go, lp);
        }
        btns.setPadding(0, dp(10), 0, 0);
        c.addView(btns);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.bottomMargin = dp(12);
        c.setLayoutParams(lp);
        return c;
    }

    /* ── 경기 결과 ────────────────────────────────────────────────────── */

    private void showResult(String matchId) {
        JSONObject m = League.matchById(matchId);
        if (m == null) return;
        JSONObject o = League.oppById(m.optString("opp"));
        String st = m.optString("status");
        StringBuilder sb = new StringBuilder();
        String title;
        if ("hold".equals(st) || "cancelled".equals(st)) {
            title = ("hold".equals(st) ? "보류" : "무효") + " — 점수에 넣지 않았습니다";
            sb.append(m.optString("why"));
            if (m.has("fix")) sb.append("\n\n복구: ").append(m.optString("fix"));
        } else {
            title = "W".equals(m.optString("outcome")) ? "승리" : "L".equals(m.optString("outcome")) ? (m.optBoolean("forfeit") ? "기권패" : "패배") : "무승부";
            JSONObject r = m.optJSONObject("result");
            if (r != null) sb.append("최종 ").append(r.optInt("w1")).append(" : ").append(r.optInt("w2"))
                    .append("  (").append(League.CHAR[r.optInt("my_char")]).append(" vs ")
                    .append(o != null ? League.CHAR[o.optInt("char")] : "?").append(")\n");
            JSONObject sb0 = m.optJSONObject("score_before");
            int d = m.optInt("delta");
            if (sb0 != null) {
                int rankBefore = m.optInt("rank_before"), rankAfter = m.optInt("rank_after");
                sb.append("점수 ").append(sb0.optInt("me")).append(" → ").append(sb0.optInt("me") + d)
                  .append(" (").append(d > 0 ? "+" + d : String.valueOf(d)).append(")")
                  .append("\n순위 ").append(rankBefore).append("위 → ").append(rankAfter).append("위");
            }
            if (o != null) sb.append("\n").append(o.optString("nick")).append("과(와)의 전적 ")
                    .append(o.optInt("l")).append("승 ").append(o.optInt("w")).append("패")
                    .append(o.optInt("d") > 0 ? " " + o.optInt("d") + "무" : "");
            JSONObject me = League.me();
            if (me.optInt("streak") > 0) sb.append("\n").append(me.optInt("streak")).append("연승 (최장 ").append(me.optInt("best")).append(")");
            if (m.has("broke_streak")) sb.append("\n").append(m.optInt("broke_streak")).append("연승이 끊겼습니다");
        }
        AlertDialog.Builder d = new AlertDialog.Builder(this).setTitle(title).setMessage(sb.toString())
                .setNegativeButton("랭킹으로", null);
        if (o != null && rom != null && League.openMatch() == null)
            d.setPositiveButton("재대결", (x, y) -> challenge(o.optString("id")));
        d.show();
    }

    /* ── 그리기 도구 ───────────────────────────────────────────────────── */

    private LinearLayout card() {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable g = new GradientDrawable(); g.setColor(CARD); g.setCornerRadius(dp(14));
        c.setBackground(g);
        c.setPadding(dp(14), dp(10), dp(14), dp(10));
        return c;
    }
    private View line() { View v = new View(this); v.setBackgroundColor(LINE); v.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 1)); return v; }
    private TextView text(String s, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(sp); t.setTextColor(color);
        if (bold) t.setTypeface(t.getTypeface(), Typeface.BOLD);
        return t;
    }
    private TextView pill(String s, int bg, int fg) {
        TextView t = text(s, 15, fg, true);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(12), dp(10), dp(12), dp(10));
        GradientDrawable g = new GradientDrawable(); g.setColor(bg); g.setCornerRadius(dp(12));
        t.setBackground(g);
        t.setClickable(true);
        return t;
    }
    private void toast(String s) { android.widget.Toast.makeText(this, s, android.widget.Toast.LENGTH_SHORT).show(); }
    private int dp(float v) { return Math.round(v * getResources().getDisplayMetrics().density); }
}
