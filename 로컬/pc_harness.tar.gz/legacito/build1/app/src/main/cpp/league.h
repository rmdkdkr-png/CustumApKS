/* 가상 리그 — 사무쇼2 랭크전의 대진 덮어쓰기·최종 결과 감지 (league.c). */
#pragma once
#include <stddef.h>
#include <stdint.h>

/* 진짜 프레임 한 번(retro_run) 뒤, 코어 잠금 안에서 부른다. ram = SYSTEM_RAM(16KB, CPU 0x4000~). */
void league_tick(uint8_t *ram, size_t n);

#define LEAGUE_NSTAT 21
#define LEAGUE_CARDS_OFF 1   /* 사용자 카드 없음(0xFF) */
#define LEAGUE_ALLCARDS  2   /* 올카드 해금(소유 개수 8) */
#define LEAGUE_AUTONAV   4   /* 새로 켠 판 — 1인 대전 캐릭터 고르기까지 메뉴 자동 진입 */
#define LEAGUE_FROM_CKPT 8   /* 체크포인트에서 재개 — 이미 서 있는 결판 bit7 도 이 경기 결과로 잡는다 */
void league_arm(int opp, int sty, int diff, int points, int timev, int flags);
/* 메뉴 자동 진입 중이면 on=1, 입력 콜백은 사용자 입력 대신 mask 를 돌려준다 */
extern volatile int league_ovr_on, league_ovr_mask;
void league_disarm(void);
void league_status(int v[LEAGUE_NSTAT]);
