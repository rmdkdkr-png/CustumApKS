/* 가상 리그 — 사무쇼2 랭크전 한 판의 «대진 덮어쓰기»와 «최종 결과 감지».

   기획서(NGP 사무라이 쇼다운 2 가상 리그 v1) 4장의 두 검증 항목을 실행부에서 한다.
   주소는 CustumApKS handoff/ss2_league/0단계_주소탐색_결과.md 에서 확정한 것만 쓴다
   (순정 ss2.ngc·ss2_h1.ngc 와 한글패치 v1.01·동봉판 사본에서 같게 동작함을 실측).
   지원하지 않는 롬에서는 Java 가 아예 무장(arm)하지 않는다 — 여기서는 롬을 가리지 않는다.

   매 «진짜» 프레임(retro_run 한 번 뒤, 코어 잠금 안)에 league_tick 이 불린다.
   런어헤드·프레임 생성의 숨은 프레임은 코어 안에서 되돌려지므로 여기 오지 않는다.

     대진: 결판 전까지 매 프레임 0x57DF(상대 id)·0x57E0(유파)를 쓴다. 게임은 상대를 뽑는 프레임에
           한 번 써 넣으므로 그 뒤 첫 프레임에 다시 덮이고, 전투 로드(0x5D51) 때는 이미 우리 값이다.
     결과: 0x5824 의 bit7(경기 결판)이 0 인 것을 한 번 본 뒤 1 로 서는 첫 프레임 = 경기 최종 결과.
           승자는 같은 바이트의 0x40(P1)/0x20(P2), 둘 다 없으면 무승부. 승수는 0x5821/0x5822.
           «승수 == 2» 는 쓰지 않는다 — 무승부 라운드(양쪽 +1)·3:3 무승부·포인트 3·1 라운드 경기에서 틀린다.
     한 번만: 잡은 뒤에는 done 이 서고 다시 잡지 않는다(다음 경기는 Java 가 새로 무장한다).
     경기 시작: (0x40A7==241 && 0x411A==1 && 0x5824==0) 이 거짓→참이 되는 첫 프레임이 라운드 시작이고,
           그때 승수 0:0 이고 이어하기 횟수(0x5804)가 0 이면 경기 시작이다(입력은 그 2프레임 뒤부터 받는다).
           리셋 직후 남은 램으로는 서지 않는다 — 옛 «P2 블록이 목표와 같다» 조건은 남은 램에 헛발했다.
     올카드: 소유 개수(0x63BA + 8×캐릭 + 4×유파 + k, 120칸)를 8로 채운다. 게임은 부팅과 «모드를 고르는 순간»
           세이브에서 다시 읽어 덮으므로, 캐릭터·유파 고르기 화면(MODE 240 · SCR 2/4) 동안 쓴다(마감은 유파 확정 뒤 SCR 4→0).
           게임오버·설정 저장 때 이 값이 .flash 에 남으므로 랭크전은 원작과 다른 세이브 폴더를 쓴다(Java).
     메뉴 자동 진입: 새로 켠 판이면 «A → 뗐다가 → A» 로 1인 대전 캐릭터 고르기까지 대신 밟는다(그동안 사용자 입력은 막는다).
           캐릭터·유파·카드는 사용자가 고른다. 정해진 때까지 못 닿으면 손을 뗀다. */

#include <jni.h>
#include <pthread.h>
#include <stdint.h>
#include <string.h>
#include "league.h"

#define RAM_BASE 0x4000
#define A(x) ((x) - RAM_BASE)

#define R_OPP    A(0x57DF)   /* 다음/지금 상대 캐릭터 id (0~14) */
#define R_STY    A(0x57E0)   /* 상대 유파 0 修羅 · 1 羅刹 */
#define R_CARD1  A(0x57DC)   /* P1 능력 카드 1 · 2 — 0xFF 없음 */
#define R_CARD2  A(0x57DD)
#define R_W1     A(0x5821)   /* 라운드 승수 P1 · P2 */
#define R_W2     A(0x5822)
#define R_KO     A(0x5823)
#define R_RES    A(0x5824)   /* 라운드 결과 0x40 P1 · 0x20 P2 · 0x10 무승부 라운드, +0x80 경기 결판 */
#define R_NEED   A(0x5813)   /* 이번 경기 실효 포인트(필요 승수) */
#define R_TIME   A(0x5812)   /* 이번 경기 실효 시간 */
#define R_HP1    A(0x5A46)
#define R_HP2    A(0x5C46)
#define R_P1BLK  A(0x5B51)   /* (캐릭터<<4)|(유파<<3)|(카드 미러 0x04) */
#define R_P2BLK  A(0x5D51)
#define R_MODE   A(0x40A7)   /* 240 메뉴·연출 / 241 전투측 */
#define R_SCR    A(0x41C0)   /* 메뉴 화면: 0 타이틀 · 2 캐릭터 · 4 유파 · 6 카드 */
#define R_FIGHT  A(0x411A)   /* 1 = 라운드 진행(조작 가능 직전) */
#define R_CONT   A(0x5804)   /* 이어하기 횟수 — 새 1인 대전 캐릭터 고르기에서 0 */
#define R_OPT    A(0x636A)   /* GAME OPTION: 난도·포인트·시간·대전 포인트·대전 시간 */
#define R_OWN    A(0x63BA)   /* 카드 소유 개수 120칸 */
#define R_CPUMUL A(0x57E2)   /* CPU 공격 배율 · 받는 피해 배율(16비트씩, 0x100=1.0) — 난도·장 따라 */
#define R_CPULV  A(0x5814)   /* CPU 단계 — 1인 대전 첫 경기에서 1 + 3×난도(이어하기마다 줄어듦) */
#define R_CCARD1 A(0x57E6)   /* CPU(P2) 카드 1 · 2 — 0xFF 없음 */
#define R_CCARD2 A(0x57E7)

/* 메뉴 자동 진입 — native.c 의 입력 콜백이 이 둘을 본다(다음 프레임 입력). NGPC A = libretro JOYPAD_B(0). */
volatile int league_ovr_on = 0, league_ovr_mask = 0;

static pthread_mutex_t L_mu = PTHREAD_MUTEX_INITIALIZER;
static struct {
   int armed;
   int opp, sty;            /* 대진 목표 */
   int diff, points, timev; /* 옵션 — 음수면 안 건드린다 */
   int cards_off;           /* 1 = 사용자 카드 없음(0xFF) */
   int allcards;            /* 1 = 올카드 해금 */
   int autonav;             /* 1 = 메뉴 자동 진입 중 */
   unsigned nav_ok;         /* 캐릭터 고르기 화면이 이어진 프레임 수 */
   int seen_open;           /* 무장 뒤 bit7 이 0 인 걸 봤나 */
   int rs_prev;             /* 지난 프레임의 라운드 시작 조건 */
   int fight_seen;          /* 경기 시작(첫 라운드, 0:0)을 봤나 */
   int done;                /* 최종 결과를 잡았나 */
   int bits, w1, w2, ko, need, timev_eff, p1blk, p2blk, p2blk_first, card1, card2, cpu_lv, cpu_atk, cpu_def;
   unsigned frames, fight_frame, done_frame;
} L;

void league_tick(uint8_t *ram, size_t n)
{
   if (!ram || n < 0x4000) return;
   pthread_mutex_lock(&L_mu);
   if (!L.armed || L.done) { pthread_mutex_unlock(&L_mu); return; }
   L.frames++;

   ram[R_OPP] = (uint8_t)L.opp;
   ram[R_STY] = (uint8_t)L.sty;
   ram[R_CCARD1] = 0xFF; ram[R_CCARD2] = 0xFF;          /* CPU 카드 없음 — 리그 공통 규칙(1장 상대는 원래도 없다) */
   if (L.cards_off) { ram[R_CARD1] = 0xFF; ram[R_CARD2] = 0xFF; }
   if (L.diff   >= 0) ram[R_OPT + 0] = (uint8_t)L.diff;
   if (L.points >  0) ram[R_OPT + 1] = (uint8_t)L.points;
   if (L.timev  >  0) ram[R_OPT + 2] = (uint8_t)L.timev;
   if (L.allcards && ram[R_MODE] == 240 && (ram[R_SCR] == 2 || ram[R_SCR] == 4))
      memset(ram + R_OWN, 8, 120);

   /* 메뉴 자동 진입: 무장 뒤 20·60 프레임에 A(4프레임씩, 사이는 뗀다). 캐릭터 고르기(MODE 240 · SCR 2)가
      30프레임 이어지면 끝(데모·이어하기 화면도 잠깐 SCR 2 라서 이어짐까지 본다). 400프레임 안에 못 닿으면 손을 뗀다. */
   if (L.autonav) {
      unsigned f = L.frames + 1;                        /* 다음 프레임에 들어갈 입력 */
      league_ovr_mask = ((f >= 20 && f < 24) || (f >= 60 && f < 64)) ? 1 : 0;
      league_ovr_on = 1;
      if (L.frames > 64 && ram[R_MODE] == 240 && ram[R_SCR] == 2) L.nav_ok++; else L.nav_ok = 0;
      if (L.nav_ok >= 30 || L.frames > 400) { L.autonav = 0; league_ovr_on = 0; league_ovr_mask = 0; }
   }

   /* 경기 시작 — 첫 라운드(0:0, 이어하기 아님)가 조작 가능해지는 순간. 대진이 맞는지 이때 P2 블록으로도 남긴다 */
   int rs = ram[R_MODE] == 241 && ram[R_FIGHT] == 1 && ram[R_RES] == 0;
   if (rs && !L.rs_prev && !L.fight_seen && ram[R_W1] == 0 && ram[R_W2] == 0 && ram[R_CONT] == 0) {
      L.fight_seen = 1; L.fight_frame = L.frames; L.p2blk_first = ram[R_P2BLK];
   }
   L.rs_prev = rs;

   uint8_t r = ram[R_RES];
   if (!(r & 0x80)) L.seen_open = 1;
   else if (L.seen_open) {
      L.done = 1; L.done_frame = L.frames;
      L.autonav = 0; league_ovr_on = 0; league_ovr_mask = 0;
      L.bits = r; L.w1 = ram[R_W1]; L.w2 = ram[R_W2]; L.ko = ram[R_KO];
      L.need = ram[R_NEED]; L.p1blk = ram[R_P1BLK]; L.p2blk = ram[R_P2BLK];
      L.card1 = ram[R_CARD1]; L.card2 = ram[R_CARD2]; L.timev_eff = ram[R_TIME];
      L.cpu_lv = ram[R_CPULV];                        /* 난도가 실제로 먹었는지의 증거 — 정산 기록에 남긴다 */
      L.cpu_atk = ram[R_CPUMUL] | (ram[R_CPUMUL + 1] << 8); L.cpu_def = ram[R_CPUMUL + 2] | (ram[R_CPUMUL + 3] << 8);
   }
   pthread_mutex_unlock(&L_mu);
}

/* JNI 없이도 부를 수 있게(호스트 시험 하네스가 ctypes 로 같은 코드를 돌린다) 몸통은 평범한 C 함수로 둔다. */
void league_arm(int opp, int sty, int diff, int points, int timev, int flags)
{
   pthread_mutex_lock(&L_mu);
   memset(&L, 0, sizeof L);
   L.opp = opp & 0x0F; L.sty = sty & 1;
   L.diff = diff; L.points = points; L.timev = timev;
   L.cards_off = (flags & LEAGUE_CARDS_OFF) ? 1 : 0;
   L.allcards  = (flags & LEAGUE_ALLCARDS) ? 1 : 0;
   L.autonav   = (flags & LEAGUE_AUTONAV) ? 1 : 0;
   L.rs_prev   = 1;                                   /* 무장 순간 이미 라운드 중이면(체크포인트) 그 라운드는 «시작»으로 안 센다 */
   /* 체크포인트에서 재개: 랭크전 판은 램이 0 인 새 부팅에서 시작하므로, 체크포인트 안에서 bit7 이 이미 서 있다면
      그건 이 경기의 결판뿐이다(Java 가 정산하기 전에 앱이 내려간 경우). 첫 틱에 그대로 결과로 잡는다. */
   L.seen_open = (flags & LEAGUE_FROM_CKPT) ? 1 : 0;
   league_ovr_on = 0; league_ovr_mask = 0;
   L.armed = 1;
   pthread_mutex_unlock(&L_mu);
}

void league_disarm(void)
{
   pthread_mutex_lock(&L_mu); L.armed = 0; league_ovr_on = 0; league_ovr_mask = 0; pthread_mutex_unlock(&L_mu);
}

/* [무장, 프레임, bit7 0 봄, 경기 시작 봄, 결과 잡음, 결과 비트, 승수1, 승수2, KO, 실효 포인트,
    P1 블록, P2 블록(결판), P2 블록(경기 시작), 경기 시작 프레임, 결판 프레임, 사용자 카드 1, 2, 실효 시간,
    CPU 단계, CPU 공격 배율, CPU 받는 피해 배율] */
void league_status(int v[LEAGUE_NSTAT])
{
   pthread_mutex_lock(&L_mu);
   v[0] = L.armed; v[1] = (int)L.frames; v[2] = L.seen_open; v[3] = L.fight_seen; v[4] = L.done;
   v[5] = L.bits; v[6] = L.w1; v[7] = L.w2; v[8] = L.ko; v[9] = L.need;
   v[10] = L.p1blk; v[11] = L.p2blk; v[12] = L.p2blk_first;
   v[13] = (int)L.fight_frame; v[14] = (int)L.done_frame;
   v[15] = L.done ? L.card1 : 0xFF; v[16] = L.done ? L.card2 : 0xFF;
   v[17] = L.timev_eff;
   v[18] = L.cpu_lv; v[19] = L.cpu_atk; v[20] = L.cpu_def;
   pthread_mutex_unlock(&L_mu);
}

#define JNI(ret, name) JNIEXPORT ret JNICALL Java_com_dudu_pocketcore_Emu_##name

JNI(void, nativeLeagueArm)(JNIEnv *env, jclass cls, jint opp, jint sty, jint diff, jint points,
                           jint timev, jint flags)
{ (void)env; (void)cls; league_arm(opp, sty, diff, points, timev, flags); }

JNI(void, nativeLeagueDisarm)(JNIEnv *env, jclass cls)
{ (void)env; (void)cls; league_disarm(); }

JNI(jintArray, nativeLeagueStatus)(JNIEnv *env, jclass cls)
{
   (void)cls;
   int v[LEAGUE_NSTAT];
   jint jv[LEAGUE_NSTAT];
   league_status(v);
   for (int i = 0; i < LEAGUE_NSTAT; i++) jv[i] = v[i];
   jintArray a = (*env)->NewIntArray(env, LEAGUE_NSTAT);
   if (a) (*env)->SetIntArrayRegion(env, a, 0, LEAGUE_NSTAT, jv);
   return a;
}
